/* SehatSaathi AI - Global Script */

document.addEventListener('DOMContentLoaded', () => {
    // Determine path level
    const isSubPage = window.location.pathname.toLowerCase().includes('/pages/');
    const basePath = isSubPage ? '../' : '';
    const pageName = window.location.pathname.split('/').pop() || 'index.html';

    // ==========================================
    // 0. LOCALSTORAGE GUEST INTERCEPTOR & MIGRATION
    // ==========================================
    const originalGetItem = localStorage.getItem.bind(localStorage);
    const originalSetItem = localStorage.setItem.bind(localStorage);
    const originalRemoveItem = localStorage.removeItem.bind(localStorage);

    // List of keys to prefix under the Guest ID when in guest mode
    const guestKeysToPrefix = [
        'guest_bmi', 'guest_weight', 'guest_height', 'guest_waterIntake', 
        'guest_sleepHours', 'guest_medicineReminders', 'guest_vaccinationReminders', 
        'guest_healthGoals', 'guest_healthTopicsCompleted', 'guest_aiQuestionsAnswered', 
        'guest_surveySubmissions', 'sehatsathi_family_profiles', 'sehatsathi_lang',
        'sehatsathi_ai_chat_history', 'sehatsathi_guest_name'
    ];

    // Check if legacy (unprefixed) guest data exists in localStorage
    const hasLegacyData = originalGetItem('guest_bmi') || 
                           originalGetItem('sehatsathi_family_profiles') || 
                           originalGetItem('guest_waterIntake');
    
    // Auto-generate guest ID and enable guest mode if legacy data is present
    let guestId = originalGetItem('sehatsathi_guest_id');
    if (hasLegacyData && !guestId) {
        const randHex = Math.floor(100000 + Math.random() * 900000).toString(16).toUpperCase().substring(0, 6);
        guestId = `SSA-${randHex}`;
        originalSetItem('sehatsathi_guest_id', guestId);
        originalSetItem('sehatsathi_guest_mode', 'true');
    }

    // Migration function to copy old unprefixed data to prefixed keys
    if (guestId) {
        guestKeysToPrefix.forEach(key => {
            const oldVal = originalGetItem(key);
            const newVal = originalGetItem(`${guestId}_${key}`);
            if (oldVal !== null && newVal === null) {
                originalSetItem(`${guestId}_${key}`, oldVal);
            }
        });
    }

    // Override localStorage methods
    localStorage.getItem = function(key) {
        const currentGuestMode = originalGetItem('sehatsathi_guest_mode') === 'true';
        const currentGuestId = originalGetItem('sehatsathi_guest_id');
        if (currentGuestMode && currentGuestId && guestKeysToPrefix.includes(key)) {
            return originalGetItem(`${currentGuestId}_${key}`);
        }
        return originalGetItem(key);
    };

    localStorage.setItem = function(key, value) {
        const currentGuestMode = originalGetItem('sehatsathi_guest_mode') === 'true';
        const currentGuestId = originalGetItem('sehatsathi_guest_id');
        if (currentGuestMode && currentGuestId && guestKeysToPrefix.includes(key)) {
            return originalSetItem(`${currentGuestId}_${key}`, value);
        }
        return originalSetItem(key, value);
    };

    localStorage.removeItem = function(key) {
        const currentGuestMode = originalGetItem('sehatsathi_guest_mode') === 'true';
        const currentGuestId = originalGetItem('sehatsathi_guest_id');
        if (currentGuestMode && currentGuestId && guestKeysToPrefix.includes(key)) {
            return originalRemoveItem(`${currentGuestId}_${key}`);
        }
        return originalRemoveItem(key);
    };

    // Helper to display a welcome toast (only once per session)
    function showToast(message) {
        const toast = document.createElement('div');
        toast.className = "fixed bottom-5 right-5 md:bottom-10 md:right-10 bg-surface-container-high border border-secondary-fixed/30 text-white px-6 py-3.5 rounded-2xl shadow-2xl z-50 flex items-center gap-3 animate-fade-in-up backdrop-blur-xl max-w-sm";
        toast.style.transition = "all 0.5s ease";
        toast.innerHTML = `
            <span class="material-symbols-outlined text-secondary-fixed">info</span>
            <span class="text-sm font-medium leading-snug">${message}</span>
        `;
        document.body.appendChild(toast);
        setTimeout(() => {
            toast.style.opacity = '0';
            toast.style.transform = 'translateY(20px)';
            setTimeout(() => toast.remove(), 500);
        }, 4000);
    }

    const currentGuestMode = originalGetItem('sehatsathi_guest_mode') === 'true';
    const toastShown = originalGetItem('sehatsathi_welcome_toast_shown') === 'true';
    if (currentGuestMode && !toastShown) {
        // Delay slightly for visual effect
        setTimeout(() => {
            showToast("Welcome! Your health data will be saved locally on this device.");
            originalSetItem('sehatsathi_welcome_toast_shown', 'true');
        }, 1000);
    }

    // ==========================================
    // 1. FIREBASE & STATE LAYER (MOCK/LIVE DUAL MODE)
    // ==========================================
    window.sehatSathiDB = {
        currentUser: null,
        
        init() {
            // Load from LocalStorage first
            const savedUser = localStorage.getItem('sehatsathi_current_user');
            if (savedUser) {
                this.currentUser = JSON.parse(savedUser);
            }
            this.updateProfileUI();
            
            // Try loading Firebase SDKs and connect
            const firebaseConfig = localStorage.getItem('sehatsathi_firebase_config');
            if (firebaseConfig) {
                try {
                    const config = JSON.parse(firebaseConfig);
                    this.loadFirebaseSDKs().then(() => {
                        if (!window.firebase.apps.length) {
                            window.firebase.initializeApp(config);
                        }
                        window.firestoreDb = window.firebase.firestore();
                        console.log("Firebase initialized successfully.");
                        
                        // Sync current user with Firestore
                        if (this.currentUser) {
                            window.firestoreDb.collection('users').doc(this.currentUser.uid).get().then(doc => {
                                if (doc.exists) {
                                    this.currentUser = { ...this.currentUser, ...doc.data() };
                                    localStorage.setItem('sehatsathi_current_user', JSON.stringify(this.currentUser));
                                    this.updateProfileUI();
                                    this.refreshPageMetrics();
                                }
                            });
                        }
                    });
                } catch (e) {
                    console.warn("Invalid Firebase config stored.", e);
                }
            }
        },

        loadFirebaseSDKs() {
            return new Promise((resolve) => {
                if (window.firebase) {
                    resolve();
                    return;
                }
                const appScript = document.createElement('script');
                appScript.src = "https://www.gstatic.com/firebasejs/9.6.10/firebase-app-compat.js";
                appScript.onload = () => {
                    const authScript = document.createElement('script');
                    authScript.src = "https://www.gstatic.com/firebasejs/9.6.10/firebase-auth-compat.js";
                    authScript.onload = () => {
                        const firestoreScript = document.createElement('script');
                        firestoreScript.src = "https://www.gstatic.com/firebasejs/9.6.10/firebase-firestore-compat.js";
                        firestoreScript.onload = () => {
                            resolve();
                        };
                        document.head.appendChild(firestoreScript);
                    };
                    document.head.appendChild(authScript);
                };
                document.head.appendChild(appScript);
            });
        },

        register(name, email, password, age, blood) {
            let users = JSON.parse(localStorage.getItem('sehatsathi_all_users') || '[]');
            if (users.find(u => u.email === email)) {
                alert("An account with this email already exists.");
                return false;
            }
            const newUser = {
                uid: 'usr_' + Date.now(),
                name,
                email,
                password,
                age,
                bloodGroup: blood,
                bmi: "22.9",
                weight: "70",
                height: "175",
                waterIntake: "1.8",
                sleepHours: "7.25",
                medicineReminders: [
                    { id: 1, name: 'Vitamin D3', time: '08:00 AM', dose: '1 Pill', taken: true },
                    { id: 2, name: 'Amoxicillin', time: '02:00 PM', dose: 'After food', taken: false },
                    { id: 3, name: 'Atorvastatin', time: '09:00 PM', dose: '20mg', taken: false }
                ],
                vaccinationReminders: [
                    { id: 1, name: 'Annual Blood Work', date: 'Overdue', type: 'overdue' },
                    { id: 2, name: 'Flu Shot', date: 'Oct 15, 2026', type: 'upcoming' }
                ],
                healthGoals: ["Improve sleep consistency", "Increase morning hydration", "Maintain step count > 8k"],
                healthTopicsCompleted: parseInt(localStorage.getItem('guest_healthTopicsCompleted') || '0'),
                aiQuestionsAnswered: parseInt(localStorage.getItem('guest_aiQuestionsAnswered') || '0'),
                surveySubmissions: parseInt(localStorage.getItem('guest_surveySubmissions') || '0')
            };

            users.push(newUser);
            localStorage.setItem('sehatsathi_all_users', JSON.stringify(users));
            this.currentUser = newUser;
            localStorage.setItem('sehatsathi_current_user', JSON.stringify(newUser));

            // Firestore Sync
            if (window.firestoreDb) {
                window.firestoreDb.collection('users').doc(newUser.uid).set(newUser).catch(err => console.warn(err));
            }

            this.updateProfileUI();
            this.refreshPageMetrics();
            return true;
        },

        login(email, password) {
            let users = JSON.parse(localStorage.getItem('sehatsathi_all_users') || '[]');
            const user = users.find(u => u.email === email && u.password === password);
            if (!user) {
                alert("Invalid email or password.");
                return false;
            }
            this.currentUser = user;
            localStorage.setItem('sehatsathi_current_user', JSON.stringify(user));

            // Firestore Sync
            if (window.firestoreDb) {
                window.firestoreDb.collection('users').doc(user.uid).get().then(doc => {
                    if (doc.exists) {
                        this.currentUser = { ...this.currentUser, ...doc.data() };
                        localStorage.setItem('sehatsathi_current_user', JSON.stringify(this.currentUser));
                        this.updateProfileUI();
                        this.refreshPageMetrics();
                    }
                }).catch(err => console.warn(err));
            }

            this.updateProfileUI();
            this.refreshPageMetrics();
            return true;
        },

        googleLogin() {
            // Mock Google Login
            let users = JSON.parse(localStorage.getItem('sehatsathi_all_users') || '[]');
            let rahul = users.find(u => u.email === 'rahul@gmail.com');
            if (!rahul) {
                this.register("Rahul Kumar", "rahul@gmail.com", "google123", "28", "B+");
            } else {
                this.currentUser = rahul;
                localStorage.setItem('sehatsathi_current_user', JSON.stringify(rahul));
                this.updateProfileUI();
                this.refreshPageMetrics();
            }
            return true;
        },

        logout() {
            this.currentUser = null;
            localStorage.removeItem('sehatsathi_current_user');
            localStorage.removeItem('sehatsathi_guest_mode');
            this.updateProfileUI();
            window.location.href = isSubPage ? 'auth.html' : 'pages/auth.html';
        },

        saveHealthData(data) {
            if (!this.currentUser) {
                // Save to guest storage
                for (let key in data) {
                    localStorage.setItem(`guest_${key}`, JSON.stringify(data[key]));
                }
                return;
            }

            this.currentUser = { ...this.currentUser, ...data };
            localStorage.setItem('sehatsathi_current_user', JSON.stringify(this.currentUser));

            // Update local users table
            let users = JSON.parse(localStorage.getItem('sehatsathi_all_users') || '[]');
            const idx = users.findIndex(u => u.uid === this.currentUser.uid);
            if (idx !== -1) {
                users[idx] = this.currentUser;
                localStorage.setItem('sehatsathi_all_users', JSON.stringify(users));
            }

            // Sync with Firestore
            if (window.firestoreDb) {
                window.firestoreDb.collection('users').doc(this.currentUser.uid).update(data).catch(err => console.warn(err));
            }
        },

        getHealthData() {
            if (this.currentUser) {
                return this.currentUser;
            }
            // Guest default fallbacks
            return {
                bmi: localStorage.getItem('guest_bmi') ? JSON.parse(localStorage.getItem('guest_bmi')) : "22.9",
                weight: localStorage.getItem('guest_weight') ? JSON.parse(localStorage.getItem('guest_weight')) : "70",
                height: localStorage.getItem('guest_height') ? JSON.parse(localStorage.getItem('guest_height')) : "175",
                waterIntake: localStorage.getItem('guest_waterIntake') ? JSON.parse(localStorage.getItem('guest_waterIntake')) : "1.8",
                sleepHours: localStorage.getItem('guest_sleepHours') ? JSON.parse(localStorage.getItem('guest_sleepHours')) : "7.25",
                medicineReminders: localStorage.getItem('guest_medicineReminders') ? JSON.parse(localStorage.getItem('guest_medicineReminders')) : [
                    { id: 1, name: 'Vitamin D3', time: '08:00 AM', dose: '1 Pill', taken: true },
                    { id: 2, name: 'Amoxicillin', time: '02:00 PM', dose: 'After food', taken: false },
                    { id: 3, name: 'Atorvastatin', time: '09:00 PM', dose: '20mg', taken: false }
                ],
                vaccinationReminders: localStorage.getItem('guest_vaccinationReminders') ? JSON.parse(localStorage.getItem('guest_vaccinationReminders')) : [
                    { id: 1, name: 'Annual Blood Work', date: 'Overdue (2 weeks ago)', type: 'overdue' },
                    { id: 2, name: 'Flu Shot', date: 'Oct 15, 2026', type: 'upcoming' }
                ],
                healthGoals: localStorage.getItem('guest_healthGoals') ? JSON.parse(localStorage.getItem('guest_healthGoals')) : ["Improve sleep consistency", "Increase morning hydration", "Maintain step count > 8k"],
                healthTopicsCompleted: parseInt(localStorage.getItem('guest_healthTopicsCompleted') || '0'),
                aiQuestionsAnswered: parseInt(localStorage.getItem('guest_aiQuestionsAnswered') || '0'),
                surveySubmissions: parseInt(localStorage.getItem('guest_surveySubmissions') || '0')
            };
        },

        updateProfileUI() {
            const nameEl = document.getElementById('user-profile-name');
            const subtextEl = document.getElementById('user-profile-subtext');
            const avatarContainer = document.getElementById('user-avatar-container');
            const profileBtn = document.getElementById('user-profile-btn');
            const guestMode = localStorage.getItem('sehatsathi_guest_mode') === 'true';
            const guestId = localStorage.getItem('sehatsathi_guest_id');

            if (guestMode && guestId) {
                if (nameEl) {
                    const guestName = localStorage.getItem('sehatsathi_guest_name') || 'Guest User';
                    nameEl.innerHTML = `${guestName} <span class="ml-1 text-[8px] bg-secondary-container/20 text-secondary-container px-1 py-0.5 rounded font-semibold inline-block align-middle">Guest Session</span>`;
                }
                if (subtextEl) {
                    subtextEl.textContent = `ID: ${guestId}`;
                }
                if (avatarContainer) {
                    avatarContainer.innerHTML = `<span class="material-symbols-outlined text-secondary-fixed text-[24px]">account_circle</span>`;
                }
                // Append settings/reset button inside profileBtn if not already present
                if (profileBtn && !document.getElementById('guest-reset-btn')) {
                    const resetBtn = document.createElement('button');
                    resetBtn.id = 'guest-reset-btn';
                    resetBtn.className = 'text-on-surface-variant hover:text-error p-2 rounded-lg hover:bg-white/5 transition-colors z-50';
                    resetBtn.title = 'Reset Guest Data';
                    resetBtn.innerHTML = '<span class="material-symbols-outlined text-[18px]">restart_alt</span>';
                    resetBtn.addEventListener('click', (e) => {
                        e.stopPropagation(); // Prevent triggering the profileBtn click
                        if (confirm("Reset Guest Data?\n\nThis will clear all locally saved health data and settings for this Guest Session. This action cannot be undone.")) {
                            localStorage.clear();
                            alert("Guest data has been reset successfully.");
                            window.location.href = isSubPage ? 'auth.html' : 'pages/auth.html';
                        }
                    });
                    profileBtn.appendChild(resetBtn);
                }
            } else if (this.currentUser) {
                const fullName = this.currentUser.name || 'User';
                if (nameEl) nameEl.textContent = `Hello, ${fullName.split(' ')[0]}`;
                if (subtextEl) subtextEl.textContent = 'Log Out';
                if (avatarContainer) {
                    const initials = fullName.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase();
                    avatarContainer.innerHTML = `<span class="font-bold text-secondary-fixed text-xs">${initials}</span>`;
                }
                const resetBtn = document.getElementById('guest-reset-btn');
                if (resetBtn) resetBtn.remove();
            } else {
                if (nameEl) nameEl.textContent = 'User';
                if (subtextEl) subtextEl.textContent = 'Sign In';
                if (avatarContainer) {
                    avatarContainer.innerHTML = `<span class="material-symbols-outlined text-on-surface text-[24px]">account_circle</span>`;
                }
                const resetBtn = document.getElementById('guest-reset-btn');
                if (resetBtn) resetBtn.remove();
            }
        },

        refreshPageMetrics() {
            // Disabled to prevent infinite page-reload loops.
        }
    };

    window.sehatSathiDB.init();

    // Redirect Gate Check
    const isLocalFile = window.location.protocol === 'file:';
    if (!isLocalFile && !pageName.includes('auth') && !window.sehatSathiDB.currentUser && localStorage.getItem('sehatsathi_guest_mode') !== 'true') {
        window.location.href = isSubPage ? 'auth.html' : 'pages/auth.html';
        return; // stop execution
    }

    // ==========================================
    // 1.5. LANGUAGE TOGGLE AND TRANSLATION SYSTEM
    // ==========================================
    const currentLang = localStorage.getItem('sehatsathi_lang') || 'en';

    const toggleLanguage = () => {
        const nextLang = currentLang === 'hi' ? 'en' : 'hi';
        localStorage.setItem('sehatsathi_lang', nextLang);
        window.location.reload();
    };

    document.addEventListener('click', (e) => {
        if (e.target.closest('#lang-switch-mobile') || e.target.closest('#lang-switch-desktop') || e.target.closest('#lang-switch-header')) {
            toggleLanguage();
        }
    });

    // Global Translation Engine
    const translatePage = () => {
        const dict = window.sehatSathiTranslations ? window.sehatSathiTranslations[currentLang] : null;
        if (!dict) return;

        // 1. Attribute data-translate translation
        const elements = document.querySelectorAll('[data-translate]');
        elements.forEach(el => {
            const key = el.getAttribute('data-translate');
            if (dict[key]) {
                const val = dict[key];
                if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
                    el.placeholder = val;
                } else {
                    el.innerHTML = val;
                }
            }
        });

        // 2. Translate Sidebar links
        const sidebarLinks = document.querySelectorAll('#sidebar-container a');
        sidebarLinks.forEach(link => {
            const textSpan = link.querySelector('.sidebar-text');
            if (textSpan) {
                const text = textSpan.textContent.trim();
                if (text === 'Home' || text === 'मुख्य पृष्ठ') textSpan.textContent = dict.nav_home;
                if (text === 'AI Assistant' || text === 'एआई सहायक' || text === 'AI Chat') textSpan.textContent = dict.nav_assistant;
                if (text === 'Library' || text === 'स्वास्थ्य पुस्तकालय' || text === 'Health Library') textSpan.textContent = dict.nav_library;
                if (text === 'Symptom Checker' || text === 'लक्षण जांचकर्ता') textSpan.textContent = dict.nav_symptom_checker;
                if (text === 'First Aid' || text === 'प्राथमिक चिकित्सा') textSpan.textContent = dict.nav_first_aid;
                if (text === 'Family Card' || text === 'पारिवारिक कार्ड' || text === 'Family Health Card') textSpan.textContent = dict.nav_family_card;
                if (text === 'Schemes' || text === 'सरकारी योजनाएं' || text === 'Government Schemes') textSpan.textContent = dict.nav_schemes;
                if (text === 'Community Survey' || text === 'सामुदायिक सर्वेक्षण') textSpan.textContent = dict.nav_community_survey;
                if (text === 'Impact' || text === 'हमारा प्रभाव' || text === 'Community Impact') textSpan.textContent = dict.nav_impact;
                if (text === 'Tools' || text === 'स्वास्थ्य उपकरण' || text === 'Health Tools') textSpan.textContent = dict.nav_tools;
                if (text === 'Feedback' || text === 'प्रतिक्रिया') textSpan.textContent = dict.nav_feedback;

                if (text === 'Emergency Support' || text === 'आपातकालीन सहायता' || text === 'Emergency') textSpan.textContent = currentLang === 'hi' ? 'आपातकालीन सहायता' : 'Emergency';
            }
        });

        // 3. Translate Mobile Bottom Navigation links
        const bottomNavSpans = document.querySelectorAll('div.md\\:hidden.fixed.bottom-0 span.text-\\[9px\\]');
        if (bottomNavSpans.length >= 4) {
            bottomNavSpans[0].textContent = dict.nav_home;
            bottomNavSpans[1].textContent = currentLang === 'hi' ? 'AI चैट' : 'AI Chat';
            bottomNavSpans[2].textContent = dict.nav_library;
            bottomNavSpans[3].textContent = dict.nav_tools;
        }

        // 4. Translate page-specific static contents
        if (pageName.includes('index') || pageName === '' || pageName === 'index.html') {
            const h1 = document.querySelector('main h1');
            if (h1) h1.innerHTML = dict.home_title;
            const p = document.querySelector('main p.font-body-lg');
            if (p) p.innerHTML = dict.home_desc;
            
            // Core features header
            const h2 = document.querySelector('main h2');
            if (h2) h2.innerHTML = dict.home_features;

            // Stats cards
            const statsLabels = document.querySelectorAll('main .font-label-md');
            statsLabels.forEach(label => {
                const text = label.textContent.trim();
                if (text.includes("TOTAL USERS") || text.includes("कुल उपयोगकर्ता")) label.textContent = dict.home_stat_users;
                if (text.includes("FAMILIES REACHED") || text.includes("लाभान्वित परिवार")) label.textContent = dict.home_stat_families;
                if (text.includes("TOPICS COMPLETED") || text.includes("पूरे किए गए विषय")) label.textContent = dict.home_stat_completed;
            });
        }
        if (pageName.includes('symptom-checker')) {
            const h2 = document.querySelector('main h2');
            if (h2) h2.innerHTML = dict.sc_title;
            const p = document.querySelector('main p.text-tertiary-fixed');
            if (p) p.innerHTML = dict.sc_desc;
        }
        if (pageName.includes('community-survey')) {
            const h1 = document.querySelector('main h1');
            if (h1) h1.innerHTML = dict.cs_title;
            const p = document.querySelector('main p.font-body-lg');
            if (p) p.innerHTML = dict.cs_desc;
        }
        if (pageName.includes('first-aid')) {
            const h1 = document.querySelector('main h1');
            if (h1) h1.innerHTML = dict.fa_title;
            const p = document.querySelector('main p.text-on-surface-variant');
            if (p) p.innerHTML = dict.fa_desc;
        }
        if (pageName.includes('govt-schemes')) {
            const h2 = document.querySelector('main h2.font-display-lg');
            if (h2) h2.innerHTML = dict.schemes_title;
            const p = document.querySelector('main p.text-on-surface-variant');
            if (p) p.innerHTML = dict.schemes_desc;

            // Finder tool
            const finderH3 = document.querySelector('main h3.font-title-md');
            if (finderH3) finderH3.innerHTML = dict.schemes_finder_title;

            // Finder select label elements
            const labels = document.querySelectorAll('main label.font-label-sm');
            if (labels.length >= 3) {
                labels[0].innerHTML = currentLang === 'hi' ? 'उम्र' : 'Age';
                labels[1].innerHTML = currentLang === 'hi' ? 'लिंग' : 'Gender';
                labels[2].innerHTML = currentLang === 'hi' ? 'वार्षिक आय' : 'Annual Income';
            }
            
            // Finder select option default placeholders
            const selectOptions = document.querySelectorAll('main select option');
            selectOptions.forEach(opt => {
                const t = opt.textContent.trim();
                if (t.includes("Select Age Group") || t.includes("आयु वर्ग चुनें")) opt.textContent = dict.schemes_filter_age;
                if (t.includes("All Genders") || t.includes("लिंग चुनें")) opt.textContent = dict.schemes_filter_gender;
                if (t.includes("Any Income") || t.includes("आय श्रेणी")) opt.textContent = dict.schemes_filter_income;
            });

            // Find schemes button
            const schBtn = document.querySelector('main button.bg-gradient-to-r');
            if (schBtn) schBtn.innerHTML = currentLang === 'hi' ? 'योजनाएं खोजें' : 'Find Schemes';
        }
        if (pageName.includes('family-card')) {
            const h1 = document.querySelector('main h1');
            if (h1) h1.innerHTML = dict.fc_title;
            const p = document.querySelector('main p.text-secondary\\/70');
            if (p) p.innerHTML = dict.fc_desc;

            // Previews and sidebars
            const previewH2 = document.querySelectorAll('main h2.text-xl');
            previewH2.forEach(h2 => {
                if (h2.textContent.includes("Form") || h2.textContent.includes("विवरण")) {
                    h2.textContent = dict.fc_form_personal;
                }
            });
        }
        if (pageName.includes('health-library')) {
            const h1 = document.querySelector('main h1');
            if (h1) h1.innerHTML = dict.lib_title;
            const p = document.querySelector('main p.text-on-surface-variant');
            if (p) p.innerHTML = dict.lib_desc;
        }
        if (pageName.includes('health-tools')) {
            const h1 = document.querySelector('main h1');
            if (h1) h1.innerHTML = dict.tools_title;
            const p = document.querySelector('main p.text-on-surface-variant');
            if (p) p.innerHTML = dict.tools_desc;

            // Tracker headers
            const trackerHeaders = document.querySelectorAll('main h3.font-title-md');
            trackerHeaders.forEach(th => {
                const text = th.textContent.trim();
                if (text.includes("BMI Calculator") || text.includes("बीएमआई")) th.textContent = dict.tools_bmi_title;
                if (text.includes("Water Intake Tracker") || text.includes("जल सेवन")) th.textContent = dict.tools_water_title;
                if (text.includes("Sleep Tracker") || text.includes("नींद ट्रैकर")) th.textContent = dict.tools_sleep_title;
                if (text.includes("Medicine Schedule") || text.includes("दवा अनुसूची")) th.textContent = dict.tools_med_title;
            });
        }
        if (pageName.includes('feedback')) {
            const h1 = document.querySelector('main h1');
            if (h1) h1.innerHTML = dict.fb_title;
            const p = document.querySelector('main p.text-on-surface-variant');
            if (p) p.innerHTML = dict.fb_desc;
            
            // Translate form labels and elements
            const ratingLabel = document.getElementById('fb-rating-label');
            if (ratingLabel) ratingLabel.textContent = dict.fb_q_rating;
            
            const goodText = document.getElementById('fb-good-text');
            if (goodText) goodText.textContent = dict.fb_opt_good;
            
            const notGoodText = document.getElementById('fb-not-good-text');
            if (notGoodText) notGoodText.textContent = dict.fb_opt_not_good;
            
            const suggestionsLabel = document.getElementById('fb-suggestions-label');
            if (suggestionsLabel) suggestionsLabel.textContent = dict.fb_q_suggestions;
            
            const suggestionsInput = document.getElementById('fb-suggestions-input');
            if (suggestionsInput) suggestionsInput.placeholder = dict.fb_placeholder_suggestions;
            
            const submitBtn = document.getElementById('fb-submit-btn');
            if (submitBtn) {
                const span = submitBtn.querySelector('span:not(.material-symbols-outlined)');
                if (span) span.textContent = dict.fb_btn_submit;
            }
            
            // Translate success state
            const successTitle = document.getElementById('fb-success-title');
            if (successTitle) successTitle.textContent = dict.fb_success_title;
            
            const successDesc = document.getElementById('fb-success-desc');
            if (successDesc) successDesc.textContent = dict.fb_success_desc;
            
            const resetBtn = document.getElementById('fb-reset-btn');
            if (resetBtn) {
                const span = resetBtn.querySelector('span:not(.material-symbols-outlined)');
                if (span) span.textContent = dict.fb_btn_reset;
            }
        }
        if (pageName.includes('impact-dashboard')) {
            const h1 = document.querySelector('main h1');
            if (h1) h1.innerHTML = dict.imp_title;
            const p = document.querySelector('main p.text-on-surface-variant');
            if (p) p.innerHTML = dict.imp_desc;
        }
    };

    // ==========================================
    // 2. RENDER TOP APP BAR (MOBILE NAVBAR)
    // ==========================================
    // ==========================================
    // 2. RENDER UNIFIED TOP HEADER
    // ==========================================
    const navbarContainer = document.getElementById('navbar-container');
    if (navbarContainer) {
        navbarContainer.className = "flex justify-between items-center px-6 py-3 border-b border-white/5 bg-[#14171d] fixed top-0 right-0 left-0 h-16 z-30 transition-all duration-300 ease-in-out";
        
        const isGuest = localStorage.getItem('sehatsathi_guest_mode') === 'true';
        const guestId = localStorage.getItem('sehatsathi_guest_id') || 'SSA-XXXXXX';
        const guestName = localStorage.getItem(`${guestId}_sehatsathi_guest_name`) || 'Guest User';
        const displayUser = isGuest ? guestName : (window.sehatSathiDB?.currentUser?.name || 'Guest User');
        const displaySub = isGuest ? `ID: ${guestId}` : 'Member';

        navbarContainer.innerHTML = `
            <!-- Left: Logo & Context -->
            <div class="flex items-center gap-3 cursor-pointer" onclick="window.location.href='${basePath}index.html'">
                <div class="w-9 h-9 rounded-xl bg-gradient-to-br from-secondary-container to-tertiary flex items-center justify-center shadow-[0_0_10px_rgba(0,241,254,0.2)] shrink-0">
                    <span class="material-symbols-outlined text-on-secondary-container text-[20px]" style="font-variation-settings: 'FILL' 1;">health_and_safety</span>
                </div>
                <span class="font-headline-lg-mobile text-[18px] font-bold text-secondary-fixed tracking-tight md:block hidden">SehatSaathi AI</span>
                <span class="font-headline-lg-mobile text-[16px] font-bold text-secondary-fixed tracking-tight md:hidden block">SehatSaathi</span>
            </div>

            <!-- Right: Action Buttons -->
            <div class="flex items-center gap-3 md:gap-4">
                <!-- Emergency SOS Button -->
                <button onclick="window.location.href='${basePath}pages/emergency.html'" class="bg-error text-on-error text-xs font-bold px-3 py-1.5 rounded-full flex items-center gap-1 hover:bg-error/90 active:scale-95 transition-all">
                    <span class="material-symbols-outlined text-[14px]">sos</span>
                    <span class="sm:inline hidden">Emergency SOS</span>
                </button>

                <!-- Language Switcher Toggle -->
                <button id="lang-switch-header" class="px-2.5 py-1.5 rounded-lg bg-white/5 border border-white/10 text-xs font-bold text-secondary-fixed hover:border-secondary-fixed/50 hover:bg-white/10 transition-all">
                    ${currentLang === 'hi' ? 'EN' : 'हिंदी'}
                </button>

                <!-- Settings Icon (Gemini Configuration) -->
                <button id="settings-key-btn" class="text-on-surface-variant hover:text-secondary-fixed transition-colors p-1.5 rounded-lg hover:bg-white/5 flex items-center justify-center" title="Gemini Settings">
                    <span class="material-symbols-outlined text-[20px]">settings</span>
                </button>

                <!-- User/Guest Session Details -->
                <div id="header-profile-btn" class="flex items-center gap-2.5 pl-3 border-l border-white/10 cursor-pointer hover:opacity-85 transition-opacity">
                    <div class="w-8 h-8 rounded-full bg-surface-container-high border border-white/10 flex items-center justify-center overflow-hidden shrink-0">
                        <span class="material-symbols-outlined text-on-surface text-[18px]">account_circle</span>
                    </div>
                    <div class="sm:flex hidden flex-col text-left">
                        <p class="text-xs font-bold text-on-surface leading-tight">${displayUser}</p>
                        <p class="text-[9px] text-on-surface-variant leading-none mt-0.5">${displaySub}</p>
                    </div>
                </div>

                <!-- Hamburger menu (Mobile Drawer Trigger) -->
                <button id="mobile-hamburger-trigger" class="md:hidden flex text-on-surface-variant hover:text-secondary-fixed transition-colors p-1.5 rounded-lg hover:bg-white/5" title="Open Menu">
                    <span class="material-symbols-outlined text-2xl">menu</span>
                </button>
            </div>
        `;
    }

    // ==========================================
    // 3. RENDER SIDE NAVIGATION (COLLAPSIBLE)
    // ==========================================
    const sidebarContainer = document.getElementById('sidebar-container');
    if (sidebarContainer) {
        sidebarContainer.className = "fixed left-0 top-0 h-full w-72 bg-background md:bg-surface-container-low/50 backdrop-blur-xl border-r border-white/5 shadow-2xl p-6 z-40 transform -translate-x-full md:translate-x-0 transition-transform duration-300 ease-in-out flex flex-col";

        const navItems = [
            { name: 'Home', icon: 'home', file: 'index.html', path: `${basePath}index.html` },
            { name: 'AI Assistant', icon: 'smart_toy', file: 'ai-assistant.html', path: `${basePath}pages/ai-assistant.html`, fill: true },
            { name: 'Health Library', icon: 'menu_book', file: 'health-library.html', path: `${basePath}pages/health-library.html` },
            { name: 'Symptom Checker', icon: 'medical_services', file: 'symptom-checker.html', path: `${basePath}pages/symptom-checker.html` },
            { name: 'First Aid', icon: 'medical_information', file: 'first-aid.html', path: `${basePath}pages/first-aid.html` },
            { name: 'Family Health Card', icon: 'badge', file: 'family-card.html', path: `${basePath}pages/family-card.html` },
            { name: 'Government Schemes', icon: 'description', file: 'govt-schemes.html', path: `${basePath}pages/govt-schemes.html` },
            { name: 'Community Survey', icon: 'assignment', file: 'community-survey.html', path: `${basePath}pages/community-survey.html` },
            { name: 'Community Impact', icon: 'groups', file: 'impact-dashboard.html', path: `${basePath}pages/impact-dashboard.html` },
            { name: 'Health Tools', icon: 'handyman', file: 'health-tools.html', path: `${basePath}pages/health-tools.html` },
            { name: 'Feedback', icon: 'feedback', file: 'feedback.html', path: `${basePath}pages/feedback.html` }
        ];

        let navLinksHtml = '';
        navItems.forEach(item => {
            const isActive = pageName.includes(item.file.replace('.html', ''));
            const activeClass = isActive ? 'nav-item-active font-bold' : 'text-on-surface-variant hover:text-on-surface hover:bg-white/10';
            const iconFill = isActive || item.fill ? "style=\"font-variation-settings: 'FILL' 1;\"" : "";

            navLinksHtml += `
                <a class="flex items-center gap-3 px-4 py-3 transition-all duration-200 rounded-xl ${activeClass}" href="${item.path}">
                    <span class="material-symbols-outlined" ${iconFill}>${item.icon}</span>
                    <span class="font-label-md text-label-md sidebar-text">${item.name}</span>
                </a>
            `;
        });

        const isEmergencyActive = pageName === 'emergency.html';
        const emergencyClass = isEmergencyActive ? 'bg-error/30 text-error font-bold border border-error/50' : 'text-error hover:bg-error/10 border border-transparent';

        sidebarContainer.innerHTML = `
            <!-- Brand Header -->
            <div class="flex items-center justify-between mb-8 px-2 mt-16 md:mt-0 brand-header">
                <div class="flex items-center gap-3">
                    <div class="w-10 h-10 rounded-xl bg-gradient-to-br from-secondary-container to-tertiary flex items-center justify-center shadow-[0_0_15px_rgba(0,241,254,0.3)] shrink-0">
                        <span class="material-symbols-outlined text-on-secondary-container" style="font-variation-settings: 'FILL' 1;">health_and_safety</span>
                    </div>
                    <div class="sidebar-text flex flex-col">
                        <h1 class="font-headline-lg text-headline-lg text-secondary-container text-[18px] leading-tight font-bold">SehatSaathi</h1>
                        <p class="font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider text-[10px]">Community Platform</p>
                    </div>
                </div>
                <!-- Toggle Button (desktop only) -->
                <button id="desktop-sidebar-toggle" class="hidden md:flex text-on-surface-variant hover:text-secondary-fixed transition-colors p-2 rounded-lg hover:bg-white/5 shrink-0" title="Toggle Sidebar">
                    <span id="toggle-icon-dir" class="material-symbols-outlined">menu</span>
                </button>
            </div>
            
            <!-- Navigation Links -->
            <div class="flex-1 space-y-1">
                ${navLinksHtml}
                <div class="my-4 border-t border-white/5"></div>
                <a class="flex items-center gap-3 px-4 py-3 transition-all duration-200 rounded-xl group ${emergencyClass}" href="${basePath}pages/emergency.html">
                    <span class="material-symbols-outlined group-hover:animate-pulse">emergency</span>
                    <span class="font-label-md text-label-md sidebar-text">Emergency</span>
                </a>
            </div>

            <!-- Language Switcher (Desktop) -->
            <div class="px-2 py-4 border-t border-white/5 flex items-center justify-between brand-header">
                <span class="text-xs text-on-surface-variant font-medium flex items-center gap-1.5 sidebar-text">
                    <span class="material-symbols-outlined text-[16px]">language</span> Language / भाषा
                </span>
                <button id="lang-switch-desktop" class="px-3 py-1.5 rounded-lg bg-surface-container border border-white/10 text-xs font-bold text-secondary-fixed hover:border-secondary-fixed/50 hover:bg-white/5 transition-all">
                    ${currentLang === 'hi' ? 'English' : 'हिंदी'}
                </button>
            </div>
            
            <!-- User Profile Area -->
            <div id="user-profile-btn" class="pt-4 border-t border-white/5 flex items-center justify-between cursor-pointer hover:bg-white/5 rounded-xl p-2 transition-all">
                <div class="flex items-center gap-3 group flex-1">
                    <div id="user-avatar-container" class="w-10 h-10 rounded-full bg-surface-container-high border border-white/10 flex items-center justify-center overflow-hidden group-hover:border-secondary-fixed transition-colors shrink-0">
                        <span class="material-symbols-outlined text-on-surface text-[24px]">account_circle</span>
                    </div>
                    <div class="user-details flex flex-col">
                        <p id="user-profile-name" class="font-label-md text-label-md text-on-surface group-hover:text-secondary-fixed transition-colors">User</p>
                        <p id="user-profile-subtext" class="text-[10px] text-on-surface-variant group-hover:text-secondary-fixed/80 transition-colors">Sign In</p>
                    </div>
                </div>
            </div>
        `;

        window.sehatSathiDB.updateProfileUI();

        // Render Mobile Bottom Navigation Bar (Hidden on desktop)
        const mobileBottomNav = document.createElement('div');
        mobileBottomNav.className = "md:hidden fixed bottom-0 left-0 right-0 h-14 bg-[#14171d] border-t border-white/5 flex justify-around items-center z-50 px-2 backdrop-blur-xl shadow-lg";
        mobileBottomNav.innerHTML = `
            <a href="${basePath}index.html" class="flex flex-col items-center gap-0.5 text-on-surface-variant hover:text-accent transition-colors">
                <span class="material-symbols-outlined text-[18px]">home</span>
                <span class="text-[9px] font-semibold">Home</span>
            </a>
            <a href="${basePath}pages/ai-assistant.html" class="flex flex-col items-center gap-0.5 text-on-surface-variant hover:text-accent transition-colors">
                <span class="material-symbols-outlined text-[18px]" style="font-variation-settings: 'FILL' 1;">smart_toy</span>
                <span class="text-[9px] font-semibold">AI Chat</span>
            </a>
            <a href="${basePath}pages/health-library.html" class="flex flex-col items-center gap-0.5 text-on-surface-variant hover:text-accent transition-colors">
                <span class="material-symbols-outlined text-[18px]">menu_book</span>
                <span class="text-[9px] font-semibold">Library</span>
            </a>
            <a href="${basePath}pages/health-tools.html" class="flex flex-col items-center gap-0.5 text-on-surface-variant hover:text-accent transition-colors">
                <span class="material-symbols-outlined text-[18px]">handyman</span>
                <span class="text-[9px] font-semibold">Tools</span>
            </a>
            <button id="mobile-hamburger-trigger" class="flex flex-col items-center gap-0.5 text-on-surface-variant hover:text-accent transition-colors">
                <span class="material-symbols-outlined text-[18px]">menu</span>
                <span class="text-[9px] font-semibold">Menu</span>
            </button>
        `;
        document.body.appendChild(mobileBottomNav);

        // Inject Sidebar Overlay (for mobile drawer closure)
        let overlay = document.getElementById('sidebar-overlay');
        if (!overlay) {
            overlay = document.createElement('div');
            overlay.id = 'sidebar-overlay';
            document.body.appendChild(overlay);
            overlay.addEventListener('click', () => {
                sidebarContainer.classList.add('-translate-x-full');
                document.body.classList.remove('mobile-sidebar-open');
            });
        }

        // Bind hamburger trigger click
        document.addEventListener('click', (e) => {
            const trigger = e.target.closest('#mobile-hamburger-trigger');
            if (trigger) {
                const isOpen = sidebarContainer.classList.toggle('-translate-x-full');
                document.body.classList.toggle('mobile-sidebar-open', !isOpen);
            }
        });

        // Initialize Collapsed State from localStorage
        const isCollapsed = localStorage.getItem('sidebar-collapsed') === 'true';
        if (isCollapsed) {
            document.body.classList.add('sidebar-collapsed');
        }

        // Setup Toggle Listeners (Desktop Collapse / Expand)
        const toggleSidebar = () => {
            document.body.classList.toggle('sidebar-collapsed');
            const collapsedNow = document.body.classList.contains('sidebar-collapsed');
            localStorage.setItem('sidebar-collapsed', collapsedNow);
        };

        const desktopToggle = document.getElementById('desktop-sidebar-toggle');
        if (desktopToggle) {
            desktopToggle.addEventListener('click', toggleSidebar);
        }

        // Hamburger listener
        document.addEventListener('click', (e) => {
            const btn = e.target.closest('#sidebar-hamburger-toggle');
            if (btn) {
                if (window.innerWidth >= 768) {
                    toggleSidebar();
                } else {
                    const isOpen = sidebarContainer.classList.toggle('-translate-x-full');
                    document.body.classList.toggle('mobile-sidebar-open', !isOpen);
                }
            }
        });

        // Click handler for login / logout / guest exit
        const profileBtn = document.getElementById('user-profile-btn');
        if (profileBtn) {
            profileBtn.addEventListener('click', () => {
                const guestMode = localStorage.getItem('sehatsathi_guest_mode') === 'true';
                const guestId = localStorage.getItem('sehatsathi_guest_id');

                if (guestMode && guestId) {
                    if (confirm("Would you like to exit your Guest Session? Your health data will remain saved on this device.")) {
                        window.sehatSathiDB.logout();
                    }
                } else if (window.sehatSathiDB.currentUser) {
                    if (confirm("Would you like to log out of your account?")) {
                        window.sehatSathiDB.logout();
                    }
                } else {
                    const loginModal = document.getElementById('login-modal');
                    if (loginModal) {
                        loginModal.classList.remove('opacity-0', 'pointer-events-none');
                    }
                }
            });
        }
    }

    // ==========================================
    // 4.5. INJECT API SETTINGS MODAL & TRIGGERS
    // ==========================================
    let apiModal = document.getElementById('api-modal');
    if (!apiModal) {
        apiModal = document.createElement('div');
        apiModal.id = 'api-modal';
        apiModal.className = "fixed inset-0 bg-black/75 backdrop-blur-md z-50 flex items-center justify-center opacity-0 pointer-events-none transition-opacity duration-300";
        apiModal.innerHTML = `
            <div class="glass-panel p-6 rounded-3xl border border-white/10 max-w-md w-full mx-4 shadow-2xl relative bg-[#131315]">
                <button id="close-api-modal-btn" class="absolute top-4 right-4 text-on-surface-variant hover:text-white transition-colors">
                    <span class="material-symbols-outlined">close</span>
                </button>
                <div class="flex flex-col">
                    <h3 class="text-title-md text-white font-bold mb-2 flex items-center gap-2">
                        <span class="material-symbols-outlined text-secondary-fixed">key</span>
                        Gemini API Settings
                    </h3>
                    <p class="text-xs text-on-surface-variant mb-4">Enter your Gemini API key to allow the assistant to answer questions beyond the offline local database.</p>
                    <input type="text" id="api-key-input-global" class="w-full px-4 py-3 rounded-xl bg-surface-container border border-white/15 text-white placeholder-on-surface-variant/40 mb-4 focus:outline-none focus:border-secondary-fixed/50" placeholder="AIzaSy...">
                    <button id="save-api-btn-global" class="w-full py-3 rounded-xl bg-gradient-to-r from-secondary-container to-tertiary text-on-secondary-container font-semibold hover:shadow-[0_0_15px_rgba(0,241,254,0.4)] transition-all">Save API Key</button>
                </div>
            </div>
        `;
        document.body.appendChild(apiModal);
    }

    // Dynamic key getter/setter helper
    const syncApiKeyInput = () => {
        const savedKey = localStorage.getItem('GEMINI_API_KEY') || '';
        const inputEl = document.getElementById('api-key-input-global') || document.getElementById('api-key-input');
        if (inputEl) inputEl.value = savedKey;
    };
    syncApiKeyInput();

    // Listen to click events on both old and new save buttons
    const bindSaveBtn = () => {
        const btn = document.getElementById('save-api-btn-global') || document.getElementById('save-api-btn');
        if (btn) {
            // Remove previous event listener references if any, then add
            btn.onclick = () => {
                const inputEl = document.getElementById('api-key-input-global') || document.getElementById('api-key-input');
                const key = inputEl ? inputEl.value.trim() : '';
                localStorage.setItem('GEMINI_API_KEY', key);
                if (apiModal) apiModal.classList.add('opacity-0', 'pointer-events-none');
                alert(localStorage.getItem('sehatsathi_lang') === 'hi' ? "Gemini API कुंजी सफलतापूर्वक सहेज ली गई है।" : "Gemini API key saved successfully.");
            };
        }
    };
    bindSaveBtn();

    // Listen to click events on both old and new close buttons
    const bindCloseBtn = () => {
        const closeBtn = document.getElementById('close-api-modal-btn') || document.getElementById('close-modal-btn');
        if (closeBtn) {
            closeBtn.onclick = () => {
                if (apiModal) apiModal.classList.add('opacity-0', 'pointer-events-none');
            };
        }
    };
    bindCloseBtn();

    if (apiModal) {
        apiModal.addEventListener('click', (e) => {
            if (e.target === apiModal) apiModal.classList.add('opacity-0', 'pointer-events-none');
        });
    }

    document.addEventListener('click', (e) => {
        if (e.target.closest('#settings-key-btn') || e.target.closest('#api-settings-btn')) {
            const modal = document.getElementById('api-modal');
            if (modal) {
                syncApiKeyInput();
                bindSaveBtn(); // Ensure bindings are active
                bindCloseBtn();
                modal.classList.remove('opacity-0', 'pointer-events-none');
            }
        }
        if (e.target.closest('#header-profile-btn')) {
            const guestMode = localStorage.getItem('sehatsathi_guest_mode') === 'true';
            const guestId = localStorage.getItem('sehatsathi_guest_id');
            if (guestMode && guestId) {
                if (confirm("Would you like to exit your Guest Session? Your health data will remain saved on this device.")) {
                    window.sehatSathiDB.logout();
                }
            } else if (window.sehatSathiDB?.currentUser) {
                if (confirm("Would you like to log out of your account?")) {
                    window.sehatSathiDB.logout();
                }
            } else {
                const loginModal = document.getElementById('login-modal');
                if (loginModal) {
                    loginModal.classList.remove('opacity-0', 'pointer-events-none');
                }
            }
        }
    });

    // ==========================================
    // 4. INJECT LOGIN MODAL & AUTH CONTROLS
    // ==========================================
    let loginModal = document.getElementById('login-modal');
    if (!loginModal) {
        loginModal = document.createElement('div');
        loginModal.id = 'login-modal';
        loginModal.className = "fixed inset-0 bg-black/75 backdrop-blur-md z-50 flex items-center justify-center opacity-0 pointer-events-none transition-opacity duration-300";
        loginModal.innerHTML = `
            <div class="glass-panel p-6 rounded-3xl border border-white/10 max-w-md w-full mx-4 shadow-2xl relative bg-[#131315]">
                <button id="close-login-btn" class="absolute top-4 right-4 text-on-surface-variant hover:text-white transition-colors">
                    <span class="material-symbols-outlined">close</span>
                </button>
                
                <div id="login-view" class="flex flex-col">
                    <h3 class="text-title-md text-white font-bold mb-2 flex items-center gap-2">
                        <span class="material-symbols-outlined text-secondary-fixed">health_and_safety</span>
                        Access SehatSaathi AI
                    </h3>
                    <p class="text-xs text-on-surface-variant mb-6">Join our community healthcare platform to track health metrics and ask AI.</p>
                    
                    <button id="google-login-btn" class="flex items-center justify-center gap-3 w-full py-3 rounded-xl bg-white text-black font-semibold hover:bg-white/90 transition-all mb-4">
                        <svg class="w-5 h-5" viewBox="0 0 24 24"><path fill="#EA4335" d="M12.24 10.285V14.4h6.887C18.2 16.614 15.645 18 12.24 18c-3.86 0-7-3.14-7-7s3.14-7 7-7c1.7 0 3.3.6 4.6 1.7l3.1-3.1C17.9 1.1 15.1 0 12.24 0 6.04 0 1 5.04 1 11.24S6.04 22.48 12.24 22.48c5.8 0 10.76-4.14 10.76-11.24 0-.69-.06-1.35-.18-1.95H12.24z"/></svg>
                        Continue with Google
                    </button>
                    
                    <div class="flex items-center my-4">
                        <hr class="flex-1 border-white/10">
                        <span class="px-3 text-xs text-on-surface-variant/50">or Email Login</span>
                        <hr class="flex-1 border-white/10">
                    </div>
                    
                    <input type="email" id="login-email" class="w-full px-4 py-3 rounded-xl bg-surface-container border border-white/15 text-white placeholder-on-surface-variant/40 mb-3 focus:outline-none focus:border-secondary-fixed/50" placeholder="Email Address">
                    <input type="password" id="login-password" class="w-full px-4 py-3 rounded-xl bg-surface-container border border-white/15 text-white placeholder-on-surface-variant/40 mb-4 focus:outline-none focus:border-secondary-fixed/50" placeholder="Password">
                    
                    <button id="email-login-btn" class="w-full py-3 rounded-xl bg-gradient-to-r from-secondary-container to-tertiary text-on-secondary-container font-semibold hover:shadow-[0_0_15px_rgba(0,241,254,0.4)] transition-all mb-4">Log In</button>
                    
                    <p class="text-center text-xs text-on-surface-variant">Don't have an account? <a href="#" id="toggle-signup" class="text-secondary-fixed hover:underline font-bold">Sign Up</a></p>
                </div>
                
                <div id="signup-view" class="flex flex-col hidden">
                    <h3 class="text-title-md text-white font-bold mb-2 flex items-center gap-2">
                        <span class="material-symbols-outlined text-secondary-fixed">person_add</span>
                        Create Health Profile
                    </h3>
                    <p class="text-xs text-on-surface-variant mb-4">Set up your community health card today.</p>
                    
                    <input type="text" id="signup-name" class="w-full px-4 py-2.5 rounded-xl bg-surface-container border border-white/15 text-white placeholder-on-surface-variant/40 mb-3 focus:outline-none focus:border-secondary-fixed/50" placeholder="Full Name">
                    <input type="email" id="signup-email" class="w-full px-4 py-2.5 rounded-xl bg-surface-container border border-white/15 text-white placeholder-on-surface-variant/40 mb-3 focus:outline-none focus:border-secondary-fixed/50" placeholder="Email Address">
                    <input type="password" id="signup-password" class="w-full px-4 py-2.5 rounded-xl bg-surface-container border border-white/15 text-white placeholder-on-surface-variant/40 mb-3 focus:outline-none focus:border-secondary-fixed/50" placeholder="Password">
                    
                    <div class="grid grid-cols-2 gap-3 mb-4">
                        <input type="number" id="signup-age" class="px-4 py-2.5 rounded-xl bg-surface-container border border-white/15 text-white placeholder-on-surface-variant/40 focus:outline-none focus:border-secondary-fixed/50" placeholder="Age">
                        <select id="signup-blood" class="px-4 py-2.5 rounded-xl bg-surface-container border border-white/15 text-white placeholder-on-surface-variant/40 focus:outline-none focus:border-secondary-fixed/50">
                            <option value="">Blood Group</option>
                            <option value="A+">A+</option>
                            <option value="A-">A-</option>
                            <option value="B+">B+</option>
                            <option value="B-">B-</option>
                            <option value="AB+">AB+</option>
                            <option value="AB-">AB-</option>
                            <option value="O+">O+</option>
                            <option value="O-">O-</option>
                        </select>
                    </div>
                    
                    <button id="email-signup-btn" class="w-full py-3 rounded-xl bg-gradient-to-r from-secondary-container to-tertiary text-on-secondary-container font-semibold hover:shadow-[0_0_15px_rgba(0,241,254,0.4)] transition-all mb-4">Register Account</button>
                    
                    <p class="text-center text-xs text-on-surface-variant">Already have an account? <a href="#" id="toggle-login" class="text-secondary-fixed hover:underline font-bold">Log In</a></p>
                </div>
            </div>
        `;
        document.body.appendChild(loginModal);

        // Add event listeners for Login Modal View Toggling & Login triggers
        const closeBtn = document.getElementById('close-login-btn');
        const toggleSignup = document.getElementById('toggle-signup');
        const toggleLogin = document.getElementById('toggle-login');
        const loginView = document.getElementById('login-view');
        const signupView = document.getElementById('signup-view');

        const closeModal = () => loginModal.classList.add('opacity-0', 'pointer-events-none');
        if (closeBtn) closeBtn.addEventListener('click', closeModal);
        loginModal.addEventListener('click', (e) => { if (e.target === loginModal) closeModal(); });

        if (toggleSignup) {
            toggleSignup.addEventListener('click', (e) => {
                e.preventDefault();
                loginView.classList.add('hidden');
                signupView.classList.remove('hidden');
            });
        }
        if (toggleLogin) {
            toggleLogin.addEventListener('click', (e) => {
                e.preventDefault();
                signupView.classList.add('hidden');
                loginView.classList.remove('hidden');
            });
        }

        // Action Handlers
        document.getElementById('google-login-btn').addEventListener('click', () => {
            window.sehatSathiDB.googleLogin();
            closeModal();
        });

        document.getElementById('email-login-btn').addEventListener('click', () => {
            const email = document.getElementById('login-email').value.trim();
            const pass = document.getElementById('login-password').value.trim();
            if (email && pass) {
                if (window.sehatSathiDB.login(email, pass)) {
                    closeModal();
                }
            } else {
                alert("Please fill in all credentials.");
            }
        });

        document.getElementById('email-signup-btn').addEventListener('click', () => {
            const name = document.getElementById('signup-name').value.trim();
            const email = document.getElementById('signup-email').value.trim();
            const pass = document.getElementById('signup-password').value.trim();
            const age = document.getElementById('signup-age').value.trim();
            const blood = document.getElementById('signup-blood').value;
            
            if (name && email && pass && age && blood) {
                if (window.sehatSathiDB.register(name, email, pass, age, blood)) {
                    closeModal();
                }
            } else {
                alert("Please fill in all inputs.");
            }
        });
    }

    // ==========================================
    // 5. GLOBAL RESPONSIVE MOBILE NAVIGATION PANEL TRIGGER
    // ==========================================
    const toggleBtn = document.getElementById('mobile-menu-toggle');
    if (toggleBtn && sidebarContainer) {
        let overlay = document.getElementById('sidebar-overlay');
        if (!overlay) {
            overlay = document.createElement('div');
            overlay.id = 'sidebar-overlay';
            document.body.appendChild(overlay);
        }

        const closeMobileSidebar = () => {
            sidebarContainer.classList.add('-translate-x-full');
            document.body.classList.remove('mobile-sidebar-open');
        };

        toggleBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            const isOpen = sidebarContainer.classList.toggle('-translate-x-full');
            document.body.classList.toggle('mobile-sidebar-open', !isOpen);
        });

        document.addEventListener('click', (e) => {
            if (!sidebarContainer.contains(e.target) && !toggleBtn.contains(e.target)) {
                closeMobileSidebar();
            }
        });

        overlay.addEventListener('click', () => {
            closeMobileSidebar();
        });
    }

    // ==========================================
    // 6. DYNAMIC MARK AS READ IN HEALTH LIBRARY
    // ==========================================
    // Legacy Mark as Read button appending block removed to prevent duplicate buttons in dynamic health library.

    // ==========================================
    // 7. PAGE INTERACTIONS: AI CHAT ASSISTANT
    // ==========================================
    if (pageName.includes('ai-assistant')) {
        const sendBtn = document.getElementById('send-message-btn');
        const textarea = document.getElementById('chat-textarea');
        const chatContainer = document.getElementById('chat-messages');
        const voiceBtn = document.getElementById('voice-input-btn');
        const langEnBtn = document.getElementById('lang-en');
        const langHiBtn = document.getElementById('lang-hi');

        // Modal Controls
        const apiSettingsBtn = document.getElementById('api-settings-btn');
        const apiModal = document.getElementById('api-modal');
        const apiInput = document.getElementById('api-key-input');
        const saveApiBtn = document.getElementById('save-api-btn');
        const closeModalBtn = document.getElementById('close-modal-btn');

        let currentLang = localStorage.getItem('sehatsathi_lang') || 'en';
        let currentUtterance = null;

        if (apiInput && localStorage.getItem('GEMINI_API_KEY')) {
            apiInput.value = localStorage.getItem('GEMINI_API_KEY');
        }

        // Inline API Key Prompt on page load if not configured
        const existingKey = localStorage.getItem('GEMINI_API_KEY');
        if (!existingKey && chatContainer) {
            const isHi = currentLang === 'hi';
            const inlinePromptHtml = `
                <div id="inline-api-prompt" class="flex items-start gap-4 max-w-[85%] animate-fade-in-up mt-4">
                    <div class="w-10 h-10 rounded-full bg-gradient-to-br from-secondary-container to-tertiary flex items-center justify-center shrink-0 shadow-[0_0_10px_rgba(0,241,254,0.2)]">
                        <span class="material-symbols-outlined text-on-secondary-container">smart_toy</span>
                    </div>
                    <div class="glass-panel p-5 rounded-2xl rounded-tl-sm border border-secondary-fixed/30 hover:border-secondary-fixed/50 transition-all flex flex-col gap-3 flex-1">
                        <p class="font-body-md text-sm md:text-[15px] text-on-surface">
                            ${isHi 
                                ? "ऑनलाइन एआई सहायक को सक्रिय करने के लिए कृपया अपनी <strong>Gemini API Key</strong> नीचे दर्ज करें। (आप इसे बाद में ऊपर दाईं ओर दिए गए सेटिंग्स गियर आइकन से भी बदल सकते हैं):" 
                                : "To activate the Online AI Assistant, please enter your <strong>Gemini API Key</strong> below. (You can also configure/change this later using the settings gear icon in the top right corner):"}
                        </p>
                        <div class="flex flex-col sm:flex-row gap-2 mt-1">
                            <input type="password" id="inline-api-key-input" placeholder="${isHi ? 'यहाँ कुंजी दर्ज करें (AIzaSy...)' : 'Enter key here (AIzaSy...)'}" class="bg-surface-container/50 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-on-surface focus:outline-none focus:border-secondary-fixed/50 w-full" />
                            <button id="inline-save-api-btn" class="bg-secondary-container text-on-secondary-container font-bold text-sm px-5 py-2.5 rounded-xl hover:bg-secondary-container/85 transition-all shrink-0">
                                ${isHi ? "सहेजें और सक्षम करें" : "Save & Enable"}
                            </button>
                        </div>
                    </div>
                </div>
            `;
            chatContainer.insertAdjacentHTML('beforeend', inlinePromptHtml);
            chatContainer.scrollTop = chatContainer.scrollHeight;

            const inlineInput = document.getElementById('inline-api-key-input');
            const inlineBtn = document.getElementById('inline-save-api-btn');
            if (inlineInput && inlineBtn) {
                inlineBtn.addEventListener('click', () => {
                    const key = inlineInput.value.trim();
                    if (key) {
                        localStorage.setItem('GEMINI_API_KEY', key);
                        if (apiInput) apiInput.value = key;
                        
                        const promptEl = document.getElementById('inline-api-prompt');
                        if (promptEl) promptEl.remove();

                        const successMsgHtml = `
                            <div class="flex items-start gap-4 max-w-[85%] animate-fade-in-up">
                                <div class="w-10 h-10 rounded-full bg-gradient-to-br from-secondary-container to-tertiary flex items-center justify-center shrink-0 shadow-[0_0_10px_rgba(0,241,254,0.2)]">
                                    <span class="material-symbols-outlined text-on-secondary-container">smart_toy</span>
                                </div>
                                <div class="glass-panel p-4 rounded-2xl rounded-tl-sm text-on-surface">
                                    <p class="font-body-md text-sm md:text-[15px]">
                                        ${isHi 
                                            ? "✅ मिथुन (Gemini) एपीआई कुंजी सफलतापूर्वक सहेज ली गई है! अब आप कोई भी स्वास्थ्य संबंधी प्रश्न पूछ सकते हैं।" 
                                            : "✅ Gemini API key saved successfully! You can now ask any health questions."}
                                    </p>
                                </div>
                            </div>
                        `;
                        chatContainer.insertAdjacentHTML('beforeend', successMsgHtml);
                        chatContainer.scrollTop = chatContainer.scrollHeight;
                    } else {
                        alert(isHi ? "कृपया एक वैध कुंजी दर्ज करें।" : "Please enter a valid key.");
                    }
                });
            }
        }

        if (apiSettingsBtn && apiModal && closeModalBtn && saveApiBtn) {
            apiSettingsBtn.addEventListener('click', () => {
                apiModal.classList.remove('opacity-0', 'pointer-events-none');
            });
            const closeModalWin = () => apiModal.classList.add('opacity-0', 'pointer-events-none');
            closeModalBtn.addEventListener('click', closeModalWin);
            apiModal.addEventListener('click', (e) => { if (e.target === apiModal) closeModalWin(); });
            saveApiBtn.addEventListener('click', () => {
                const key = apiInput ? apiInput.value.trim() : '';
                localStorage.setItem('GEMINI_API_KEY', key);
                closeModalWin();
                addSystemMessage(
                    currentLang === 'en' 
                    ? "Gemini API key saved successfully." 
                    : "मिथुन (Gemini) एपीआई कुंजी सफलतापूर्वक सहेज ली गई है।"
                );
            });
        }

        const speakText = (text, langCode) => {
            if (window.speechSynthesis.speaking) {
                window.speechSynthesis.cancel();
                if (currentUtterance && currentUtterance.text === text) {
                    currentUtterance = null;
                    return;
                }
            }
            const cleanText = text.replace(/[*#•]/g, '').trim();
            const utterance = new SpeechSynthesisUtterance(cleanText);
            utterance.lang = langCode === 'hi' ? 'hi-IN' : 'en-US';
            currentUtterance = utterance;
            window.speechSynthesis.speak(utterance);
        };

        if (textarea) {
            textarea.addEventListener('input', () => {
                textarea.style.height = '';
                textarea.style.height = textarea.scrollHeight + 'px';
            });
        }

        window.triggerQuickSearch = (text) => {
            if (textarea) {
                textarea.value = text;
                textarea.dispatchEvent(new Event('input'));
                handleSend();
            }
        };

        const setupChipListeners = () => {
            const chips = document.querySelectorAll('#quick-chips button, #greeting-chips button');
            chips.forEach(chip => {
                const newChip = chip.cloneNode(true);
                chip.parentNode.replaceChild(newChip, chip);
                
                newChip.addEventListener('click', () => {
                    const textSpan = newChip.querySelector('.select-text-label') || newChip;
                    let text = textSpan.textContent.trim();
                    
                    if (text === "First Aid Guide" || text === "प्राथमिक उपचार गाइड") {
                        text = currentLang === 'en' ? "Show me First Aid for cuts" : "कट्स के लिए प्राथमिक उपचार दिखाएं";
                    } else if (text === "Nutrition Tips" || text === "पोषण युक्तियाँ") {
                        text = currentLang === 'en' ? "What is a healthy diet for nutrition?" : "पोषण के लिए स्वस्थ आहार क्या है?";
                    } else if (text === "Govt Health Schemes" || text === "सरकारी स्वास्थ्य योजनाएं") {
                        text = currentLang === 'en' ? "Tell me about PMJAY scheme" : "PMJAY योजना के बारे में बताएं";
                    } else if (text === "Symptom Checker" || text === "लक्षण जांचकर्ता") {
                        text = currentLang === 'en' ? "My child has fever symptoms" : "मेरे बच्चे को बुखार के लक्षण हैं";
                    }
                    
                    textarea.value = text;
                    textarea.dispatchEvent(new Event('input'));
                    handleSend();
                });
            });
        };

        const updateUIForLanguage = (lang) => {
            currentLang = lang;
            localStorage.setItem('sehatsathi_lang', lang);

            const disclaimer = document.getElementById('disclaimer-text');
            const greetingText = document.getElementById('bot-greeting-text');
            const warningText = document.getElementById('footer-warning-text');
            const quickChips = document.getElementById('quick-chips');
            const greetingChips = document.getElementById('greeting-chips');

            if (lang === 'hi') {
                if (disclaimer) disclaimer.textContent = "सेहतसाथी एआई केवल जानकारी प्रदान करता है, चिकित्सा निदान नहीं। गंभीर स्थितियों के लिए डॉक्टर से सलाह लें।";
                if (greetingText) greetingText.textContent = "नमस्ते! मैं सेहतसाथी हूँ, आपका व्यक्तिगत एआई स्वास्थ्य सहायक। आज मैं आपकी क्या मदद कर सकता हूँ? मैं निम्न में मदद कर सकता हूँ:";
                if (textarea) textarea.placeholder = "लक्षणों का वर्णन करें या स्वास्थ्य संबंधी प्रश्न पूछें...";
                if (warningText) warningText.textContent = "सेहतसाथी एआई गलतियां कर सकता है। हमेशा महत्वपूर्ण चिकित्सा जानकारी को सत्यापित करें।";
                
                if (langHiBtn) langHiBtn.className = "px-3 py-1.5 rounded-lg text-xs font-bold transition-all bg-secondary-container text-on-secondary-container";
                if (langEnBtn) langEnBtn.className = "px-3 py-1.5 rounded-lg text-xs font-bold transition-all text-on-surface-variant hover:text-white";

                if (greetingChips) {
                    greetingChips.innerHTML = `
                        <button class="flex items-center gap-2 p-2 rounded-lg bg-surface-container/50 border border-white/5 hover:border-secondary-fixed/50 hover:bg-secondary-fixed/5 transition-colors text-left chip-btn">
                            <span class="material-symbols-outlined text-secondary-fixed text-[18px]">medical_services</span>
                            <span class="font-semibold select-text-label">प्राथमिक उपचार गाइड</span>
                        </button>
                        <button class="flex items-center gap-2 p-2 rounded-lg bg-surface-container/50 border border-white/5 hover:border-secondary-fixed/50 hover:bg-secondary-fixed/5 transition-colors text-left chip-btn">
                            <span class="material-symbols-outlined text-tertiary-fixed text-[18px]">nutrition</span>
                            <span class="font-semibold select-text-label">पोषण युक्तियाँ</span>
                        </button>
                        <button class="flex items-center gap-2 p-2 rounded-lg bg-surface-container/50 border border-white/5 hover:border-secondary-fixed/50 hover:bg-secondary-fixed/5 transition-colors text-left chip-btn">
                            <span class="material-symbols-outlined text-primary text-[18px]">description</span>
                            <span class="font-semibold select-text-label">सरकारी स्वास्थ्य योजनाएं</span>
                        </button>
                        <button class="flex items-center gap-2 p-2 rounded-lg bg-surface-container/50 border border-white/5 hover:border-secondary-fixed/50 hover:bg-secondary-fixed/5 transition-colors text-left chip-btn">
                            <span class="material-symbols-outlined text-error text-[18px]">monitor_heart</span>
                            <span class="font-semibold select-text-label">लक्षण जांचकर्ता</span>
                        </button>
                    `;
                }

                if (quickChips) {
                    quickChips.innerHTML = `
                        <button class="whitespace-nowrap px-3 py-1.5 rounded-lg bg-surface-container text-on-surface-variant hover:text-on-surface hover:bg-white/10 transition-colors border border-white/5">PMJAY योजना के बारे में बताएं</button>
                        <button class="whitespace-nowrap px-3 py-1.5 rounded-lg bg-surface-container text-on-surface-variant hover:text-on-surface hover:bg-white/10 transition-colors border border-white/5">हल्के बुखार का इलाज कैसे करें?</button>
                        <button class="whitespace-nowrap px-3 py-1.5 rounded-lg bg-surface-container text-on-surface-variant hover:text-on-surface hover:bg-white/10 transition-colors border border-white/5">मधुमेह के लिए स्वस्थ आहार</button>
                    `;
                }
            } else {
                if (disclaimer) disclaimer.textContent = "SehatSaathi AI provides information, not medical diagnosis. Consult a doctor for serious conditions.";
                if (greetingText) greetingText.textContent = "Hello! I am SehatSaathi, your personal AI health assistant. How can I help you today? I can assist with:";
                if (textarea) textarea.placeholder = "Describe symptoms or ask a health question...";
                if (warningText) warningText.textContent = "SehatSaathi AI can make mistakes. Always verify critical medical information.";
                
                if (langEnBtn) langEnBtn.className = "px-3 py-1.5 rounded-lg text-xs font-bold transition-all bg-secondary-container text-on-secondary-container";
                if (langHiBtn) langHiBtn.className = "px-3 py-1.5 rounded-lg text-xs font-bold transition-all text-on-surface-variant hover:text-white";

                if (greetingChips) {
                    greetingChips.innerHTML = `
                        <button class="flex items-center gap-2 p-2 rounded-lg bg-surface-container/50 border border-white/5 hover:border-secondary-fixed/50 hover:bg-secondary-fixed/5 transition-colors text-left chip-btn">
                            <span class="material-symbols-outlined text-secondary-fixed text-[18px]">medical_services</span>
                            <span class="font-semibold select-text-label">First Aid Guide</span>
                        </button>
                        <button class="flex items-center gap-2 p-2 rounded-lg bg-surface-container/50 border border-white/5 hover:border-secondary-fixed/50 hover:bg-secondary-fixed/5 transition-colors text-left chip-btn">
                            <span class="material-symbols-outlined text-tertiary-fixed text-[18px]">nutrition</span>
                            <span class="font-semibold select-text-label">Nutrition Tips</span>
                        </button>
                        <button class="flex items-center gap-2 p-2 rounded-lg bg-surface-container/50 border border-white/5 hover:border-secondary-fixed/50 hover:bg-secondary-fixed/5 transition-colors text-left chip-btn">
                            <span class="material-symbols-outlined text-primary text-[18px]">description</span>
                            <span class="font-semibold select-text-label">Govt Health Schemes</span>
                        </button>
                        <button class="flex items-center gap-2 p-2 rounded-lg bg-surface-container/50 border border-white/5 hover:border-secondary-fixed/50 hover:bg-secondary-fixed/5 transition-colors text-left chip-btn">
                            <span class="material-symbols-outlined text-error text-[18px]">monitor_heart</span>
                            <span class="font-semibold select-text-label">Symptom Checker</span>
                        </button>
                    `;
                }

                if (quickChips) {
                    quickChips.innerHTML = `
                        <button class="whitespace-nowrap px-3 py-1.5 rounded-lg bg-surface-container text-on-surface-variant hover:text-on-surface hover:bg-white/10 transition-colors border border-white/5">Tell me about PMJAY scheme</button>
                        <button class="whitespace-nowrap px-3 py-1.5 rounded-lg bg-surface-container text-on-surface-variant hover:text-on-surface hover:bg-white/10 transition-colors border border-white/5">How to manage mild fever?</button>
                        <button class="whitespace-nowrap px-3 py-1.5 rounded-lg bg-surface-container text-on-surface-variant hover:text-on-surface hover:bg-white/10 transition-colors border border-white/5">Healthy diet for diabetes</button>
                    `;
                }
            }
            setupChipListeners();
        };

        if (langEnBtn && langHiBtn) {
            langEnBtn.addEventListener('click', () => updateUIForLanguage('en'));
            langHiBtn.addEventListener('click', () => updateUIForLanguage('hi'));
        }

        updateUIForLanguage(currentLang);

        const addSystemMessage = (text) => {
            const sysMsgHtml = `
                <div class="flex justify-center my-2 animate-fade-in-up">
                    <div class="glass-panel px-4 py-2.5 rounded-xl border border-white/10 text-on-surface-variant/80 text-xs max-w-[80%] text-center">
                        ${text}
                    </div>
                </div>
            `;
            chatContainer.insertAdjacentHTML('beforeend', sysMsgHtml);
            chatContainer.scrollTop = chatContainer.scrollHeight;
        };

        // Speech Recognition Setup
        let recognition = null;
        let isListening = false;
        if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
            const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
            recognition = new SpeechRecognition();
            recognition.continuous = false;
            recognition.interimResults = false;

            recognition.onstart = () => {
                isListening = true;
                const icon = document.getElementById('mic-icon');
                const ping = document.getElementById('mic-ping');
                if (icon) icon.textContent = 'graphic_eq';
                if (ping) {
                    ping.classList.remove('opacity-0');
                    ping.classList.add('animate-ping', 'opacity-100');
                }
            };

            recognition.onend = () => {
                isListening = false;
                const icon = document.getElementById('mic-icon');
                const ping = document.getElementById('mic-ping');
                if (icon) icon.textContent = 'mic';
                if (ping) {
                    ping.classList.add('opacity-0');
                    ping.classList.remove('animate-ping', 'opacity-100');
                }
            };

            recognition.onresult = (event) => {
                const speechToText = event.results[0][0].transcript;
                if (textarea) {
                    textarea.value = speechToText;
                    textarea.dispatchEvent(new Event('input'));
                    textarea.focus();
                }
            };
        }

        if (voiceBtn) {
            voiceBtn.addEventListener('click', () => {
                if (!recognition) {
                    alert(currentLang === 'en' 
                        ? "Speech Recognition is not supported by your browser. Please try Google Chrome."
                        : "आपका ब्राउज़र स्पीच रिकग्निशन का समर्थन नहीं करता है। कृपया गूगल क्रोम का उपयोग करें।");
                    return;
                }
                if (isListening) {
                    recognition.stop();
                } else {
                    recognition.lang = currentLang === 'hi' ? 'hi-IN' : 'en-US';
                    recognition.start();
                }
            });
        }

        const isEmergencyQuery = (text) => {
            const emergencyKeywords = [
                'chest pain', "can't breathe", "cannot breathe", 'breathing problem', 
                'stroke', 'unconscious', 'heavy bleeding', 'bleeding heavily', 'heart attack',
                'सीने में दर्द', 'सांस की तकलीफ', 'सांस नहीं ले पा रहा', 'लकवा', 'बेहोश', 'भारी रक्तस्राव', 'हार्ट अटैक'
            ];
            const lower = text.toLowerCase();
            return emergencyKeywords.some(kw => lower.includes(kw));
        };

        const getLocalResponseContent = (matchedKey, currentLang) => {
            if (!window.healthKnowledge || !window.healthKnowledge[matchedKey]) return "";
            const entry = window.healthKnowledge[matchedKey];
            const content = entry[currentLang] || entry['en'];
            const isScheme = matchedKey === 'pmjay' || matchedKey === 'abha' || matchedKey === 'jsy' || matchedKey === 'jan_aushadhi' || matchedKey === 'ayushman_bharat' || matchedKey === 'poshan_abhiyaan' || matchedKey === 'mission_indradhanush' || matchedKey === 'jssk' || matchedKey === 'rbsk' || matchedKey === 'npcdcs' || matchedKey === 'ntep' || matchedKey === 'tb_mukt_bharat' || matchedKey === 'esanjeevani' || matchedKey === 'ayush_programs' || matchedKey === 'pmsma';
            const isDiet = matchedKey.includes('diet') || matchedKey.includes('nutrition') || matchedKey === 'hydration' || matchedKey === 'vitamin_deficiency' || matchedKey === 'indian_meals' || matchedKey === 'balanced_diet';
            const isHi = currentLang === 'hi';
            if (isScheme) {
                const labels = {
                    overview: isHi ? "विवरण (Overview)" : "Overview",
                    eligibility: isHi ? "पात्रता / लाभार्थी (Eligibility)" : "Eligibility / Who is Covered",
                    benefits: isHi ? "योजना के लाभ (Benefits)" : "Key Benefits",
                    howToApply: isHi ? "आवेदन / लाभ कैसे लें (How to Apply)" : "How to Apply / Avail Benefits",
                    details: isHi ? "अतिरिक्त विवरण (Additional Details)" : "Additional Details"
                };
                return `
                    <h3 class="font-bold text-lg text-secondary-fixed mb-2">${content.name}</h3>
                    <p class="mb-3"><strong>${labels.overview}:</strong> ${content.overview}</p>
                    <p class="mb-2"><strong>${labels.eligibility}:</strong><br>${(content.symptoms || '').replace(/\n/g, '<br>')}</p>
                    <p class="mb-2"><strong>${labels.benefits}:</strong><br>${(content.homeCare || '').replace(/\n/g, '<br>')}</p>
                    <p class="mb-2"><strong>${labels.howToApply}:</strong><br>${(content.firstAid || '').replace(/\n/g, '<br>')}</p>
                    <p class="mb-2 text-outline"><strong>${labels.details}:</strong><br>${(content.doctorVisit || '').replace(/\n/g, '<br>')}</p>
                `;
            } else if (isDiet) {
                const labels = {
                    overview: isHi ? "विवरण (Overview)" : "Overview",
                    importance: isHi ? "महत्व / लक्षण (Importance)" : "Importance & Indicators",
                    dietPlan: isHi ? "आहार योजना / क्या खाएं (Diet Plan)" : "Recommended Foods & Diet Plan",
                    avoid: isHi ? "परहेज / क्या न खाएं (Foods to Avoid)" : "Foods to Limit or Avoid",
                    additional: isHi ? "अतिरिक्त सुझाव (Health Tips)" : "Additional Tips"
                };
                return `
                    <h3 class="font-bold text-lg text-secondary-fixed mb-2">${content.name}</h3>
                    <p class="mb-3"><strong>${labels.overview}:</strong> ${content.overview}</p>
                    <p class="mb-2"><strong>${labels.importance}:</strong><br>${(content.symptoms || '').replace(/\n/g, '<br>')}</p>
                    <p class="mb-2"><strong>${labels.dietPlan}:</strong><br>${(content.homeCare || '').replace(/\n/g, '<br>')}</p>
                    <p class="mb-2 text-error"><strong>${labels.avoid}:</strong><br>${(content.firstAid || '').replace(/\n/g, '<br>')}</p>
                    <p class="mb-2 text-outline"><strong>${labels.additional}:</strong><br>${(content.doctorVisit || '').replace(/\n/g, '<br>')}</p>
                `;
            } else {
                const labels = {
                    overview: isHi ? "विवरण" : "Overview",
                    symptoms: isHi ? "सामान्य लक्षण" : "Common Symptoms",
                    causes: isHi ? "कारण" : "Causes",
                    firstAid: isHi ? "त्वरित प्राथमिक उपचार" : "Immediate First Aid",
                    homeCare: isHi ? "घरेलू देखभाल (Home Care)" : "Home Care (What You Can Do)",
                    doctorVisit: isHi ? "डॉक्टर से कब मिलें" : "When to See a Doctor",
                    dangerSigns: isHi ? "आपातकालीन चेतावनी संकेत" : "Emergency Warning Signs"
                };
                return `
                    <h3 class="font-bold text-lg text-secondary-fixed mb-2">${content.name}</h3>
                    <p class="mb-3"><strong>${labels.overview}:</strong> ${content.overview}</p>
                    <p class="mb-2"><strong>${labels.symptoms}:</strong><br>${(content.symptoms || '').replace(/\n/g, '<br>')}</p>
                    <p class="mb-2"><strong>${labels.causes}:</strong><br>${(content.causes || '').replace(/\n/g, '<br>')}</p>
                    <p class="mb-2"><strong>${labels.firstAid}:</strong><br>${(content.firstAid || 'N/A').replace(/\n/g, '<br>')}</p>
                    <p class="mb-2"><strong>${labels.homeCare}:</strong><br>${(content.homeCare || '').replace(/\n/g, '<br>')}</p>
                    <p class="mb-2"><strong>${labels.doctorVisit}:</strong><br>${(content.doctorVisit || 'N/A').replace(/\n/g, '<br>')}</p>
                    <p class="mb-2 text-error font-bold"><strong>${labels.dangerSigns}:</strong><br>${(content.dangerSigns || '').replace(/\n/g, '<br>')}</p>
                `;
            }
        };

        const handleSend = async () => {
            const messageText = textarea.value.trim();
            if (!messageText) return;

            // Clear inputs
textarea.value = '';
            textarea.style.height = '';

            // Render User Card (right aligned cyan bubble)
            const userMsgHtml = `
                <div class="flex items-start gap-4 max-w-[85%] self-end flex-row-reverse animate-fade-in-up">
                    <div class="w-10 h-10 rounded-full bg-secondary-container text-on-secondary-container flex items-center justify-center shrink-0 border border-white/10 shadow-[0_0_10px_rgba(0,241,254,0.1)]">
                        <span class="material-symbols-outlined">person</span>
                    </div>
                    <div class="bg-secondary-container/20 border border-secondary-container/30 p-4 rounded-2xl rounded-tr-sm text-on-surface">
                        ${messageText}
                    </div>
                </div>
            `;
            chatContainer.insertAdjacentHTML('beforeend', userMsgHtml);
            chatContainer.scrollTop = chatContainer.scrollHeight;

            // Show Typing Indicator
            const typingMsgHtml = `
                <div id="bot-typing" class="flex items-start gap-4 max-w-[85%] animate-fade-in-up">
                    <div class="w-10 h-10 rounded-full bg-gradient-to-br from-secondary-container to-tertiary flex items-center justify-center shrink-0 shadow-[0_0_10px_rgba(0,241,254,0.2)]">
                        <span class="material-symbols-outlined text-on-secondary-container">smart_toy</span>
                    </div>
                    <div class="glass-panel p-4 rounded-2xl rounded-tl-sm flex items-center h-[56px]">
                        <div class="typing-indicator flex items-center">
                            <span></span>
                            <span></span>
                            <span></span>
                        </div>
                    </div>
                </div>
            `;
            chatContainer.insertAdjacentHTML('beforeend', typingMsgHtml);
            chatContainer.scrollTop = chatContainer.scrollHeight;

            // Increment AI Questions answered stat
            let currentStats = window.sehatSathiDB.getHealthData();
            let questionsCount = (currentStats.aiQuestionsAnswered || 0) + 1;
            window.sehatSathiDB.saveHealthData({ aiQuestionsAnswered: questionsCount });

            setTimeout(async () => {
                const botTyping = document.getElementById('bot-typing');
                if (botTyping) botTyping.remove();

                // Preprocess query: lowercase, remove punctuation, commas, extra spaces
                const cleanQuery = messageText.toLowerCase()
                    .replace(/[.,\/#!$%\^&\*;:{}=\-_`~()?"']/g, " ")
                    .replace(/\s+/g, " ")
                    .trim();
                const queryTokens = cleanQuery.split(" ").filter(t => t.length > 0);

                let isEmergency = isEmergencyQuery(messageText);
                let responseContent = "";
                let matchedKey = null;

                const synonymGroupings = {
                    'pmjay': ['pmjay', 'ayushman bharat', 'ayushman card', 'pm-jay', 'pmjay scheme', 'tell me about pmjay scheme', 'प्रधान मंत्री जन आरोग्य योजना', 'पीएमजेएवाई'],
                    'abha': ['abha', 'health id', 'abha health account', 'आभा', 'डिजिटल हेल्थ'],
                    'jan_aushadhi': ['jan aushadhi', 'janaushadhi', 'generic medicine', 'sasti dawai', 'जन औषधि', 'जेनेरिक दवा'],
                    'ayushman_bharat': ['ayushman bharat', 'ayushman arogya mandir', 'wellness center', 'आरोग्य मंदिर'],
                    'poshan_abhiyaan': ['poshan abhiyaan', 'poshan', 'nutrition mission', 'anganwadi', 'पोषण अभियान', 'आंगनवाड़ी'],
                    'mission_indradhanush': ['mission indradhanush', 'immunization campaign', 'indradhanush', 'इंद्रधनुष', 'टीकाकरण अभियान'],
                    'jsy': ['jsy', 'janani suraksha yojana', 'safe motherhood', 'जननी सुरक्षा', 'प्रसव सहायता'],
                    'jssk': ['jssk', 'janani shishu suraksha karyakram', 'free delivery', 'मुफ्त प्रसव', 'शिशु सुरक्षा'],
                    'rbsk': ['rbsk', 'rashtriya bal swasthya karyakram', 'child screening', 'बाल स्वास्थ्य', 'जन्मजात दोष'],
                    'npcdcs': ['npcdcs', 'lifestyle diseases program', 'cancer diabetes stroke', 'कैंसर मधुमेह'],
                    'ntep': ['ntep', 'national tuberculosis elimination program', 'dots', 'टीबी उन्मूलन'],
                    'tb_mukt_bharat': ['tb mukt bharat', 'nikshay mitra', 'adopt tb patient', 'निक्षय मित्र', 'टीबी मुक्त'],
                    'esanjeevani': ['esanjeevani', 'esanjeevaniopd', 'telemedicine', 'online doctor consultation', 'ई-संजीवनी', 'ऑनलाइन डॉक्टर'],
                    'ayush_programs': ['ayush', 'ayurveda yoga', 'homeopathy', 'आयुष', 'आयुर्वेद'],
                    'pmsma': ['pmsma', 'surakshit matritva', 'safe pregnancy scheme', 'सुरक्षित मातृत्व'],

                    'diabetes_diet': ['diabetes diet', 'sugar diet', 'diabetic diet', 'healthy diet for diabetes', 'what to eat in diabetes', 'diabetes meal plan', 'मधुमेह आहार', 'शुगर डाइट'],
                    'high_bp_diet': ['high bp diet', 'hypertension diet', 'low sodium diet', 'dash diet', 'bp food', 'उच्च रक्तचाप आहार', 'बीपी डाइट'],
                    'pregnancy_diet': ['pregnancy diet', 'pregnant diet', 'prenatal nutrition', 'what to eat during pregnancy', 'गर्भावस्था आहार', 'गर्भवती का भोजन'],
                    'child_nutrition': ['child nutrition', 'baby food', 'kids diet', 'pediatric nutrition', 'बाल पोषण', 'बच्चे का आहार'],
                    'anemia_diet': ['anemia diet', 'iron diet', 'blood deficiency diet', 'hemoglobin food', 'एनीमिया आहार', 'खून बढ़ाने वाला भोजन'],
                    'protein_diet': ['protein rich foods', 'protein diet', 'high protein food', 'protein sources', 'प्रोटीन युक्त भोजन', 'प्रोटीन डाइट'],
                    'hydration': ['hydration', 'water intake', 'drink water', 'fluid balance', 'जल संतुलन', 'पानी पीना'],
                    'vitamin_deficiency': ['vitamin deficiency', 'lack of vitamins', 'vitamin d b12 c a', 'विटामिन की कमी'],
                    'indian_meals': ['healthy indian meals', 'indian diet', 'healthy thali', 'स्वस्थ भारतीय भोजन'],
                    'balanced_diet': ['balanced diet', 'complete nutrition', 'balanced food', 'संतुलित आहार'],

                    'fever': ['fever', 'temp', 'temperature', 'high temperature', 'feverish', 'hot body', 'mild fever', 'how to manage mild fever', 'manage fever', 'बुखार', 'तापमान', 'शरीर गर्म'],
                    'cold': ['cold', 'common cold', 'runny nose', 'blocked nose', 'stuffy nose', 'sniffles', 'sneezing', 'congestion', 'जुकाम', 'सर्दी', 'छींक', 'बंद नाक'],
                    'flu': ['flu', 'influenza', 'viral fever', 'body aches', 'chills', 'फ्लू', 'इन्फ्लुएंजा'],
                    'covid': ['covid', 'covid-19', 'coronavirus', 'loss of smell', 'loss of taste', 'कोविड', 'कोरोना'],
                    'vomiting': ['vomit', 'vomiting', 'throw up', 'throwing up', 'nausea', 'stomach upset', 'sick to stomach', 'i feel like vomiting', 'feeling like throwing up', 'उल्टी', 'जी मिचलाना'],
                    'nausea': ['nausea', 'nauseous', 'feel like throwing up', 'sick feeling', 'जी मिचलाना', 'मतली'],
                    'diarrhea': ['diarrhea', 'loose motion', 'watery stool', 'loose stools', 'दस्त', 'पेट खराब', 'loose motion', 'stomach infection'],
                    'food_poisoning': ['food poisoning', 'poisoning', 'bad food', 'stomach infection', 'विषाक्त भोजन', 'फूड प्वाइजनिंग'],
                    'headache': ['headache', 'head pain', 'throbbing head', 'migraine', 'head ache', 'सिरदर्द', 'सिर दर्द'],
                    'migraine': ['migraine', 'severe headache', 'migraine pain', 'माइग्रेन', 'आधा सीसी दर्द'],
                    'stomach_pain': ['stomach pain', 'belly ache', 'abdominal pain', 'stomach ache', 'cramps', 'पेट दर्द', 'मरोड़'],
                    'chest_pain': ['chest pain', 'heart pain', 'chest tightness', 'angina', 'सीने में दर्द', 'छाती में दर्द'],
                    'hypertension': ['hypertension', 'high blood pressure', 'high bp', 'blood pressure', 'bp', 'रक्तचाप', 'हाई बीपी'],
                    'diabetes': ['diabetes', 'sugar', 'diabetic', 'high sugar', 'my sugar is high', 'sugar level', 'मधुमेह', 'शुगर'],
                    'asthma': ['asthma', 'wheezing', 'shortness of breath', 'breathing difficulty', 'breathless', 'breathing problem', 'breathlessness', 'shortness of breath', 'दमा', 'अस्थमा', 'सांस फूलना'],
                    'allergy': ['allergy', 'allergies', 'allergic', 'sneezing', 'rash', 'itching', 'एलर्जी', 'खुजली'],
                    'dehydration': ['dehydration', 'dry mouth', 'extreme thirst', 'water deficiency', 'निर्जलीकरण', 'पानी की कमी'],
                    'acidity': ['acidity', 'acid reflux', 'heartburn', 'gas', 'एसिडिटी', 'सीने में जलन'],
                    'heat_stroke': ['heat stroke', 'sun stroke', 'heatstroke', 'sunstroke', 'लू लगना', 'गर्मी लगना'],
                    'burns': ['burn', 'burns', 'scald', 'fire burn', 'जलना', 'जल गया'],
                    'cuts': ['cut', 'cuts', 'scrape', 'bleeding', 'wound', 'घाव', 'चोट', 'रक्तस्राव'],
                    'snake_bite': ['snake bite', 'snakebite', 'snake', 'सांप का काटना', 'सांप'],
                    'dog_bite': ['dog bite', 'dog', 'rabies', 'कुत्ते का काटना', 'कुत्ता'],
                    'pregnancy_care': ['pregnancy care', 'pregnancy', 'pregnant', 'prenatal', 'गर्भावस्था', 'गर्भवती'],
                    'child_fever': ['child fever', 'baby fever', 'pediatric fever', 'infant fever', 'बच्चों का बुखार', 'बच्चे को बुखार'],
                    'malaria': ['malaria', 'mosquito bite', 'chills fever', 'मलेरिया', 'मच्छर'],
                    'dengue': ['dengue', 'dengue fever', 'breakbone fever', 'डेंगू'],
                    'typhoid': ['typhoid', 'typhoid fever', 'दूषित पानी बुखार', 'टाइफाइड'],
                    'tuberculosis': ['tuberculosis', 'tb', 'chronic cough', 'क्षय रोग', 'टीबी'],
                    'eye_infection': ['eye infection', 'pink eye', 'conjunctivitis', 'red eyes', 'आंक आना', 'आंकड़ों का संक्रमण', 'आंको का संक्रमण', 'आंखों का संक्रमण'],
                    'ear_pain': ['ear pain', 'earache', 'ear infection', 'कान में दर्द', 'कान दर्द'],
                    'tooth_pain': ['tooth pain', 'toothache', 'dental pain', 'दांत दर्द', 'दांत में दर्द'],
                    'anxiety': ['anxiety', 'panic', 'tension', 'stress', 'fear', 'चिंता', 'घबराहट'],
                    'depression': ['depression', 'sadness', 'depressed', 'sad', 'अवसाद', 'डिप्रेशन'],
                    'insomnia': ['insomnia', 'sleep problems', 'sleeplessness', 'can\'t sleep', 'अनिद्रा', 'नींद न आना']
                };

                const scores = {};
                if (window.healthKnowledge) {
                    for (const key in window.healthKnowledge) {
                        let score = 0;
                        const keywords = [...(synonymGroupings[key] || [])];

                        const dbEntry = window.healthKnowledge[key];
                        if (dbEntry.en && dbEntry.en.name) keywords.push(dbEntry.en.name.toLowerCase());
                        if (dbEntry.hi && dbEntry.hi.name) keywords.push(dbEntry.hi.name.toLowerCase());
                        keywords.push(key.replace('_', ' '));

                        // 1. Synonym matching & Fuzzy phrase matching
                        for (let kw of keywords) {
                            kw = kw.toLowerCase().trim();
                            if (cleanQuery === kw) {
                                score += 30; // Perfect match
                            } else if (cleanQuery.includes(kw)) {
                                score += kw.length * 3; // Phrase containment
                            } else if (kw.includes(cleanQuery) && cleanQuery.length > 3) {
                                score += cleanQuery.length * 2;
                            }
                        }

                        // 2. Token overlap matching (fuzzy keyword search)
                        const kwTokens = keywords.flatMap(k => k.split(/\s+/)).filter(t => t.length > 2);
                        let tokenOverlap = 0;
                        for (const token of queryTokens) {
                            if (token.length >= 3 && kwTokens.includes(token)) {
                                tokenOverlap++;
                            }
                        }
                        score += tokenOverlap * 4;

                        // 3. Search inside database entry fields (title, overview, symptoms, causes, homeCare, firstAid)
                        const contentEN = dbEntry.en;
                        const contentHI = dbEntry.hi;
                        const fieldsToSearch = [
                            contentEN.name, contentEN.overview, contentEN.symptoms, contentEN.causes, contentEN.homeCare, contentEN.firstAid, contentEN.doctorVisit, contentEN.dangerSigns,
                            contentHI ? contentHI.name : '', contentHI ? contentHI.overview : '', contentHI ? contentHI.symptoms : '', contentHI ? contentHI.causes : '', contentHI ? contentHI.homeCare : '', contentHI ? contentHI.firstAid : '', contentHI ? contentHI.doctorVisit : '', contentHI ? contentHI.dangerSigns : ''
                        ].map(f => (f || '').toLowerCase());

                        let fieldOverlap = 0;
                        for (const token of queryTokens) {
                            if (token.length >= 3) {
                                for (const field of fieldsToSearch) {
                                    if (field.includes(token)) {
                                        fieldOverlap++;
                                    }
                                }
                            }
                        }
                        score += fieldOverlap * 0.5;

                        if (score > 0) {
                            scores[key] = score;
                            if (!matchedKey || score > scores[matchedKey]) {
                                matchedKey = key;
                            }
                        }
                    }
                }

                if (matchedKey && window.healthKnowledge[matchedKey]) {
                    // Exact local match found - render offline-first directly (does not break existing search!)
                    responseContent = getLocalResponseContent(matchedKey, currentLang);
                } else {
                    // No exact match found - try Gemini API
                    const savedApiKey = localStorage.getItem('GEMINI_API_KEY') || '';
                    let apiSuccess = false;
                    
                    if (savedApiKey && window.geminiService) {
                        try {
                            const geminiAnswer = await window.geminiService.askGemini(messageText, savedApiKey);
                            responseContent = geminiAnswer
                                .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
                                .replace(/\*(.*?)\*/g, '<em>$1</em>')
                                .replace(/\n/g, '<br>');
                            apiSuccess = true;
                        } catch (err) {
                            console.error("Gemini API call failed:", err);
                        }
                    }
                    
                    if (!apiSuccess) {
                        // Gemini API failed or key is missing. Find if a partial/closest local match exists!
                        let fallbackKey = null;
                        let highestFallbackScore = 0;
                        
                        if (window.healthKnowledge) {
                            for (const key in window.healthKnowledge) {
                                let score = 0;
                                const keywords = [...(synonymGroupings[key] || [])];
                                const dbEntry = window.healthKnowledge[key];
                                if (dbEntry.en && dbEntry.en.name) keywords.push(dbEntry.en.name.toLowerCase());
                                if (dbEntry.hi && dbEntry.hi.name) keywords.push(dbEntry.hi.name.toLowerCase());
                                keywords.push(key.replace('_', ' '));
                                
                                for (let kw of keywords) {
                                    kw = kw.toLowerCase().trim();
                                    if (cleanQuery.includes(kw) || kw.includes(cleanQuery)) {
                                        score += kw.length;
                                    }
                                }
                                
                                for (const token of queryTokens) {
                                    if (token.length >= 3) {
                                        const kwTokens = keywords.flatMap(k => k.split(/\s+/)).filter(t => t.length > 2);
                                        if (kwTokens.includes(token)) score += 5;
                                    }
                                }
                                
                                if (score > highestFallbackScore) {
                                    highestFallbackScore = score;
                                    fallbackKey = key;
                                }
                            }
                        }
                        
                        if (fallbackKey && window.healthKnowledge[fallbackKey]) {
                            // Local result exists! Show guidance with warning banner
                            const bannerText = currentLang === 'hi'
                                ? "ऑनलाइन एआई वर्तमान में अनुपलब्ध है। स्थानीय चिकित्सा ज्ञान आधार से मार्गदर्शन दिखा रहा है।"
                                : "Online AI is currently unavailable. Showing guidance from the local medical knowledge base.";
                            
                            responseContent = `
                                <div class="bg-warning/15 border border-warning/35 text-warning p-3 rounded-xl mb-4 text-xs font-semibold flex items-center gap-2">
                                    <span class="material-symbols-outlined text-[16px]">warning</span>
                                    <span>${bannerText}</span>
                                </div>
                                ${getLocalResponseContent(fallbackKey, currentLang)}
                            `;
                        } else {
                            // No local result exists at all! Show offline warning
                            const noResultText = currentLang === 'hi'
                                ? "यह विषय ऑफ़लाइन उपलब्ध नहीं है। कृपया बाद में पुनः प्रयास करें।"
                                : "This topic is not available offline. Please try again later.";
                            
                            responseContent = `
                                <div class="text-on-surface-variant/80 font-medium flex items-center gap-2">
                                    <span class="material-symbols-outlined text-outline text-[18px]">cloud_off</span>
                                    <span>${noResultText}</span>
                                </div>
                            `;
                        }
                    }
                }

                // Render Response Card
                let botMsgHtml = "";
                
                if (isEmergency) {
                    const emergencyAlertTitle = currentLang === 'hi' ? "संभावित आपातकालीन स्थिति" : "Possible Medical Emergency";
                    const emergencyAlertBanner = currentLang === 'hi' 
                        ? "संभावित आपातकाल। तुरंत चिकित्सा सहायता से संपर्क करें।" 
                        : "Possible emergency. Contact medical help.";
                    const callAmbulanceText = currentLang === 'hi' ? "एंबुलेंस बुलाएं (108)" : "Call Ambulance (108)";
                    const callNationalText = currentLang === 'hi' ? "आपातकालीन नंबर (112)" : "Emergency Helpline (112)";

                    botMsgHtml = `
                        <div class="flex items-start gap-4 max-w-[90%] animate-fade-in-up">
                            <div class="w-10 h-10 rounded-full bg-error flex items-center justify-center shrink-0 shadow-[0_0_15px_rgba(255,180,171,0.4)] animate-pulse">
                                <span class="material-symbols-outlined text-on-error">warning</span>
                            </div>
                            <div class="bg-error-container/20 border-2 border-error/50 p-4 rounded-2xl rounded-tl-sm relative overflow-hidden flex-1">
                                <div class="absolute inset-0 bg-error/5 animate-pulse rounded-2xl"></div>
                                <div class="relative z-10">
                                    <div class="flex items-center gap-2 mb-2 text-error">
                                        <span class="material-symbols-outlined font-bold">emergency</span>
                                        <h3 class="font-semibold uppercase tracking-wider">${emergencyAlertTitle}</h3>
                                    </div>
                                    <p class="text-error font-bold mb-3">${emergencyAlertBanner}</p>
                                    
                                    <div class="text-on-surface mb-4">
                                        ${responseContent || (currentLang === 'hi' 
                                            ? "छाती में दर्द या सांस लेने में भारी तकलीफ गंभीर लक्षण हैं। तुरंत नीचे दिए गए नंबरों पर कॉल करें।" 
                                            : "Severe chest pain or extreme breathing difficulty are critical symptoms. Call emergency services immediately.")}
                                    </div>
                                    
                                    <div class="flex flex-wrap gap-3 mt-4">
                                        <a class="flex items-center justify-center gap-2 bg-error text-on-error px-5 py-2.5 rounded-xl font-bold hover:bg-error/90 transition-all shadow-[0_4px_14px_rgba(255,180,171,0.3)] hover:-translate-y-0.5" href="tel:108">
                                            <span class="material-symbols-outlined" style="font-variation-settings: 'FILL' 1;">call</span>
                                            ${callAmbulanceText}
                                        </a>
                                        <a class="flex items-center justify-center gap-2 bg-surface-container px-5 py-2.5 rounded-xl border border-white/10 hover:bg-white/5 transition-all text-on-surface font-bold" href="tel:112">
                                            <span class="material-symbols-outlined">phone</span>
                                            ${callNationalText}
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    `;
                } else {
                    botMsgHtml = `
                        <div class="flex items-start gap-4 max-w-[85%] animate-fade-in-up">
                            <div class="w-10 h-10 rounded-full bg-gradient-to-br from-secondary-container to-tertiary flex items-center justify-center shrink-0 shadow-[0_0_10px_rgba(0,241,254,0.2)]">
                                <span class="material-symbols-outlined text-on-secondary-container">smart_toy</span>
                            </div>
                            <div class="glass-panel p-4 rounded-2xl rounded-tl-sm hover:border-secondary-fixed/30 transition-all flex-1 relative">
                                <div class="text-on-surface chat-bot-response-text">${responseContent}</div>
                                <div class="flex justify-end mt-3 gap-2">
                                    <button class="speak-btn p-1.5 rounded-lg text-on-surface-variant hover:text-white hover:bg-white/5 transition-colors" title="Speak Answer">
                                        <span class="material-symbols-outlined text-[18px]">volume_up</span>
                                    </button>
                                </div>
                            </div>
                        </div>
                    `;
                }

                chatContainer.insertAdjacentHTML('beforeend', botMsgHtml);
                chatContainer.scrollTop = chatContainer.scrollHeight;

                const speakButtons = chatContainer.querySelectorAll('.speak-btn');
                if (speakButtons.length > 0) {
                    const lastBtn = speakButtons[speakButtons.length - 1];
                    lastBtn.addEventListener('click', () => {
                        const cardText = lastBtn.closest('.glass-panel').querySelector('.chat-bot-response-text').innerText;
                        speakText(cardText, currentLang);
                    });
                }

            }, 1000);
        };

        if (sendBtn) sendBtn.addEventListener('click', handleSend);
        if (textarea) {
            textarea.addEventListener('keydown', (e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    handleSend();
                }
            });
        }
    }

    // ==========================================
    // 8. PAGE INTERACTIONS: HEALTH TOOLS
    // ==========================================
    if (pageName.includes('health-tools')) {
        const heightInput = document.getElementById('bmi-height');
        const weightInput = document.getElementById('bmi-weight');
        const calcBtn = document.getElementById('bmi-calc-btn');
        const resultVal = document.getElementById('bmi-result-val');

        // Load existing metrics
        const metrics = window.sehatSathiDB.getHealthData();
        if (heightInput) heightInput.value = metrics.height || "175";
        if (weightInput) weightInput.value = metrics.weight || "70";
        if (resultVal && metrics.bmi) {
            resultVal.innerHTML = `${metrics.bmi} <span class="text-sm font-normal text-on-surface-variant">(Saved)</span>`;
        }

        if (heightInput && weightInput && calcBtn && resultVal) {
            calcBtn.addEventListener('click', () => {
                const h = parseFloat(heightInput.value) / 100;
                const w = parseFloat(weightInput.value);
                if (h > 0 && w > 0) {
                    const bmi = (w / (h * h)).toFixed(1);
                    let status = 'Normal';
                    let statusColor = '#4fdbc8';
                    if (bmi < 18.5) {
                        status = 'Underweight';
                        statusColor = '#ddfcff';
                    } else if (bmi >= 25 && bmi < 30) {
                        status = 'Overweight';
                        statusColor = '#b9c7e4';
                    } else if (bmi >= 30) {
                        status = 'Obese';
                        statusColor = '#ffb4ab';
                    }
                    resultVal.innerHTML = `${bmi} <span class="text-sm font-normal" style="color: ${statusColor}">(${status})</span>`;
                    
                    // Save permanently
                    window.sehatSathiDB.saveHealthData({
                        height: heightInput.value,
                        weight: weightInput.value,
                        bmi: bmi
                    });
                }
            });
        }

        // ==========================================
        // Water Tracker
        // ==========================================
        const waterDisplayVal = document.getElementById('water-display-val');
        const waterDisplaySub = document.getElementById('water-display-sub');
        const waterProgressBar = document.getElementById('water-progress-bar');
        const waterGoalMsg = document.getElementById('water-goal-msg');
        const addWater250 = document.getElementById('add-water-250');
        const addWater500 = document.getElementById('add-water-500');
        const addWater1000 = document.getElementById('add-water-1000');
        const resetWater = document.getElementById('reset-water');
        const waterToast = document.getElementById('water-toast');

        if (waterDisplayVal && waterProgressBar) {
            let rawWater = metrics.waterIntake;
            if (rawWater === null || rawWater === undefined) {
                rawWater = "0";
            }
            let currentWater = parseFloat(rawWater);
            if (isNaN(currentWater)) {
                currentWater = 0.0;
            }
            const goal = 2.5;

            const showToastMessage = (toastEl, msg) => {
                toastEl.textContent = msg;
                toastEl.classList.remove('opacity-0');
                toastEl.classList.add('opacity-100');
                setTimeout(() => {
                    toastEl.classList.remove('opacity-100');
                    toastEl.classList.add('opacity-0');
                }, 2000);
            };

            const drawWater = (animate = false) => {
                waterDisplayVal.textContent = `${currentWater.toFixed(1)} L / ${goal.toFixed(1)} L`;
                const percentage = Math.min((currentWater / goal) * 100, 100);
                waterDisplaySub.textContent = `${Math.round(percentage)}% of Daily Goal`;
                
                waterProgressBar.style.width = `${percentage}%`;

                if (currentWater >= goal) {
                    waterGoalMsg.classList.remove('hidden');
                } else {
                    waterGoalMsg.classList.add('hidden');
                }

                if (animate) {
                    waterDisplayVal.classList.add('scale-105', 'text-secondary-fixed');
                    setTimeout(() => {
                        waterDisplayVal.classList.remove('scale-105', 'text-secondary-fixed');
                    }, 300);
                }
            };

            const updateWater = (amount) => {
                if (amount === 0) {
                    currentWater = 0;
                    showToastMessage(waterToast, "Water tracker reset.");
                } else {
                    currentWater += amount;
                    showToastMessage(waterToast, "Water intake updated.");
                }
                drawWater(true);
                window.sehatSathiDB.saveHealthData({ waterIntake: currentWater.toFixed(2) });
            };

            drawWater();

            if (addWater250) addWater250.addEventListener('click', () => updateWater(0.25));
            if (addWater500) addWater500.addEventListener('click', () => updateWater(0.50));
            if (addWater1000) addWater1000.addEventListener('click', () => updateWater(1.00));
            if (resetWater) resetWater.addEventListener('click', () => updateWater(0));
        }

        // ==========================================
        // Sleep Tracker
        // ==========================================
        const sleepTimeInput = document.getElementById('sleep-time');
        const sleepWakeInput = document.getElementById('sleep-wake');
        const calculateSleepBtn = document.getElementById('calculate-sleep-btn');
        const sleepDisplayVal = document.getElementById('sleep-display-val');
        const sleepStatusBadge = document.getElementById('sleep-status-badge');
        const sleepRecommendation = document.getElementById('sleep-recommendation');
        const sleepLastUpdated = document.getElementById('sleep-last-updated');
        const sleepToast = document.getElementById('sleep-toast');

        if (calculateSleepBtn && sleepDisplayVal) {
            let rawSleep = metrics.sleepHours;
            if (rawSleep === null || rawSleep === undefined) {
                rawSleep = "0";
            }
            const parsedSleepHours = parseFloat(rawSleep);
            const initialSleepHours = isNaN(parsedSleepHours) ? 0.0 : parsedSleepHours;
            
            const displaySleepInfo = (totalHours, updateTimestamp = "Today") => {
                if (totalHours <= 0) {
                    sleepDisplayVal.textContent = "No data";
                    sleepStatusBadge.textContent = "Poor";
                    sleepStatusBadge.className = "inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-error/10 text-error border border-error/20";
                    sleepRecommendation.textContent = "Use the calculator to log last night's sleep.";
                    sleepLastUpdated.textContent = "Never";
                    return;
                }

                const h = Math.floor(totalHours);
                const m = Math.round((totalHours - h) * 60);
                sleepDisplayVal.textContent = `${h}h ${m}m`;

                let status = "Healthy";
                let badgeClass = "bg-tertiary-fixed/10 text-tertiary-fixed border border-tertiary-fixed/20";
                let rec = "Try sleeping before 11 PM consistently for better recovery.";

                if (totalHours < 5) {
                    status = "Poor";
                    badgeClass = "bg-error/10 text-error border border-error/20";
                    rec = "Extremely short sleep. Prioritize getting 7-9 hours to support heart and brain recovery.";
                } else if (totalHours >= 5 && totalHours < 7) {
                    status = "Average";
                    badgeClass = "bg-amber-500/10 text-amber-400 border border-amber-500/20";
                    rec = "Slightly less than recommended. Aim for an extra hour of rest.";
                } else if (totalHours >= 7 && totalHours <= 9) {
                    status = "Healthy";
                    badgeClass = "bg-tertiary-fixed/10 text-tertiary-fixed border border-tertiary-fixed/20";
                    rec = "Excellent! You are maintaining a healthy sleep schedule. Keep it up.";
                } else if (totalHours > 9) {
                    status = "Oversleep";
                    badgeClass = "bg-secondary-fixed/10 text-secondary-fixed border border-secondary-fixed/20";
                    rec = "Regular oversleeping can cause grogginess. Try setting an alarm.";
                }

                sleepStatusBadge.textContent = status;
                sleepStatusBadge.className = `inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${badgeClass}`;
                sleepRecommendation.textContent = rec;
                sleepLastUpdated.textContent = updateTimestamp;
            };

            displaySleepInfo(initialSleepHours, initialSleepHours > 0 ? "Today" : "Never");

            calculateSleepBtn.addEventListener('click', () => {
                const sleepTime = sleepTimeInput.value;
                const wakeTime = sleepWakeInput.value;

                if (!sleepTime || !wakeTime) return;

                const [sleepH, sleepM] = sleepTime.split(':').map(Number);
                const [wakeH, wakeM] = wakeTime.split(':').map(Number);

                let diffMins = (wakeH * 60 + wakeM) - (sleepH * 60 + sleepM);
                if (diffMins < 0) {
                    diffMins += 24 * 60; // midnight roll-over
                }

                const totalHours = diffMins / 60;
                displaySleepInfo(totalHours, "Today");

                window.sehatSathiDB.saveHealthData({ sleepHours: totalHours.toString() });

                // Toast
                sleepToast.textContent = "Sleep record saved.";
                sleepToast.classList.remove('opacity-0');
                sleepToast.classList.add('opacity-100');
                setTimeout(() => {
                    sleepToast.classList.remove('opacity-100');
                    sleepToast.classList.add('opacity-0');
                }, 2000);
            });
        }

        // Medicine Reminder Complete check toggle
        const medBtns = document.querySelectorAll('button');
        medBtns.forEach((btn) => {
            const icon = btn.querySelector('.material-symbols-outlined');
            if (icon && icon.textContent === 'done') {
                btn.addEventListener('click', () => {
                    const row = btn.closest('div');
                    if (row) {
                        row.style.opacity = '0.6';
                        const label = row.querySelector('.font-label-md');
                        if (label) label.style.textDecoration = 'line-through';
                        alert("Medicine marked as taken!");
                    }
                });
            }
        });
    }
    // ==========================================
    // 8.5. PAGE INTERACTIONS: HEALTH LIBRARY
    // ==========================================
    if (pageName.includes('health-library')) {
        const libraryGrid = document.getElementById('library-grid');
        const searchInput = document.getElementById('library-search-input');
        const tabs = document.querySelectorAll('.category-tab');

        const categoryMap = {
            common: [
                'fever', 'headache', 'body_ache', 'cough', 'runny_nose', 'sore_throat', 
                'vomiting', 'nausea', 'stomach_pain', 'diarrhea', 'constipation', 'bloating', 
                'acid_reflux', 'malaria', 'dengue', 'typhoid', 'bronchitis', 'tonsillitis', 
                'chickenpox', 'measles', 'sinusitis', 'ear_infection', 'conjunctivitis', 'yeast_infection'
            ],
            chronic: [
                'type_2_diabetes', 'high_cholesterol', 'fatty_liver_disease', 'asthma_lifestyle', 
                'arthritis', 'dementia', 'alzheimers', 'parkinsons', 'osteoporosis', 'cataract', 
                'hearing_loss', 'prostate_issues', 'jaundice', 'fatty_liver', 'ulcer', 'gastritis', 
                'piles', 'kidney_stones', 'high_bp_diet', 'obesity', 'heart_diet'
            ],
            women: [
                'pregnancy_care', 'menstrual_cramps', 'pcos', 'uti', 'breast_cancer', 
                'cervical_cancer', 'osteoporosis_women', 'thyroid_women', 'menopause', 
                'pregnancy_spacing', 'pregnancy_diet', 'pmsma', 'morning_sickness', 
                'gestational_diabetes', 'preeclampsia', 'postpartum_care', 'breastfeeding', 
                'folic_acid', 'prenatal_exercise', 'miscarriage', 'labor_signs', 'anemia_diet'
            ],
            children: [
                'vaccination_schedule', 'child_fever', 'colic', 'diaper_rash', 
                'childhood_obesity', 'teething', 'deworming', 'pediatric_asthma', 
                'dehydration_in_children', 'mumps', 'rubella', 'child_nutrition', 
                'bcg_vaccine', 'polio_vaccine', 'hepatitis_b_vaccine', 'tetanus_vaccine', 
                'mmr_vaccine', 'dpt_vaccine', 'flu_shot', 'covid_vaccine', 'hpv_vaccine'
            ]
        };

        let activeCategory = 'all';
        let searchQuery = '';

        const renderLibrary = () => {
            if (!libraryGrid) return;
            libraryGrid.innerHTML = '';

            let data = window.sehatSathiDB.getHealthData();
            let completedTopics = data.completedTopicsList || [];

            // Get current language (default to en)
            let lang = localStorage.getItem('sehatsathi_lang') || 'en';

            for (let key in window.healthKnowledge) {
                // Skip schemes or first aid from main library display
                if (key === 'pmjay' || key === 'abha' || key === 'jsy' || key === 'indradhanush' || key === 'nhm' || key === 'first aid') continue;
                if (key === 'heart attack' || key === 'stroke' || key === 'burns' || key === 'severe bleeding' || key === 'fracture' || key === 'seizure' || key === 'breathing difficulty' || key === 'snake bite' || key === 'choking' || key === 'electric shock' || key === 'unconscious') continue;

                const disease = window.healthKnowledge[key];
                const content = disease[lang] || disease['en'];

                // Filter by category
                if (activeCategory !== 'all') {
                    const keys = categoryMap[activeCategory];
                    if (!keys || !keys.includes(key)) continue;
                }

                // Filter by search query
                if (searchQuery) {
                    const query = searchQuery.toLowerCase();
                    const nameMatch = content.name.toLowerCase().includes(query);
                    const symptomsMatch = content.symptoms.toLowerCase().includes(query);
                    const overviewMatch = content.overview.toLowerCase().includes(query);
                    if (!nameMatch && !symptomsMatch && !overviewMatch) continue;
                }

                // Determine tag and color
                let tag = 'Common';
                let tagClass = 'bg-secondary-container text-on-secondary-container';
                if (categoryMap.chronic.includes(key)) {
                    tag = lang === 'hi' ? 'दीर्घकालिक' : 'Chronic';
                    tagClass = 'bg-tertiary-container text-tertiary-fixed border border-tertiary-fixed/30';
                } else if (categoryMap.women.includes(key)) {
                    tag = lang === 'hi' ? 'महिला स्वास्थ्य' : 'Women\'s';
                    tagClass = 'bg-primary-container text-primary-fixed border border-primary-fixed/30';
                } else if (categoryMap.children.includes(key)) {
                    tag = lang === 'hi' ? 'बाल स्वास्थ्य' : 'Children\'s';
                    tagClass = 'bg-secondary-container text-on-secondary-container border border-secondary-fixed/30';
                } else {
                    tag = lang === 'hi' ? 'सामान्य' : 'Common';
                }

                const isCompleted = completedTopics.includes(key);
                const buttonText = isCompleted 
                    ? (lang === 'hi' ? 'पूर्ण ✓' : 'Completed ✓')
                    : (lang === 'hi' ? 'पढ़ा हुआ चिह्नित करें' : 'Mark as Read');
                const buttonClass = isCompleted 
                    ? 'bg-tertiary text-on-tertiary pointer-events-none' 
                    : 'bg-surface-container hover:bg-surface-container-high text-tertiary-fixed hover:text-white transition-all';

                const cardHtml = `
                    <article class="glass-card rounded-xl p-5 flex flex-col justify-between border border-white/5 bg-surface-container-low/40 relative overflow-hidden transition-all duration-300 hover:shadow-lg hover:border-secondary-fixed/20 min-h-[380px]">
                        <div>
                            <div class="flex justify-between items-start mb-3">
                                <span class="px-2 py-0.5 rounded text-[10px] uppercase font-bold tracking-wider ${tagClass}">${tag}</span>
                            </div>
                            <h3 class="text-base text-white font-bold mb-2">${content.name}</h3>
                            <p class="text-xs text-on-surface-variant mb-4 line-clamp-2">${content.overview}</p>
                            
                            <div class="space-y-3 border-t border-white/5 pt-4">
                                <div class="text-[11px]"><strong class="text-secondary-fixed">${lang === 'hi' ? 'लक्षण' : 'Symptoms'}:</strong> <span class="text-on-surface-variant">${(content.symptoms || '').replace(/\n• /g, ', ').replace(/• /g, '')}</span></div>
                                <div class="text-[11px]"><strong class="text-secondary-fixed">${lang === 'hi' ? 'कारण' : 'Causes'}:</strong> <span class="text-on-surface-variant">${(content.causes || '').replace(/\n• /g, ', ').replace(/• /g, '')}</span></div>
                                <div class="text-[11px]"><strong class="text-secondary-fixed">${lang === 'hi' ? 'घरेलू देखभाल' : 'Home Care'}:</strong> <span class="text-on-surface-variant">${(content.homeCare || '').replace(/\n• /g, ', ').replace(/• /g, '')}</span></div>
                                <div class="text-[11px]"><strong class="text-secondary-fixed">${lang === 'hi' ? 'प्राथमिक उपचार' : 'First Aid'}:</strong> <span class="text-on-surface-variant">${(content.firstAid || '').replace(/\n• /g, ', ').replace(/• /g, '')}</span></div>
                                <div class="text-[11px]"><strong class="text-error">${lang === 'hi' ? 'डॉक्टर को कब दिखाएं' : 'When to consult doctor'}:</strong> <span class="text-on-surface-variant">${content.doctorVisit || ''}</span></div>
                            </div>
                        </div>
                        <div class="mt-4 pt-3 border-t border-white/5">
                            <button data-key="${key}" class="mark-completed-btn w-full py-2 rounded-lg font-bold text-xs text-center ${buttonClass}">
                                ${buttonText}
                            </button>
                        </div>
                    </article>
                `;
                libraryGrid.insertAdjacentHTML('beforeend', cardHtml);
            }

            // Attach Mark as Completed listeners
            const markBtns = libraryGrid.querySelectorAll('.mark-completed-btn');
            markBtns.forEach(btn => {
                btn.addEventListener('click', () => {
                    const key = btn.getAttribute('data-key');
                    if (!completedTopics.includes(key)) {
                        completedTopics.push(key);
                        
                        let currentTopics = parseInt(localStorage.getItem('guest_healthTopicsCompleted') || '0') + 1;
                        localStorage.setItem('guest_healthTopicsCompleted', currentTopics.toString());

                        let updatedData = { 
                            completedTopicsList: completedTopics,
                            healthTopicsCompleted: completedTopics.length
                        };
                        window.sehatSathiDB.saveHealthData(updatedData);

                        btn.textContent = 'Completed ✓';
                        btn.className = 'mark-completed-btn w-full py-2 rounded-lg font-bold text-xs text-center bg-tertiary text-on-tertiary pointer-events-none';
                        alert("Topic marked as completed! Your knowledge stats have been updated.");
                    }
                });
            });
        };

        // Search listener
        if (searchInput) {
            searchInput.addEventListener('input', (e) => {
                searchQuery = e.target.value;
                renderLibrary();
            });
        }

        // Tabs listener
        tabs.forEach(tab => {
            tab.addEventListener('click', () => {
                tabs.forEach(t => {
                    t.className = "category-tab px-4 py-2 rounded-full glass-panel text-on-surface font-label-md text-label-md hover:text-secondary-fixed transition-all";
                });
                tab.className = "category-tab px-4 py-2 rounded-full bg-secondary-fixed text-on-secondary-fixed font-label-md text-label-md transition-all";
                activeCategory = tab.getAttribute('data-category');
                renderLibrary();
            });
        });

        // Initial render
        renderLibrary();
    }

    // ==========================================
    // 9. PAGE INTERACTIONS: IMPACT DASHBOARD
    // ==========================================
    if (pageName.includes('impact-dashboard')) {
        const counters = document.querySelectorAll('.counter-value');
        const speed = 200;

        let stats = window.sehatSathiDB.getHealthData();
        let registeredUsers = JSON.parse(localStorage.getItem('sehatsathi_all_users') || '[]');
        let totalUsersCount = registeredUsers.length;
        let familiesCount = parseInt(localStorage.getItem('guest_surveySubmissions') || '0') + (stats.surveySubmissions || 0);
        let topicsCount = stats.healthTopicsCompleted || 0;
        let questionsCount = stats.aiQuestionsAnswered || 0;

        // Determine if we should show community preview demo stats
        const isDemoMode = (totalUsersCount === 0 && familiesCount === 0 && questionsCount === 0);

        let finalUsers = isDemoMode ? 5430 : (totalUsersCount || 1);
        let finalFamilies = isDemoMode ? 1248 : familiesCount;
        let finalTopics = isDemoMode ? 23 : topicsCount;
        let finalQuestions = isDemoMode ? 8920 : questionsCount;

        // Inject Community Preview Banner
        const headerSection = document.querySelector('header');
        if (headerSection) {
            let bannerHtml = '';
            if (isDemoMode) {
                bannerHtml = `
                    <div class="mt-4 inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-secondary-container/10 border border-secondary-container/30 text-secondary-fixed text-xs font-bold shadow-[0_0_10px_rgba(0,241,254,0.15)]">
                        <span class="material-symbols-outlined text-[14px]">science</span> Community Preview — Demo Analytics
                    </div>
                `;
            } else {
                bannerHtml = `
                    <div class="mt-4 inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-tertiary-container text-tertiary-fixed text-xs font-bold border border-tertiary/30 shadow-[0_0_10px_rgba(79,219,200,0.15)]">
                        <span class="material-symbols-outlined text-[14px]">sensors</span> Live Platform Statistics
                    </div>
                `;
            }
            const oldBanner = headerSection.querySelector('.preview-banner');
            if (oldBanner) oldBanner.remove();
            
            const bannerDiv = document.createElement('div');
            bannerDiv.className = 'preview-banner';
            bannerDiv.innerHTML = bannerHtml;
            headerSection.appendChild(bannerDiv);
        }

        counters.forEach(counter => {
            const card = counter.closest('.glass-card');
            if (!card) return;
            const labelEl = card.querySelector('.font-label-md');
            if (!labelEl) return;
            const label = labelEl.textContent.trim().toUpperCase();
            if (label.includes("FAMILIES REACHED") || label.includes("FAMILIES SURVEYED") || label.includes("SURVEYED") || label.includes("REACHED")) {
                counter.setAttribute('data-target', finalFamilies.toString());
            } else if (label.includes("INDIVIDUALS EDUCATED") || label.includes("TOTAL USERS") || label.includes("EDUCATED") || label.includes("PEOPLE")) {
                counter.setAttribute('data-target', finalUsers.toString());
            } else if (label.includes("VILLAGES COVERED") || label.includes("TOPICS COMPLETED") || label.includes("COVERED") || label.includes("VILLAGES")) {
                counter.setAttribute('data-target', finalTopics.toString());
            } else if (label.includes("QUESTIONS ANSWERED")) {
                counter.setAttribute('data-target', finalQuestions.toString());
            }
        });

        counters.forEach(counter => {
            const target = +counter.getAttribute('data-target') || 0;
            counter.innerText = target.toLocaleString();
        });
    }

    // ==========================================
    // 10. PAGE INTERACTIONS: DIGITAL FAMILY HEALTH CARD
    // ==========================================
    // ==========================================
    // 10. PAGE INTERACTIONS: DIGITAL FAMILY HEALTH CARD
    // ==========================================
    if (pageName.includes('family-card')) {
        const profileSelect = document.getElementById('profile-select');
        const addMemberBtn = document.getElementById('add-member-btn');
        const relationshipInput = document.getElementById('card-relationship-input');
        const genderInput = document.getElementById('card-gender-input');
        const nameInput = document.getElementById('card-name-input');
        const ageInput = document.getElementById('card-age-input');
        const bloodInput = document.getElementById('card-blood-input');
        const phoneInput = document.getElementById('card-phone-input');
        const conditionsInput = document.getElementById('card-conditions-input');
        const allergiesInput = document.getElementById('card-allergies-input');
        const medicationsInput = document.getElementById('card-medications-input');
        const surgeriesInput = document.getElementById('card-surgeries-input');
        const vaccinesInput = document.getElementById('card-vaccines-input');
        const addressInput = document.getElementById('card-address-input');
        const genBtn = document.getElementById('generate-card-btn');

        const qrImg = document.getElementById('preview-qr');
        const previewName = document.getElementById('preview-name');
        const previewId = document.getElementById('preview-id');
        const previewAge = document.getElementById('preview-age');
        const previewGender = document.getElementById('preview-gender');
        const previewBlood = document.getElementById('preview-blood-group-val');
        const previewRelationship = document.getElementById('preview-relationship');
        const previewPhone = document.getElementById('preview-phone-val');
        const previewConditions = document.getElementById('preview-conditions-val');
        const previewAllergies = document.getElementById('preview-allergies-val');
        const previewMedications = document.getElementById('preview-medications-val');
        const previewSurgeries = document.getElementById('preview-surgeries-val');
        const previewVaccines = document.getElementById('preview-vaccines-val');
        const previewAddress = document.getElementById('preview-address-val');

        // Load values from LocalStorage
        let familyProfiles = [];
        try {
            familyProfiles = JSON.parse(localStorage.getItem('sehatsathi_family_profiles') || '[]');
        } catch (e) {
            familyProfiles = [];
        }

        // Initialize default profile if empty
        if (familyProfiles.length === 0) {
            let currentUser = window.sehatSathiDB.currentUser;
            familyProfiles.push({
                id: currentUser ? `SS-${currentUser.uid.substring(4, 8).toUpperCase()}-9842` : 'SS-SELF-9842',
                relationship: 'Self',
                gender: 'Male',
                name: currentUser ? currentUser.name : 'Guest Profile',
                age: currentUser ? (currentUser.age || '28') : '28',
                bloodGroup: currentUser ? (currentUser.bloodGroup || 'B+') : 'B+',
                phone: currentUser ? (currentUser.phone || '+91 98765 43210') : '+91 98765 43210',
                conditions: 'None',
                allergies: 'None',
                medications: 'None',
                surgeries: 'None',
                vaccines: 'None',
                address: 'New Delhi, India'
            });
            localStorage.setItem('sehatsathi_family_profiles', JSON.stringify(familyProfiles));
        }

        // Update dropdown
        const updateProfileDropdown = () => {
            if (!profileSelect) return;
            profileSelect.innerHTML = '';
            familyProfiles.forEach((prof, idx) => {
                const opt = document.createElement('option');
                opt.value = idx.toString();
                opt.textContent = `${prof.relationship}: ${prof.name}`;
                profileSelect.appendChild(opt);
            });
        };

        const updatePreview = (prof) => {
            if (!prof) return;
            if (previewName) previewName.textContent = prof.name;
            if (previewId) previewId.textContent = prof.id;
            if (previewAge) previewAge.textContent = prof.age;
            if (previewGender) previewGender.textContent = prof.gender;
            if (previewBlood) previewBlood.textContent = prof.bloodGroup || '--';
            if (previewRelationship) previewRelationship.textContent = prof.relationship;
            if (previewPhone) previewPhone.textContent = prof.phone;
            if (previewConditions) previewConditions.textContent = prof.conditions || 'None';
            if (previewAllergies) previewAllergies.textContent = prof.allergies || 'None';
            if (previewMedications) previewMedications.textContent = prof.medications || 'None';
            if (previewSurgeries) previewSurgeries.textContent = prof.surgeries || 'None';
            if (previewVaccines) previewVaccines.textContent = prof.vaccines || 'None';
            if (previewAddress) previewAddress.textContent = prof.address || 'None';

            // Generate QR Code
            if (qrImg) {
                const qrText = `Name: ${prof.name}\nID: ${prof.id}\nRelationship: ${prof.relationship}\nAge: ${prof.age}\nGender: ${prof.gender}\nBlood: ${prof.bloodGroup}\nPhone: ${prof.phone}\nConditions: ${prof.conditions}\nAllergies: ${prof.allergies}\nMedications: ${prof.medications}\nSurgeries: ${prof.surgeries}\nVaccines: ${prof.vaccines}\nAddress: ${prof.address}`;
                qrImg.src = `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${encodeURIComponent(qrText)}`;
            }
        };

        const loadProfileToForm = (prof) => {
            if (!prof) return;
            if (relationshipInput) relationshipInput.value = prof.relationship;
            if (genderInput) genderInput.value = prof.gender;
            if (nameInput) nameInput.value = prof.name;
            if (ageInput) ageInput.value = prof.age;
            if (bloodInput) bloodInput.value = prof.bloodGroup;
            if (phoneInput) phoneInput.value = prof.phone;
            if (conditionsInput) conditionsInput.value = prof.conditions;
            if (allergiesInput) allergiesInput.value = prof.allergies;
            if (medicationsInput) medicationsInput.value = prof.medications;
            if (surgeriesInput) surgeriesInput.value = prof.surgeries || '';
            if (vaccinesInput) vaccinesInput.value = prof.vaccines || '';
            if (addressInput) addressInput.value = prof.address || '';
            updatePreview(prof);
        };

        // Profile select change listener
        if (profileSelect) {
            profileSelect.addEventListener('change', () => {
                const idx = parseInt(profileSelect.value);
                if (familyProfiles[idx]) {
                    loadProfileToForm(familyProfiles[idx]);
                }
            });
        }

        // Add member button click
        if (addMemberBtn) {
            addMemberBtn.addEventListener('click', () => {
                const isHindi = localStorage.getItem('sehatsathi_lang') === 'hi';
                const nextRel = 'Child';
                const newMemberName = isHindi ? 'नया सदस्य' : 'New Member';
                
                const newProf = {
                    id: 'SS-' + nextRel.substring(0, 4).toUpperCase() + '-' + Math.floor(1000 + Math.random() * 9000),
                    relationship: nextRel,
                    gender: 'Female',
                    name: newMemberName,
                    age: '10',
                    bloodGroup: 'O+',
                    phone: '+91 98765 43210',
                    conditions: 'None',
                    allergies: 'None',
                    medications: 'None',
                    surgeries: 'None',
                    vaccines: 'None',
                    address: 'New Delhi, India'
                };
                familyProfiles.push(newProf);
                localStorage.setItem('sehatsathi_family_profiles', JSON.stringify(familyProfiles));
                updateProfileDropdown();
                profileSelect.value = (familyProfiles.length - 1).toString();
                loadProfileToForm(newProf);
            });
        }

        // Save & Generate card button click
        if (genBtn) {
            genBtn.addEventListener('click', () => {
                const idx = parseInt(profileSelect.value);
                if (familyProfiles[idx]) {
                    familyProfiles[idx].relationship = relationshipInput.value;
                    familyProfiles[idx].gender = genderInput.value;
                    familyProfiles[idx].name = nameInput.value.trim() || 'New Profile';
                    familyProfiles[idx].age = ageInput.value.trim() || '28';
                    familyProfiles[idx].bloodGroup = bloodInput.value;
                    familyProfiles[idx].phone = phoneInput.value.trim() || '+91 98765 43210';
                    familyProfiles[idx].conditions = conditionsInput.value.trim() || 'None';
                    familyProfiles[idx].allergies = allergiesInput.value.trim() || 'None';
                    familyProfiles[idx].medications = medicationsInput.value.trim() || 'None';
                    familyProfiles[idx].surgeries = surgeriesInput.value.trim() || 'None';
                    familyProfiles[idx].vaccines = vaccinesInput.value.trim() || 'None';
                    familyProfiles[idx].address = addressInput.value.trim() || 'None';

                    localStorage.setItem('sehatsathi_family_profiles', JSON.stringify(familyProfiles));
                    
                    // Update dropdown display names
                    const activeIdx = profileSelect.value;
                    updateProfileDropdown();
                    profileSelect.value = activeIdx;

                    updatePreview(familyProfiles[idx]);
                    
                    const isHindi = localStorage.getItem('sehatsathi_lang') === 'hi';
                    alert(isHindi 
                        ? "पारिवारिक स्वास्थ्य कार्ड सफलतापूर्वक सहेजा गया और जनरेट हुआ!" 
                        : "Family Health Card generated and saved successfully!");
                }
            });
        }

        // Initial setup
        updateProfileDropdown();
        if (familyProfiles[0]) {
            loadProfileToForm(familyProfiles[0]);
        }
    }

    // ==========================================
    // 10.6. PAGE INTERACTIONS: EMERGENCY FIRST AID
    // ==========================================
    if (pageName.includes('first-aid')) {
        const faContainer = document.getElementById('first-aid-container');
        if (faContainer) {
            // Detailed list of 20 emergency first-aid topics
            const firstAidTopics = [
                {
                    key: 'heart_attack', icon: 'cardiology', severity: 'critical',
                    catEn: 'Cardiology', catHi: 'हृदय रोग',
                    nameEn: 'Heart Attack', nameHi: 'दिल का दौरा',
                    descEn: 'A life-threatening medical emergency where blood flow to the heart muscle is severely blocked.',
                    descHi: 'एक जीवन-घातक चिकित्सा आपातकाल जहां हृदय की मांसपेशियों में रक्त का प्रवाह गंभीर रूप से अवरुद्ध हो जाता है।',
                    dosEn: ['Call emergency help immediately.', 'Have the patient chew an aspirin (if not allergic).', 'Keep them calm and sitting upright.'],
                    dosHi: ['तुरंत आपातकालीन चिकित्सा सहायता बुलाएं।', 'मरीज को एक एस्पिरिन चबाने दें (यदि एलर्जी न हो)।', 'उन्हें शांत रखें और सीधे बैठाएं।'],
                    dontsEn: ['Do not leave the patient alone.', 'Do not let them walk or exert physical effort.', 'Do not give water/food if unconscious.'],
                    dontsHi: ['मरीज को अकेला न छोड़ें।', 'उन्हें चलने या शारीरिक परिश्रम न करने दें।', 'बेहोश होने पर पानी/भोजन न दें।'],
                    warningEn: 'Crushing chest pain radiating to arm, neck or jaw, shortness of breath, cold sweats.',
                    warningHi: 'बांह, गर्दन या जबड़े में फैलने वाला तेज सीने में दर्द, सांस की तकलीफ, ठंडा पसीना आना।'
                },
                {
                    key: 'stroke', icon: 'psychiatry', severity: 'critical',
                    catEn: 'Neurology', catHi: 'मस्तिष्क रोग',
                    nameEn: 'Stroke', nameHi: 'लकवा (मस्तिष्क आघात)',
                    descEn: 'Interruption of blood flow to the brain, causing rapid neurological cell damage.',
                    descHi: 'मस्तिष्क में रक्त के प्रवाह में व्यवधान, जिससे तंत्रिका कोशिकाओं को तेजी से नुकसान पहुंचता है।',
                    dosEn: ['Think F.A.S.T.: Face drooping, Arm weakness, Speech difficulty, Time to call help.', 'Note the exact time symptoms started.', 'Place them on their side if vomiting.'],
                    dosHi: ['F.A.S.T. याद रखें: चेहरा लटकना, हाथ की कमजोरी, बोलने में कठिनाई, मदद बुलाने का समय।', 'लक्षण शुरू होने का सटीक समय नोट करें।', 'उल्टी होने पर उन्हें करवट दिलाकर लेटाएं।'],
                    dontsEn: ['Do not give aspirin or other blood thinners.', 'Do not offer food, water, or medication.'],
                    dontsHi: ['एस्पिरिन या अन्य खून पतला करने वाली दवाएं न दें।', 'भोजन, पानी या कोई अन्य दवा न दें।'],
                    warningEn: 'Sudden numbness in face/limb, confusion, difficulty speaking or understanding, severe headache.',
                    warningHi: 'चेहरे/हाथ-पैर में अचानक सुन्नता, भ्रम, बोलने या समझने में कठिनाई, तेज सिरदर्द।'
                },
                {
                    key: 'severe_bleeding', icon: 'bloodtype', severity: 'critical',
                    catEn: 'Trauma', catHi: 'चोट/आघात',
                    nameEn: 'Severe Bleeding', nameHi: 'अत्यधिक रक्तस्राव',
                    descEn: 'Rapid loss of blood from wounds or severed arteries which can lead to shock and death.',
                    descHi: 'घावों या कटी हुई धमनियों से तेजी से रक्त का बहना जो सदमे (शॉक) और मृत्यु का कारण बन सकता है।',
                    dosEn: ['Apply firm, direct pressure on the wound with clean cloth.', 'Elevate the injured limb above heart level.', 'Keep patient warm and lying flat.'],
                    dosHi: ['साफ कपड़े से घाव पर सीधा और मजबूत दबाव डालें।', 'घायल अंग को हृदय के स्तर से ऊपर उठाएं।', 'मरीज को गर्म रखें और सीधा लेटाएं।'],
                    dontsEn: ['Do not remove embedded objects from the wound.', 'Do not lift the cloth to check bleeding; add more layers instead.'],
                    dontsHi: ['घाव में धंसी हुई वस्तुओं को बाहर न निकालें।', 'रक्तस्राव देखने के लिए पट्टी न हटाएं; ऊपर से और कपड़ा लपेटें।'],
                    warningEn: 'Spurting blood, pools of blood forming on ground, skin turning pale or cold.',
                    warningHi: 'फव्वारे की तरह खून बहना, जमीन पर खून जमा होना, त्वचा का पीला या ठंडा पड़ना।'
                },
                {
                    key: 'choking', icon: 'airwave', severity: 'critical',
                    catEn: 'Respiratory', catHi: 'श्वसन क्रिया',
                    nameEn: 'Choking', nameHi: 'गले में सांस अटकना',
                    descEn: 'Physical obstruction of the airway preventing breathing.',
                    descHi: 'वायुमार्ग में भौतिक रुकावट जिससे सांस लेने में असमर्थता होती है।',
                    dosEn: ['If conscious, perform Heimlich maneuver (abdominal thrusts).', 'Give 5 back blows between shoulder blades followed by 5 abdominal thrusts.', 'Call emergency immediately.'],
                    dosHi: ['यदि होश में है, तो हेइमलीक पैंतरा (पेट पर झटका) अपनाएं।', 'पीठ पर कंधे की हड्डियों के बीच 5 बार थपथपाएं और फिर 5 बार पेट दबाएं।', 'तुरंत आपातकालीन सहायता बुलाएं।'],
                    dontsEn: ['Do not try finger sweeps unless the object is clearly visible and reachable.', 'Do not give water or ask them to drink.'],
                    dontsHi: ['उंगली से वस्तु निकालने का प्रयास न करें जब तक वह स्पष्ट रूप से दिखाई न दे।', 'उन्हें पीने के लिए पानी न दें।'],
                    warningEn: 'Inability to speak, gasp, or cough; clutching throat with hands.',
                    warningHi: 'बोलने, सांस लेने या खांसने में असमर्थता; हाथों से गला पकड़ना।'
                },
                {
                    key: 'burns', icon: 'local_fire_department', severity: 'high',
                    catEn: 'Trauma', catHi: 'चोट/आघात',
                    nameEn: 'Burns & Scalds', nameHi: 'जलना और झुलसना',
                    descEn: 'Damage to the skin tissues caused by heat, steam, hot liquids, or fire.',
                    descHi: 'गर्मी, भाप, गर्म तरल पदार्थ या आग के कारण त्वचा के ऊतकों को होने वाला नुकसान।',
                    dosEn: ['Cool the burn immediately under cool running water for 10-20 minutes.', 'Remove rings or tight items near burn before swelling starts.', 'Cover with clean plastic cling wrap loosely.'],
                    dosHi: ['जलने वाले स्थान को तुरंत बहते ठंडे पानी के नीचे 10-20 मिनट तक रखें।', 'सूजन शुरू होने से पहले अंगूठियां या टाइट चीजें हटा दें।', 'साफ प्लास्टिक रैप से ढीला ढकें।'],
                    dontsEn: ['Do not apply ice, butter, toothpaste, or ointments.', 'Do not pop or break blisters.', 'Do not peel away stuck clothing.'],
                    dontsHi: ['बर्फ, मक्खन, टूथपेस्ट या मलहम न लगाएं।', 'फफोले या छालों को न फोड़ें।', 'चिपके हुए कपड़ों को न खींचे।'],
                    warningEn: 'Charred black skin, white patches, blistering over large area, burns on face or airway.',
                    warningHi: 'त्वचा का काला पड़ना, सफेद धब्बे, बड़े हिस्से में फफोले, चेहरे या श्वास नली का जलना।'
                },
                {
                    key: 'snake_bite', icon: 'pest_control', severity: 'critical',
                    catEn: 'Bites & Poison', catHi: 'काटना और जहर',
                    nameEn: 'Snake Bite', nameHi: 'साँप का काटना',
                    descEn: 'Envenomation from venomous snake species requiring immediate antivenom therapy.',
                    descHi: 'जहरीले सांपों द्वारा काटना जिसके लिए तत्काल एंटी-वेनम थेरेपी की आवश्यकता होती है।',
                    dosEn: ['Keep the patient calm and completely still (venom spreads with movement).', 'Immobilize the bitten limb at or below heart level.', 'Note snake details if safe.'],
                    dosHi: ['मरीज को पूरी तरह शांत और स्थिर रखें (हिलने-डुलने से जहर फैलता है)।', 'कटे हुए अंग को हृदय के स्तर से नीचे स्थिर रखें।', 'सुरक्षित होने पर सांप के विवरण को नोट करें।'],
                    dontsEn: ['Do not try to suck out the venom.', 'Do not apply ice, incisions, or tight tourniquets.', 'Do not try to capture the snake.'],
                    dontsHi: ['जहर को मुंह से चूसने की कोशिश न करें।', 'बर्फ न लगाएं, चीरा न लगाएं या कसकर पट्टी न बांधें।', 'सांप को पकड़ने की कोशिश न करें।'],
                    warningEn: 'Two puncture marks, rapid swelling, numbness, blurred vision, difficulty breathing.',
                    warningHi: 'दो दांतों के निशान, तेजी से सूजन, सुन्नता, धुंधली दृष्टि, सांस लेने में तकलीफ।'
                },
                {
                    key: 'dog_bite', icon: 'pets', severity: 'high',
                    catEn: 'Bites & Poison', catHi: 'काटना और जहर',
                    nameEn: 'Dog & Animal Bite', nameHi: 'कुत्ते या जानवर का काटना',
                    descEn: 'Injury from animal teeth which presents a high risk of Rabies and Tetanus infections.',
                    descHi: 'जानवर के दांतों से लगने वाली चोट जिससे रेबीज और टिटनेस संक्रमण का उच्च जोखिम होता है।',
                    dosEn: ['Wash the wound immediately under running tap water with soap for 10-15 minutes.', 'Apply clean antiseptic cream.', 'Seek doctor for post-exposure vaccines.'],
                    dosHi: ['घाव को तुरंत बहते पानी के नीचे साबुन से 10-15 मिनट तक धोएं।', 'साफ एंटीसेप्टिक क्रीम लगाएं।', 'रेबीज/टिटनेस के टीकों के लिए तुरंत डॉक्टर से मिलें।'],
                    dontsEn: ['Do not cover the wound with tight dressings.', 'Do not ignore even minor scratches from stray animals.'],
                    dontsHi: ['घाव को कसकर पट्टी से न ढकें।', 'आवारा जानवरों द्वारा किए गए छोटे खरोंचों को भी नजरअंदाज न करें।'],
                    warningEn: 'Deep puncture wounds, bleeding that won\'t stop, animal showing aggressive/erratic behavior.',
                    warningHi: 'गहरे घाव, रक्तस्राव जो बंद नहीं होता, जानवर का आक्रामक या असामान्य व्यवहार।'
                },
                {
                    key: 'fracture', icon: 'personal_injury', severity: 'medium',
                    catEn: 'Trauma', catHi: 'चोट/आघात',
                    nameEn: 'Bone Fracture', nameHi: 'हड्डी का टूटना (फ्रैक्चर)',
                    descEn: 'Breaks or cracks in bones due to fall, impact, or trauma.',
                    descHi: 'गिरने, प्रभाव या चोट के कारण हड्डियों का टूटना या दरार आना।',
                    dosEn: ['Support and immobilize the fractured bone using cardboard or splints.', 'Apply ice pack wrapped in cloth to reduce swelling.', 'Control any external bleeding.'],
                    dosHi: ['कार्डबोर्ड या खपच्चियों का उपयोग करके टूटी हड्डी को सहारा दें और स्थिर रखें।', 'सूजन कम करने के लिए कपड़े में लिपटा बर्फ लगाएं।', 'किसी भी बाहरी रक्तस्राव को नियंत्रित करें।'],
                    dontsEn: ['Do not try to realign or push back protruding bones.', 'Do not massage or move the injured limb.'],
                    dontsHi: ['बाहर निकली हुई हड्डियों को सीधा करने या अंदर धकेलने का प्रयास न करें।', 'घायल अंग की मालिश न करें या उसे न हिलाएं।'],
                    warningEn: 'Deformity of limb, severe pain on touching, bone piercing through skin, cracking sound.',
                    warningHi: 'अंग की विकृति, छूने पर तीव्र दर्द, त्वचा को भेदकर बाहर निकली हड्डी, टूटने की आवाज।'
                },
                {
                    key: 'sprain', icon: 'healing', severity: 'low',
                    catEn: 'Trauma', catHi: 'चोट/आघात',
                    nameEn: 'Sprains & Strains', nameHi: 'मोच और खिंचाव',
                    descEn: 'Stretching or tearing of ligaments or muscles around joints.',
                    descHi: 'जोड़ों के आसपास स्नायुबंधन (लिगामेंट) या मांसपेशियों का खिंचना या फटना।',
                    dosEn: ['Use R.I.C.E. method: Rest, Ice, Compression, Elevation.', 'Wrap with an elastic bandage firmly but not too tight.', 'Elevate the limb.'],
                    dosHi: ['R.I.C.E. विधि का पालन करें: आराम, बर्फ, दबाव (पट्टी), ऊंचाई।', 'लोचदार (इलास्टिक) पट्टी से मजबूती से लेकिन ज्यादा कसकर नहीं बांधें।', 'अंग को ऊपर उठाएं।'],
                    dontsEn: ['Do not apply heat or massage in the first 48 hours.', 'Do not walk or put weight on the injured joint.'],
                    dontsHi: ['पहले 48 घंटों में गर्म सिकाई या मालिश न करें।', 'घायल जोड़ पर वजन न डालें या चलें नहीं।'],
                    warningEn: 'Severe swelling, immediate bruising, inability to move or bear weight on the joint.',
                    warningHi: 'गंभीर सूजन, तुरंत नीला पड़ना, जोड़ को हिलाने या उस पर वजन उठाने में असमर्थता।'
                },
                {
                    key: 'heat_stroke', icon: 'thermostat', severity: 'high',
                    catEn: 'Environmental', catHi: 'पर्यावरणीय',
                    nameEn: 'Heat Stroke', nameHi: 'लू लगना (हीट स्ट्रोक)',
                    descEn: 'A severe condition where the body temperature rises above 40°C due to extreme heat exposure.',
                    descHi: 'एक गंभीर स्थिति जहां अत्यधिक गर्मी के संपर्क में आने से शरीर का तापमान 40°C से ऊपर बढ़ जाता है।',
                    dosEn: ['Move the person to a cool, shaded area immediately.', 'Cool the body rapidly with wet sheets, cold water sprays, or ice packs on neck/armpits.', 'Fanning the patient.'],
                    dosHi: ['व्यक्ति को तुरंत ठंडे, छायादार स्थान पर ले जाएं।', 'गीली चादरों, ठंडे पानी के छिड़काव, या गर्दन/बगल में बर्फ रखकर शरीर को तेजी से ठंडा करें।', 'मरीज को हवा करें।'],
                    dontsEn: ['Do not give fluids if they are confused, vomiting, or semi-conscious.', 'Do not apply ice directly to skin without wrapping.'],
                    dontsHi: ['यदि वे भ्रमित हैं, उल्टी कर रहे हैं, या अर्ध-बेहोश हैं तो तरल पदार्थ न दें।', 'बिना लपेटे बर्फ सीधे त्वचा पर न लगाएं।'],
                    warningEn: 'High body temperature (>103°F), hot, red, dry skin, rapid pulse, confusion, seizures.',
                    warningHi: 'उच्च शरीर का तापमान (>103°F), गर्म, लाल, सूखी त्वचा, तेज नाड़ी, भ्रम, दौरे।'
                },
                {
                    key: 'poisoning', icon: 'science', severity: 'critical',
                    catEn: 'Bites & Poison', catHi: 'काटना और जहर',
                    nameEn: 'Poisoning', nameHi: 'विषाक्तता (जहर खाना)',
                    descEn: 'Ingestion, inhalation, or skin absorption of toxic chemicals or overdoses.',
                    descHi: 'जहरीले रसायनों को निगलना, सांस द्वारा अंदर लेना, या त्वचा द्वारा सोखना।',
                    dosEn: ['Call poison control or emergency services immediately.', 'Identify the substance and container if possible.', 'If on skin, wash with running water for 15 minutes.'],
                    dosHi: ['तुरंत आपातकालीन सेवाओं या जहर नियंत्रण केंद्र को फोन करें।', 'यदि संभव हो तो पदार्थ और उसके कंटेनर की पहचान करें।', 'यदि त्वचा पर है, तो 15 मिनट तक बहते पानी से धोएं।'],
                    dontsEn: ['Do not induce vomiting unless specifically instructed by a medical expert.', 'Do not give syrup of ipecac or charcoal blindly.'],
                    dontsHi: ['जब तक किसी चिकित्सा विशेषज्ञ द्वारा विशेष रूप से न कहा जाए, उल्टी कराने का प्रयास न करें।', 'अंधाधुंध कोई सिरप या कोयला न खिलाएं।'],
                    warningEn: 'Vomiting, burns around mouth, unusual breath odor, drowsiness, difficulty breathing, seizures.',
                    warningHi: 'उल्टी, मुंह के आसपास जलन/लालिमा, सांस से असामान्य गंध, उनींदापन, सांस लेने में कठिनाई, दौरे।'
                },
                {
                    key: 'chemical_burn', icon: 'science', severity: 'high',
                    catEn: 'Trauma', catHi: 'चोट/आघात',
                    nameEn: 'Chemical Burn', nameHi: 'रासायनिक जलन',
                    descEn: 'Corrosive tissue damage caused by strong acids, alkalis, or industrial chemicals.',
                    descHi: 'तीव्र एसिड, क्षार या औद्योगिक रसायनों के कारण होने वाला संक्षारक ऊतक नुकसान।',
                    dosEn: ['Flush the area immediately with large amounts of cool running water for at least 20 minutes.', 'Remove contaminated clothing or jewelry.', 'Cover with loose dry sterile dressing.'],
                    dosHi: ['कम से कम 20 मिनट तक ठंडे बहते पानी की प्रचुर मात्रा से जले हिस्से को धोएं।', 'दूषित कपड़े या आभूषण तुरंत हटा दें।', 'सूखी जीवाणुहीन पट्टी से ढीला ढकें।'],
                    dontsEn: ['Do not apply neutralizing agents like vinegar or soda.', 'Do not rub or scrub the affected skin.'],
                    dontsHi: ['सिरका या सोडा जैसे निष्क्रिय करने वाले पदार्थों को न लगाएं।', 'प्रभावित त्वचा को न रगड़ें।'],
                    warningEn: 'Severe pain, redness, skin peeling, white or grey patches, blistering on chemical contact.',
                    warningHi: 'गंभीर दर्द, लालिमा, त्वचा का निकलना, सफेद या भूरे रंग के धब्बे, रसायनों के संपर्क में फफोले पड़ना।'
                },
                {
                    key: 'electric_shock', icon: 'bolt', severity: 'critical',
                    catEn: 'Trauma', catHi: 'चोट/आघात',
                    nameEn: 'Electric Shock', nameHi: 'बिजली का झटका',
                    descEn: 'Injuries caused by contact with high-voltage electrical currents.',
                    descHi: 'उच्च वोल्टेज वाले विद्युत प्रवाह के संपर्क में आने से होने वाली क्षति।',
                    dosEn: ['Separate patient from source using non-conductive object (wood/plastic). Turn off mains.', 'Check breathing; start CPR if not breathing.', 'Treat any visible entry/exit burns.'],
                    dosHi: ['मरीज को बिजली के स्रोत से अलग करने के लिए कुचालक वस्तु (लकड़ी/प्लास्टिक) का उपयोग करें। मुख्य स्विच बंद करें।', 'सांस की जांच करें; सांस न लेने पर सीपीआर (CPR) शुरू करें।', 'प्रवेश और निकास के घावों का इलाज करें।'],
                    dontsEn: ['Do not touch the patient while they are still in contact with electrical current.', 'Do not go near high-voltage lines.'],
                    dontsHi: ['जब तक मरीज विद्युत प्रवाह के संपर्क में है, उन्हें न छुएं।', 'हाई-वॉलटेज लाइनों के करीब न जाएं।'],
                    warningEn: 'No pulse, not breathing, visible electrical burn marks on body, muscle spasms, unconsciousness.',
                    warningHi: 'नाड़ी न चलना, सांस न लेना, शरीर पर बिजली से जलने के निशान, मांसपेशियों में ऐंठन, बेहोशी।'
                },
                {
                    key: 'nosebleed', icon: 'medical_services', severity: 'low',
                    catEn: 'Trauma', catHi: 'चोट/आघात',
                    nameEn: 'Nosebleed', nameHi: 'नाक से खून बहना (नकसीर)',
                    descEn: 'Bleeding from blood vessels inside the nasal passages, commonly due to dry air or trauma.',
                    descHi: 'नाक के मार्ग के भीतर रक्त वाहिकाओं से खून बहना, आमतौर पर सूखी हवा या चोट के कारण।',
                    dosEn: ['Sit upright and lean forward slightly.', 'Pinch the soft part of the nose below the bridge for 10-15 minutes.', 'Breathe through the mouth and apply a cold compress to the bridge of the nose.'],
                    dosHi: ['सीधे बैठें और थोड़ा आगे की ओर झुकें।', 'नाक के निचले मुलायम हिस्से को 10-15 मिनट तक दबाकर रखें।', 'मुंह से सांस लें और नाक के ऊपर ठंडी सिकाई करें।'],
                    dontsEn: ['Do not tilt the head backward (swallowing blood can cause vomiting).', 'Do not blow or pick the nose for several hours after bleeding stops.'],
                    dontsHi: ['सिर को पीछे की ओर न झुकाएं (खून निगलने से उल्टी हो सकती है)।', 'खून बंद होने के बाद कई घंटों तक नाक न साफ करें और न ही उंगली डालें।'],
                    warningEn: 'Bleeding that continues for more than 20 minutes, bleeding after head trauma, difficulty breathing.',
                    warningHi: 'रक्तस्राव जो 20 मिनट से अधिक समय तक जारी रहता है, सिर की चोट के बाद नाक बहना, सांस लेने में कठिनाई।'
                },
                {
                    key: 'asthma_attack', icon: 'airwave', severity: 'high',
                    catEn: 'Respiratory', catHi: 'श्वसन क्रिया',
                    nameEn: 'Asthma Attack', nameHi: 'दमा का दौरा',
                    descEn: 'Severe airway narrowing, causing wheezing and extreme difficulty in inhaling/exhaling.',
                    descHi: 'वायुमार्ग का अत्यधिक संकुचित होना, जिससे घरघराहट और सांस लेने/छोड़ने में अत्यधिक कठिनाई होती है।',
                    dosEn: ['Sit the person comfortably upright.', 'Help them administer 2-4 puffs of their rescue inhaler (albuterol/salbutamol).', 'Keep them calm and encourage slow breathing.'],
                    dosHi: ['व्यक्ति को आराम से सीधा बैठाएं।', 'उनकी इनहेलर (बचाव इनहेलर) की 2-4 पफ लेने में मदद करें।', 'उन्हें शांत रखें और धीमी सांस लेने के लिए प्रोत्साहित करें।'],
                    dontsEn: ['Do not lay the patient flat.', 'Do not force them to walk or talk.'],
                    dontsHi: ['मरीज को सीधा (सपाट) न लेटाएं।', 'उन्हें चलने या बात करने के लिए मजबूर न करें।'],
                    warningEn: 'Inability to speak in full sentences, chest retractions, blue lips/fingertips, inhaler provides no relief.',
                    warningHi: 'पूरे वाक्य बोलने में असमर्थता, छाती का धंसना, नीले होंठ/उंगलियां, इनहेलर से राहत न मिलना।'
                },
                {
                    key: 'anaphylaxis', icon: 'emergency', severity: 'critical',
                    catEn: 'Respiratory', catHi: 'श्वसन क्रिया',
                    nameEn: 'Anaphylaxis (Allergic)', nameHi: 'तीव्र एलर्जी (एनाफिलेक्सिस)',
                    descEn: 'A severe, rapid, and life-threatening systemic allergic reaction.',
                    descHi: 'एक गंभीर, तीव्र और जीवन-घातक प्रणालीगत एलर्जी प्रतिक्रिया।',
                    dosEn: ['Call emergency response immediately.', 'Administer epinephrine auto-injector (EpiPen) into the outer thigh if available.', 'Lay them flat with legs raised.'],
                    dosHi: ['तुरंत आपातकालीन चिकित्सा सहायता बुलाएं।', 'उपलब्ध होने पर बाहरी जांघ में एपिनेफ्रीन ऑटो-इंजेक्टर (एपिपेन) लगाएं।', 'पैरों को ऊपर उठाकर सीधा लेटाएं।'],
                    dontsEn: ['Do not give oral medication if they are struggling to breathe.', 'Do not let them stand or walk.'],
                    dontsHi: ['सांस लेने में कठिनाई होने पर मुंह से कोई दवा न दें।', 'उन्हें खड़ा होने या चलने न दें।'],
                    warningEn: 'Swelling of throat/tongue, difficulty breathing, wheezing, hives/rash, rapid pulse drop, dizziness.',
                    warningHi: 'गले/जीभ की सूजन, सांस लेने में तकलीफ, घरघराहट, पित्ती/चकत्ते, नाड़ी की गति में अचानक गिरावट, चक्कर आना।'
                },
                {
                    key: 'seizure', icon: 'psychiatry', severity: 'high',
                    catEn: 'Neurology', catHi: 'मस्तिष्क रोग',
                    nameEn: 'Seizure / Fit', nameHi: 'दौरा या मिर्गी',
                    descEn: 'Sudden, uncontrolled electrical disturbance in the brain causing convulsions.',
                    descHi: 'मस्तिष्क में अचानक, अनियंत्रित विद्युत गड़बड़ी जिससे शरीर में ऐंठन और झटके आते हैं।',
                    dosEn: ['Clear the surrounding area of sharp objects.', 'Place something soft under their head.', 'Turn the person gently onto one side once shaking stops.'],
                    dosHi: ['आसपास के क्षेत्र से नुकीली वस्तुओं को हटा दें।', 'मरीज के सिर के नीचे कुछ मुलायम कपड़ा या तकिया रखें।', 'झटके रुकने पर व्यक्ति को धीरे से करवट दिलाकर लेटाएं।'],
                    dontsEn: ['Do not hold the person down or restrict their movements.', 'Do not put anything (spoon, fingers, water) in their mouth.'],
                    dontsHi: ['व्यक्ति को जकड़ कर न रखें या उनके हिलने-डुलने को न रोकें।', 'उनके मुंह में कोई वस्तु (चम्मच, उंगली, पानी) न डालें।'],
                    warningEn: 'Seizure lasting longer than 5 minutes, multiple seizures without recovering consciousness, pregnant patient.',
                    warningHi: 'दौरा 5 मिनट से अधिक समय तक चलना, होश में आए बिना बार-बार दौरे आना, गर्भवती मरीज होना।'
                },
                {
                    key: 'drowning', icon: 'pool', severity: 'critical',
                    catEn: 'Respiratory', catHi: 'श्वसन क्रिया',
                    nameEn: 'Drowning', nameHi: 'डूबना',
                    descEn: 'Suffocation or respiratory impairment due to submersion in water.',
                    descHi: 'पानी में डूबने के कारण दम घुटना या सांस लेने में असमर्थता।',
                    dosEn: ['Pull the victim out of water safely.', 'Check for breathing; start rescue breaths and CPR immediately if not breathing.', 'Keep them warm by removing wet clothing.'],
                    dosHi: ['पीड़ित को पानी से सुरक्षित बाहर निकालें।', 'सांस की जांच करें; सांस न चलने पर तुरंत कृत्रिम सांस और सीपीआर (CPR) शुरू करें।', 'गीले कपड़े उतारकर उन्हें गर्म रखें।'],
                    dontsEn: ['Do not attempt rescue if it puts your own life at risk.', 'Do not try to force water out of the stomach.'],
                    dontsHi: ['यदि आपके अपने जीवन को खतरा हो तो पानी में कूदकर बचाने का प्रयास न करें।', 'पेट से पानी बाहर निकालने के लिए दबाव न डालें।'],
                    warningEn: 'Not breathing, bluish skin color, coughing up frothy fluid, cold body.',
                    warningHi: 'सांस न लेना, त्वचा का नीला पड़ना, झागदार थूक खांसना, शरीर का ठंडा पड़ना।'
                },
                {
                    key: 'fainting', icon: 'bed', severity: 'medium',
                    catEn: 'Neurology', catHi: 'मस्तिष्क रोग',
                    nameEn: 'Fainting (Syncope)', nameHi: 'बेहोशी (अल्पकालिक)',
                    descEn: 'Temporary loss of consciousness due to a sudden drop in blood flow to the brain.',
                    descHi: 'मस्तिष्क में रक्त के प्रवाह में अचानक गिरावट के कारण चेतना का अल्पकालिक नुकसान।',
                    dosEn: ['Lay the person flat on their back.', 'Elevate their legs about 12 inches (30 cm) to restore blood flow.', 'Loosen collars, belts, or tight clothes.'],
                    dosHi: ['व्यक्ति को पीठ के बल सीधा लेटाएं।', 'रक्त प्रवाह बहाल करने के लिए उनके पैरों को लगभग 12 इंच (30 सेमी) ऊपर उठाएं।', 'कॉलर, बेल्ट या तंग कपड़े ढीले करें।'],
                    dontsEn: ['Do not give water or food until they are fully awake and alert.', 'Do not let them stand up too quickly after waking.'],
                    dontsHi: ['पूरी तरह होश में आने से पहले उन्हें पानी या भोजन न दें।', 'होश में आने के बाद उन्हें बहुत जल्दी खड़ा न होने दें।'],
                    warningEn: 'Fainting accompanied by chest pain, shortness of breath, confusion, or inability to speak.',
                    warningHi: 'बेहोशी के साथ सीने में दर्द, सांस की तकलीफ, भ्रम, या बोलने में असमर्थता होना।'
                },
                {
                    key: 'head_injury', icon: 'personal_injury', severity: 'critical',
                    catEn: 'Trauma', catHi: 'चोट/आघात',
                    nameEn: 'Head Injury / Concussion', nameHi: 'सिर की गंभीर चोट',
                    descEn: 'Trauma to the scalp, skull, or brain, ranging from a minor bump to severe brain injury.',
                    descHi: 'खोपड़ी या मस्तिष्क पर चोट, जो एक छोटे से उभार से लेकर मस्तिष्क की गंभीर क्षति तक हो सकती है।',
                    dosEn: ['Keep the patient lying down and still with head slightly elevated.', 'Apply firm pressure with clean cloth to control scalp bleeding.', 'Keep airway clear.'],
                    dosHi: ['मरीज को सिर को थोड़ा ऊंचा रखकर सीधा और स्थिर लेटाए रखें।', 'रक्तस्राव को रोकने के लिए साफ कपड़े से मजबूत दबाव डालें।', 'श्वास मार्ग साफ रखें।'],
                    dontsEn: ['Do not wash a deep head wound.', 'Do not remove any helmet if neck/spine injury is suspected.', 'Do not let them fall asleep if confused.'],
                    dontsHi: ['सिर के गहरे घाव को न धोएं।', 'गर्दन/रीढ़ की चोट का संदेह होने पर हेलमेट न हटाएं।', 'भ्रमित होने की स्थिति में उन्हें सोने न दें।'],
                    warningEn: 'Clear fluid/blood leaking from nose or ears, confusion, persistent vomiting, unequal pupil sizes, loss of memory.',
                    warningHi: 'नाक या कान से साफ तरल/खून बहना, भ्रम, लगातार उल्टी होना, पुतलियों का असमान आकार, याददाश्त खोना।'
                }
            ];

            const renderFirstAid = (catFilter, searchVal = '') => {
                const lang = localStorage.getItem('sehatsathi_lang') || 'en';
                faContainer.innerHTML = '';
                const query = searchVal.toLowerCase().replace(/[.,\/#!$%\^&\*;:{}=\-_`~()]/g,"").replace(/\s+/g," ").trim();

                const filtered = firstAidTopics.filter(topic => {
                    const name = (lang === 'hi' ? topic.nameHi : topic.nameEn).toLowerCase();
                    const desc = (lang === 'hi' ? topic.descHi : topic.descEn).toLowerCase();
                    const category = (lang === 'hi' ? topic.catHi : topic.catEn).toLowerCase();

                    // Category filter
                    if (catFilter && catFilter !== 'all') {
                        if (topic.catEn.toLowerCase() !== catFilter.toLowerCase()) return false;
                    }

                    // Search filter
                    if (query) {
                        const matchName = name.includes(query);
                        const matchDesc = desc.includes(query);
                        const matchCat = category.includes(query);
                        if (!matchName && !matchDesc && !matchCat) return false;
                    }
                    return true;
                });

                if (filtered.length === 0) {
                    faContainer.innerHTML = `<div class="col-span-full text-center text-on-surface-variant py-12">
                        <span class="material-symbols-outlined text-4xl mb-2 block">search_off</span>
                        <p>${lang === 'hi' ? 'कोई प्राथमिक चिकित्सा विषय नहीं मिला।' : 'No first aid topics found matching your criteria.'}</p>
                    </div>`;
                    return;
                }

                filtered.forEach(topic => {
                    const name = lang === 'hi' ? topic.nameHi : topic.nameEn;
                    const desc = lang === 'hi' ? topic.descHi : topic.descEn;
                    const category = lang === 'hi' ? topic.catHi : topic.catEn;
                    const dos = lang === 'hi' ? topic.dosHi : topic.dosEn;
                    const donts = lang === 'hi' ? topic.dontsHi : topic.dontsEn;
                    const warning = lang === 'hi' ? topic.warningHi : topic.warningEn;

                    const severityClass = {
                        critical: 'badge-critical',
                        high: 'badge-high',
                        medium: 'badge-medium',
                        low: 'badge-low'
                    }[topic.severity] || 'badge-low';

                    const severityLabel = lang === 'hi' ? {
                        critical: 'गंभीर / आपातकाल',
                        high: 'उच्च जोखिम',
                        medium: 'मध्यम',
                        low: 'सामान्य'
                    }[topic.severity] : topic.severity.toUpperCase();

                    let dosHtml = '';
                    dos.forEach(item => { dosHtml += `<li>${item}</li>`; });

                    let dontsHtml = '';
                    donts.forEach(item => { dontsHtml += `<li>${item}</li>`; });

                    const cardHtml = `
                        <div class="glass-card rounded-xl p-5 flex flex-col justify-between border border-white/5 bg-surface-container-low/40 relative overflow-hidden group transition-all duration-300">
                            <div>
                                <div class="flex items-start justify-between mb-4">
                                    <div class="flex items-center gap-3">
                                        <div class="bg-surface-container-high p-2 rounded-lg flex items-center justify-center text-secondary-fixed shadow-[0_0_10px_rgba(0,241,254,0.1)]">
                                            <span class="material-symbols-outlined text-lg" data-icon="${topic.icon}">${topic.icon}</span>
                                        </div>
                                        <div>
                                            <span class="text-[9px] bg-white/5 px-2 py-0.5 rounded text-on-surface-variant font-medium uppercase tracking-wider">${category}</span>
                                            <h2 class="font-title-md text-sm text-on-surface font-bold mt-0.5 leading-tight">${name}</h2>
                                        </div>
                                    </div>
                                    <span class="text-[9px] px-2 py-0.5 rounded font-bold uppercase tracking-wider ${severityClass}">${severityLabel}</span>
                                </div>
                                <p class="text-xs text-on-surface-variant/80 mb-3 leading-relaxed">${desc}</p>
                                
                                <div class="first-aid-expanded-details hidden space-y-3 mt-3 pt-3 border-t border-white/5">
                                    <div>
                                        <h3 class="text-[10px] text-tertiary uppercase font-bold tracking-wider mb-1">${lang === 'hi' ? 'क्या करें (Do\'s)' : 'Do\'s'}</h3>
                                        <ul class="list-disc list-inside text-xs text-on-surface-variant space-y-0.5">
                                            ${dosHtml}
                                        </ul>
                                    </div>
                                    <div>
                                        <h3 class="text-[10px] text-error uppercase font-bold tracking-wider mb-1">${lang === 'hi' ? 'क्या न करें (Don\'ts)' : 'Don\'ts'}</h3>
                                        <ul class="list-disc list-inside text-xs text-on-surface-variant space-y-0.5">
                                            ${dontsHtml}
                                        </ul>
                                    </div>
                                    <div class="bg-error/5 border border-error/10 p-2.5 rounded-lg mt-2">
                                        <h4 class="text-[10px] text-error font-bold uppercase tracking-wider mb-1">${lang === 'hi' ? 'चेतावनी के लक्षण' : 'Warning Signs'}</h4>
                                        <p class="text-xs text-on-surface-variant">${warning}</p>
                                    </div>
                                </div>
                            </div>
                            
                            <button class="toggle-first-aid-details w-full mt-4 py-1.5 border border-white/5 hover:border-secondary-fixed/30 hover:bg-secondary-fixed/5 rounded-lg flex items-center justify-center gap-1 text-[11px] text-secondary-fixed font-bold transition-all">
                                <span class="expand-icon material-symbols-outlined text-[14px]">expand_more</span>
                                <span>${lang === 'hi' ? 'अधिक विवरण देखें' : 'Toggle Details'}</span>
                            </button>
                        </div>
                    `;
                    faContainer.insertAdjacentHTML('beforeend', cardHtml);
                });
            };

            // Wire up Expand Details inside the container
            faContainer.addEventListener('click', (e) => {
                const btn = e.target.closest('.toggle-first-aid-details');
                if (btn) {
                    const card = btn.closest('.glass-card');
                    const details = card.querySelector('.first-aid-expanded-details');
                    const expandIcon = btn.querySelector('.expand-icon');
                    
                    if (details) {
                        const isHidden = details.classList.contains('hidden');
                        if (isHidden) {
                            details.classList.remove('hidden');
                            btn.classList.add('bg-secondary-fixed/10');
                            if (expandIcon) expandIcon.textContent = 'expand_less';
                        } else {
                            details.classList.add('hidden');
                            btn.classList.remove('bg-secondary-fixed/10');
                            if (expandIcon) expandIcon.textContent = 'expand_more';
                        }
                    }
                }
            });

            // Wire up category chips
            let activeCat = 'all';
            document.addEventListener('click', (e) => {
                const chip = e.target.closest('.first-aid-cat-chip');
                if (chip) {
                    document.querySelectorAll('.first-aid-cat-chip').forEach(c => {
                        c.classList.remove('bg-secondary-fixed', 'text-on-secondary-fixed');
                        c.classList.add('glass-panel', 'text-on-surface');
                    });
                    chip.classList.remove('glass-panel', 'text-on-surface');
                    chip.classList.add('bg-secondary-fixed', 'text-on-secondary-fixed');
                    activeCat = chip.getAttribute('data-category');
                    const searchInput = document.getElementById('first-aid-search-input');
                    renderFirstAid(activeCat, searchInput ? searchInput.value : '');
                }
            });

            // Wire up search input
            const searchInput = document.getElementById('first-aid-search-input');
            if (searchInput) {
                searchInput.addEventListener('input', () => {
                    renderFirstAid(activeCat, searchInput.value);
                });
            }

            renderFirstAid('all', '');
        }
    }


    // ==========================================
    // 10.7. PAGE INTERACTIONS: GOVT SCHEMES
    // ==========================================
    if (pageName.includes('govt-schemes')) {
        const schContainer = document.getElementById('schemes-grid-container');
        if (schContainer) {
            // Expanded list of 30 Indian Healthcare schemes
            const schemesList = [
                {
                    key: 'pmjay', icon: 'local_hospital',
                    tagEn: 'Insurance', tagHi: 'स्वास्थ्य बीमा',
                    nameEn: 'Ayushman Bharat (PM-JAY)', nameHi: 'आयुष्मान भारत (PM-JAY)',
                    overviewEn: 'Provides free health cover of up to ₹5 Lakh per family per year for secondary and tertiary care hospitalization.',
                    overviewHi: 'माध्यमिक और तृतीयक देखभाल अस्पताल में भर्ती के लिए प्रति वर्ष प्रति परिवार ₹5 लाख तक का मुफ्त स्वास्थ्य बीमा प्रदान करता है।',
                    eligibilityEn: 'Low-income families listed in SECC 2011 database, rural workers.',
                    eligibilityHi: 'SECC 2011 डेटाबेस में सूचीबद्ध कम आय वाले परिवार, ग्रामीण और असंगठित श्रमिक।',
                    benefitsEn: 'Cashless treatment of up to ₹5,00,000 per family per year at all empanelled hospitals.',
                    benefitsHi: 'सभी सूचीबद्ध निजी और सरकारी अस्पतालों में प्रति परिवार प्रति वर्ष ₹5,00,000 तक का कैशलेस इलाज।',
                    docsEn: 'Aadhaar Card, Ration Card, Active Mobile Number.',
                    docsHi: 'आधार कार्ड, राशन कार्ड, चालू मोबाइल नंबर।',
                    processEn: 'Check eligibility on the official portal, visit nearest PM-JAY kiosk or empanelled hospital with Aadhaar to generate Ayushman Card.',
                    processHi: 'आधिकारिक पोर्टल पर पात्रता जांचें, आयुष्मान कार्ड बनवाने के लिए आधार कार्ड के साथ नजदीकी पीएम-जय कियोस्क या सूचीबद्ध अस्पताल पर जाएं।',
                    portal: 'https://pmjay.gov.in',
                    faqsEn: [
                        { q: 'Is there a limit on family size?', a: 'No, there is no limit on family size or age of members.' },
                        { q: 'Can I use this card in private hospitals?', a: 'Yes, at any empanelled private or government hospital nationwide.' }
                    ],
                    faqsHi: [
                        { q: 'क्या परिवार के आकार की कोई सीमा है?', a: 'नहीं, परिवार के आकार या सदस्यों की उम्र पर कोई सीमा नहीं है।' },
                        { q: 'क्या मैं इसे निजी अस्पतालों में उपयोग कर सकता हूँ?', a: 'हाँ, देश भर के किसी भी सूचीबद्ध निजी या सरकारी अस्पताल में।' }
                    ],
                    keywords: ['pmjay', 'ayushman', '5 lakh', 'free treatment', 'cashless', 'बीमा', 'इलाज'],
                    age: ['0-18', '19-45', '46-60', '60+'], gender: ['all', 'male', 'female'], income: ['below-1l', '1l-5l']
                },
                {
                    key: 'abha', icon: 'badge',
                    tagEn: 'Digital Health', tagHi: 'डिजिटल स्वास्थ्य',
                    nameEn: 'ABHA Health Account', nameHi: 'आभा स्वास्थ्य खाता',
                    overviewEn: 'A unique 14-digit digital ID to securely store, share, and manage health records digitally across verified healthcare providers.',
                    overviewHi: 'सत्यापित स्वास्थ्य सेवा प्रदाताओं के बीच डिजिटल रूप से स्वास्थ्य रिकॉर्ड को सुरक्षित रूप से संग्रहीत, साझा और प्रबंधित करने के लिए एक अद्वितीय 14-अंकीय डिजिटल आईडी।',
                    eligibilityEn: 'All Indian citizens of any age group.',
                    eligibilityHi: 'किसी भी उम्र के सभी भारतीय नागरिक।',
                    benefitsEn: 'Digitizes medical records, laboratory reports, prescriptions, and ensures seamless sharing with doctors.',
                    benefitsHi: 'चिकित्सीय रिकॉर्ड, प्रयोगशाला रिपोर्ट, नुस्खे को डिजिटल बनाता है और डॉक्टरों के साथ निर्बाध साझाकरण सुनिश्चित करता है।',
                    docsEn: 'Aadhaar Card or Mobile Number.',
                    docsHi: 'आधार कार्ड या मोबाइल नंबर।',
                    processEn: 'Generate instantly online on the ABHA portal or ABHA app using Aadhaar OTP verification.',
                    processHi: 'आधार ओटीपी सत्यापन का उपयोग करके आभा पोर्टल या आभा ऐप पर तुरंत ऑनलाइन जनरेट करें।',
                    portal: 'https://abdm.gov.in',
                    faqsEn: [
                        { q: 'Is ABHA card mandatory?', a: 'No, creating an ABHA ID is completely voluntary.' },
                        { q: 'Is my health data secure?', a: 'Yes, data is encrypted and records are only shared with your explicit consent.' }
                    ],
                    faqsHi: [
                        { q: 'क्या आभा कार्ड अनिवार्य है?', a: 'नहीं, आभा आईडी बनाना पूरी तरह से स्वैच्छिक है।' },
                        { q: 'क्या मेरा स्वास्थ्य डेटा सुरक्षित है?', a: 'हाँ, डेटा एन्क्रिप्टेड है और रिकॉर्ड केवल आपकी स्पष्ट सहमति से ही साझा किए जाते हैं।' }
                    ],
                    keywords: ['abha', 'health id', 'digital health', 'medical records', 'abdm', 'डिजिटल कार्ड', 'रिकॉर्ड'],
                    age: ['0-18', '19-45', '46-60', '60+'], gender: ['all', 'male', 'female'], income: ['below-1l', '1l-5l', 'above-5l']
                },
                {
                    key: 'jan_aushadhi', icon: 'medication',
                    tagEn: 'Medicines', tagHi: 'दवाइयाँ',
                    nameEn: 'Pradhan Mantri Janaushadhi', nameHi: 'जन औषधि परियोजना',
                    overviewEn: 'Provides high-quality generic medicines to all at 50% to 90% lower prices than branded medicines.',
                    overviewHi: 'ब्रांडेड दवाओं की तुलना में 50% से 90% कम कीमत पर सभी को उच्च गुणवत्ता वाली जेनेरिक दवाएं प्रदान करता है।',
                    eligibilityEn: 'Open to all citizens seeking affordable high-quality generic medications.',
                    eligibilityHi: 'सस्ती उच्च गुणवत्ता वाली जेनेरिक दवाएं चाहने वाले सभी नागरिकों के लिए खुला है।',
                    benefitsEn: 'Access to generic drugs, surgical items at extremely subsidized prices.',
                    benefitsHi: 'अत्यंत रियायती दरों पर जेनेरिक दवाओं, सर्जिकल सामानों तक पहुंच।',
                    docsEn: 'Valid doctor prescription.',
                    docsHi: 'डॉक्टर का वैध पर्चा (प्रिस्क्रिप्शन)।',
                    processEn: 'Visit any PM Janaushadhi Kendra with a doctor\'s prescription to buy medicines directly.',
                    processHi: 'सीधे दवाएं खरीदने के लिए डॉक्टर के पर्चे के साथ किसी भी पीएम जन औषधि केंद्र पर जाएं।',
                    portal: 'http://janaushadhi.gov.in',
                    faqsEn: [
                        { q: 'Are generic medicines safe?', a: 'Yes, they are therapeutically equivalent and quality-tested.' }
                    ],
                    faqsHi: [
                        { q: 'क्या जेनेरिक दवाएं सुरक्षित हैं?', a: 'हाँ, वे चिकित्सीय रूप से समान और गुणवत्ता-परीक्षित हैं।' }
                    ],
                    keywords: ['jan aushadhi', 'generic medicine', 'cheap medicines', 'subsidized', 'जेनेरिक', 'दवा'],
                    age: ['0-18', '19-45', '46-60', '60+'], gender: ['all', 'male', 'female'], income: ['below-1l', '1l-5l', 'above-5l']
                },
                {
                    key: 'jsy', icon: 'pregnant_woman',
                    tagEn: 'Maternal', tagHi: 'मातृ स्वास्थ्य',
                    nameEn: 'Janani Suraksha Yojana (JSY)', nameHi: 'जननी सुरक्षा योजना (JSY)',
                    overviewEn: 'A safe motherhood intervention promoting institutional delivery among poor pregnant women with cash assistance.',
                    overviewHi: 'नकद सहायता प्रदान करके गरीब गर्भवती महिलाओं के बीच संस्थागत प्रसव को बढ़ावा देने वाली एक सुरक्षित मातृत्व पहल।',
                    eligibilityEn: 'Pregnant women from BPL/SC/ST households delivering in government health facilities.',
                    eligibilityHi: 'BPL/SC/ST परिवारों की गर्भवती महिलाएं जो सरकारी स्वास्थ्य केंद्रों में प्रसव कराती हैं।',
                    benefitsEn: 'Direct cash benefit of ₹1,400 (rural) or ₹1,000 (urban) to the mother post-delivery.',
                    benefitsHi: 'प्रसव के बाद मां को ₹1,400 (ग्रामीण) या ₹1,000 (शहरी) का सीधा नकद हस्तांतरण।',
                    docsEn: 'BPL Card, Aadhaar Card, MCP Card (Mamta Card), Bank Account Details.',
                    docsHi: 'बीपीएल कार्ड, आधार कार्ड, एमसीपी कार्ड (ममता कार्ड), बैंक खाता विवरण।',
                    processEn: 'Register with local ASHA worker during early pregnancy; cash incentive is credited post-delivery.',
                    processHi: 'गर्भावस्था के शुरुआती दिनों में स्थानीय आशा (ASHA) कार्यकर्ता के पास पंजीकरण करें; प्रसव के बाद नकद प्रोत्साहन राशि जमा की जाती है।',
                    portal: 'https://nhm.gov.in',
                    faqsEn: [
                        { q: 'Is it applicable for private hospital deliveries?', a: 'Only at government-accredited empanelled private clinics.' }
                    ],
                    faqsHi: [
                        { q: 'क्या यह निजी अस्पताल में प्रसव के लिए लागू है?', a: 'केवल सरकार द्वारा मान्यता प्राप्त निजी क्लीनिकों में ही लागू है।' }
                    ],
                    keywords: ['jsy', 'janani', 'pregnancy cash', 'maternal delivery', 'asha', 'गर्भवती', 'प्रसव'],
                    age: ['19-45'], gender: ['female'], income: ['below-1l']
                },
                {
                    key: 'poshan_abhiyaan', icon: 'nutrition',
                    tagEn: 'Nutrition', tagHi: 'पोषण',
                    nameEn: 'POSHAN Abhiyaan', nameHi: 'पोषण अभियान',
                    overviewEn: 'Multi-ministerial convergence mission to improve nutritional outcomes for children, pregnant women, and lactating mothers.',
                    overviewHi: 'बच्चों, गर्भवती महिलाओं और स्तनपान कराने वाली माताओं के लिए पोषण परिणामों में सुधार करने के लिए बहु-मंत्रालयी मिशन।',
                    eligibilityEn: 'Children under 6 years, pregnant women, and lactating mothers.',
                    eligibilityHi: '6 वर्ष से कम उम्र के बच्चे, गर्भवती महिलाएं और स्तनपान कराने वाली माताएं।',
                    benefitsEn: 'Provides supplementary nutrition, tracks growth, and addresses stunting and anemia.',
                    benefitsHi: 'पूरक पोषण प्रदान करता है, विकास पर नजर रखता है, और बौनापन व एनीमिया का इलाज करता है।',
                    docsEn: 'Aadhaar Card, Anganwadi Registration.',
                    docsHi: 'आधार कार्ड, आंगनवाड़ी पंजीकरण।',
                    processEn: 'Register at the nearest Anganwadi center to receive nutrition rations and counseling.',
                    processHi: 'पोषण राशन और परामर्श प्राप्त करने के लिए निकटतम आंगनवाड़ी केंद्र पर पंजीकरण करें।',
                    portal: 'https://poshanabhiyaan.gov.in',
                    faqsEn: [
                        { q: 'What is the frequency of rations?', a: 'Distributed monthly at local Anganwadi centers.' }
                    ],
                    faqsHi: [
                        { q: 'राशन मिलने की आवृत्ति क्या है?', a: 'स्थानीय आंगनवाड़ी केंद्रों पर मासिक रूप से वितरित किया जाता है।' }
                    ],
                    keywords: ['poshan', 'nutrition ration', 'anganwadi', 'anemia', 'stunting', 'बच्चे', 'पोषण'],
                    age: ['0-18', '19-45'], gender: ['all', 'female'], income: ['below-1l', '1l-5l']
                },
                {
                    key: 'mission_indradhanush', icon: 'vaccines',
                    tagEn: 'Immunization', tagHi: 'टीकाकरण',
                    nameEn: 'Mission Indradhanush', nameHi: 'मिशन इंद्रधनुष',
                    overviewEn: 'A health mission aimed at immunizing all children under 2 years of age and pregnant women against 12 vaccine-preventable diseases.',
                    overviewHi: '12 वैक्सीन-रोकथाम योग्य बीमारियों के खिलाफ 2 वर्ष से कम उम्र के बच्चों और गर्भवती महिलाओं का पूर्ण टीकाकरण करने के उद्देश्य से एक स्वास्थ्य मिशन।',
                    eligibilityEn: 'Children below 2 years and pregnant women lacking immunization.',
                    eligibilityHi: 'टीकाकरण से छूटे हुए 2 वर्ष से कम उम्र के बच्चे और गर्भवती महिलाएं।',
                    benefitsEn: 'Free vaccination against diphtheria, pertussis, tetanus, polio, measles, rubella, and TB.',
                    benefitsHi: 'डिप्थीरिया, काली खांसी, टेटनस, पोलियो, खसरा, रूबेला और टीबी के खिलाफ मुफ्त टीकाकरण।',
                    docsEn: 'Child Immunization Card, Aadhaar Card.',
                    docsHi: 'बच्चे का टीकाकरण कार्ड, आधार कार्ड।',
                    processEn: 'Attend immunization camps organized at local government clinics and Anganwadi centers.',
                    processHi: 'स्थानीय सरकारी क्लीनिकों और आंगनवाड़ी केंद्रों में आयोजित टीकाकरण शिविरों में भाग लें।',
                    portal: 'https://www.nhp.gov.in/mission-indradhanush',
                    faqsEn: [
                        { q: 'Are these vaccines free?', a: 'Yes, all scheduled vaccines under this mission are entirely free.' }
                    ],
                    faqsHi: [
                        { q: 'क्या ये टीके मुफ्त हैं?', a: 'हाँ, इस मिशन के तहत सभी निर्धारित टीके पूरी तरह से मुफ्त हैं।' }
                    ],
                    keywords: ['indradhanush', 'vaccination', 'child polio', 'measles shot', 'टीकाकरण', 'पोलियो'],
                    age: ['0-18', '19-45'], gender: ['all', 'female'], income: ['below-1l', '1l-5l', 'above-5l']
                },
                {
                    key: 'jssk', icon: 'child_care',
                    tagEn: 'Maternal', tagHi: 'मातृ स्वास्थ्य',
                    nameEn: 'Janani Shishu Suraksha (JSSK)', nameHi: 'जननी शिशु सुरक्षा (JSSK)',
                    overviewEn: 'Entitles all pregnant women delivering in public health institutions to absolutely free and no-expense deliveries.',
                    overviewHi: 'सार्वजनिक स्वास्थ्य संस्थानों में प्रसव कराने वाली सभी गर्भवती महिलाओं को बिल्कुल मुफ्त और बिना किसी खर्च के प्रसव का हकदार बनाता है।',
                    eligibilityEn: 'All pregnant women and sick infants up to 1 year using public facilities.',
                    eligibilityHi: 'सभी गर्भवती महिलाएं और सरकारी अस्पतालों का उपयोग करने वाले 1 वर्ष तक के बीमार शिशु।',
                    benefitsEn: 'Free drugs, diagnostics, diet during stay, blood transfusion, and free transport from/to home.',
                    benefitsHi: 'अस्पताल में रहने के दौरान मुफ्त दवाएं, जांच, भोजन, रक्त और घर से अस्पताल तक मुफ्त परिवहन।',
                    docsEn: 'MCP Card, Government Referral Form.',
                    docsHi: 'एमसीपी कार्ड, सरकारी रेफरल फॉर्म।',
                    processEn: 'Avail benefits automatically at any government district hospital or community health center upon admission.',
                    processHi: 'भर्ती होने पर किसी भी सरकारी जिला अस्पताल या सामुदायिक स्वास्थ्य केंद्र में स्वतः लाभ उठाएं।',
                    portal: 'https://nhm.gov.in',
                    faqsEn: [
                        { q: 'Is C-section covered?', a: 'Yes, both normal deliveries and Caesarean sections are fully covered.' }
                    ],
                    faqsHi: [
                        { q: 'क्या सिजेरियन प्रसव शामिल है?', a: 'हाँ, सामान्य प्रसव और सिजेरियन ऑपरेशन दोनों पूरी तरह से कवर हैं।' }
                    ],
                    keywords: ['jssk', 'free delivery', 'pregnancy medicines', 'ambulance', 'शिशु', 'प्रसव'],
                    age: ['0-18', '19-45'], gender: ['female'], income: ['below-1l', '1l-5l', 'above-5l']
                },
                {
                    key: 'rbsk', icon: 'accessibility',
                    tagEn: 'Child Care', tagHi: 'बाल स्वास्थ्य',
                    nameEn: 'Rashtriya Bal Swasthya (RBSK)', nameHi: 'राष्ट्रीय बाल स्वास्थ्य (RBSK)',
                    overviewEn: 'A child health screening program identifying 4 Ds: Defects at birth, Diseases, Deficiencies, and Developmental delays.',
                    overviewHi: 'एक बाल स्वास्थ्य जांच कार्यक्रम जो 4 श्रेणियों की पहचान करता है: जन्म के समय दोष, बीमारियाँ, कमियाँ और विकास में देरी।',
                    eligibilityEn: 'Children from birth to 18 years enrolled in government schools and Anganwadis.',
                    eligibilityHi: 'सरकारी स्कूलों और आंगनवाड़ियों में नामांकित जन्म से 18 वर्ष तक के बच्चे।',
                    benefitsEn: 'Early identification and free tertiary surgical management for congenital diseases.',
                    benefitsHi: 'जन्मजात बीमारियों के लिए शीघ्र पहचान और मुफ्त तृतीयक सर्जिकल उपचार।',
                    docsEn: 'School ID Card, Anganwadi Registration card, Aadhaar.',
                    docsHi: 'स्कूल आईडी कार्ड, आंगनवाड़ी पंजीकरण कार्ड, आधार।',
                    processEn: 'Screened by mobile health teams visiting Anganwadis and schools; children requiring surgery are referred to tertiary hospitals.',
                    processHi: 'आंगनवाड़ियों और स्कूलों का दौरा करने वाली मोबाइल स्वास्थ्य टीमों द्वारा जांच; सर्जरी की आवश्यकता वाले बच्चों को बड़े अस्पतालों में रेफर किया जाता है।',
                    portal: 'https://nhm.gov.in/index1.php?lang=1&level=3&sublinkid=1137&lid=425',
                    faqsEn: [
                        { q: 'Is cardiac surgery covered?', a: 'Yes, congenital heart defects are screened and operated for free.' }
                    ],
                    faqsHi: [
                        { q: 'क्या हृदय की सर्जरी कवर है?', a: 'हाँ, जन्मजात हृदय दोषों की मुफ्त जांच और ऑपरेशन किया जाता है।' }
                    ],
                    keywords: ['rbsk', 'child screening', 'birth defects', 'development delay', 'हृदय रोग', 'बच्चे'],
                    age: ['0-18'], gender: ['all', 'male', 'female'], income: ['below-1l', '1l-5l']
                },
                {
                    key: 'npcdcs', icon: 'heart_broken',
                    tagEn: 'Chronic Care', tagHi: 'गंभीर रोग',
                    nameEn: 'NPCDCS Program', nameHi: 'एनपीसीडीसीएस कार्यक्रम',
                    overviewEn: 'National Program focusing on prevention and control of Cancer, Diabetes, Cardiovascular Diseases, and Stroke.',
                    overviewHi: 'कैंसर, मधुमेह, हृदय रोग और स्ट्रोक की रोकथाम और नियंत्रण पर ध्यान केंद्रित करने वाला राष्ट्रीय कार्यक्रम।',
                    eligibilityEn: 'All adult citizens, especially those above 30 years requiring chronic disease screening.',
                    eligibilityHi: 'सभी वयस्क नागरिक, विशेष रूप से 30 वर्ष से अधिक उम्र के लोग जिन्हें पुरानी बीमारियों की जांच की आवश्यकता है।',
                    benefitsEn: 'Free screening, diagnosis, life-saving medicines, and palliative cancer care at district NCD clinics.',
                    benefitsHi: 'जिला एनसीडी क्लीनिकों में मुफ्त जांच, निदान, जीवन रक्षक दवाएं और कैंसर देखभाल।',
                    docsEn: 'Aadhaar Card, Hospital Registration Card.',
                    docsHi: 'आधार कार्ड, अस्पताल पंजीकरण कार्ड।',
                    processEn: 'Visit the NCD (Non-Communicable Diseases) cell at any government district hospital for diagnostic screening.',
                    processHi: 'जांच के लिए किसी भी सरकारी जिला अस्पताल में एनसीडी (गैर-संचारी रोग) सेल पर जाएं।',
                    portal: 'https://main.mohfw.gov.in',
                    faqsEn: [
                        { q: 'Are chemotherapy medicines free?', a: 'Empanelled districts provide selected oncology chemotherapy drugs at no cost.' }
                    ],
                    faqsHi: [
                        { q: 'क्या कीमोथेरेपी दवाएं मुफ्त हैं?', a: 'चिह्नित जिलों में चुनिंदा ऑन्कोलॉजी कीमोथेरेपी दवाएं बिना किसी शुल्क के प्रदान की जाती हैं।' }
                    ],
                    keywords: ['npcdcs', 'cancer screening', 'diabetes insulin', 'cardio stroke', 'कैंसर', 'शुगर'],
                    age: ['19-45', '46-60', '60+'], gender: ['all', 'male', 'female'], income: ['below-1l', '1l-5l', 'above-5l']
                },
                {
                    key: 'ntep', icon: 'healing',
                    tagEn: 'Tuberculosis', tagHi: 'टीबी कार्यक्रम',
                    nameEn: 'National TB Elimination (NTEP)', nameHi: 'राष्ट्रीय टीबी उन्मूलन (NTEP)',
                    overviewEn: 'Provides free diagnostic facilities, drug regimens, and financial support for Tuberculosis patients across India.',
                    overviewHi: 'पूरे भारत में टीबी के मरीजों के लिए मुफ्त नैदानिक सुविधाएं, दवाएं और वित्तीय सहायता प्रदान करता है।',
                    eligibilityEn: 'Any individual suspected of or diagnosed with Tuberculosis.',
                    eligibilityHi: 'तपेदिक (टीबी) से पीड़ित या संदिग्ध कोई भी व्यक्ति।',
                    benefitsEn: 'Free sputum test, CBNAAT diagnostic, entire course of DOTS anti-TB therapy, and ₹500/month nutritional cash support.',
                    benefitsHi: 'मुफ्त बलगम परीक्षण, सीबीनाट जांच, डॉट्स (DOTS) टीबी-रोधी उपचार और ₹500/माह पोषण नकद सहायता।',
                    docsEn: 'Aadhaar Card, Bank Account Details (for Ni-kshay Poshan Yojana).',
                    docsHi: 'आधार कार्ड, बैंक खाता विवरण (निक्षय पोषण योजना के लिए)।',
                    processEn: 'Visit local government Primary Health Center (PHC) for diagnostic testing and therapy enrollment.',
                    processHi: 'निदान परीक्षण और उपचार पंजीकरण के लिए स्थानीय सरकारी प्राथमिक स्वास्थ्य केंद्र (PHC) पर जाएं।',
                    portal: 'https://tbcindia.gov.in',
                    faqsEn: [
                        { q: 'What is Ni-kshay Poshan Yojana?', a: 'It provides ₹500/month cash to every TB patient during their active treatment.' }
                    ],
                    faqsHi: [
                        { q: 'निक्षय पोषण योजना क्या है?', a: 'यह सक्रिय उपचार के दौरान प्रत्येक टीबी रोगी को ₹500/माह की नकद सहायता प्रदान करती है।' }
                    ],
                    keywords: ['ntep', 'tb dots', 'tuberculosis cough', 'nikshay poshan', 'टीबी', 'बलगम जांच'],
                    age: ['0-18', '19-45', '46-60', '60+'], gender: ['all', 'male', 'female'], income: ['below-1l', '1l-5l', 'above-5l']
                },
                {
                    key: 'esanjeevani', icon: 'videocam',
                    tagEn: 'Telehealth', tagHi: 'टेलीमेडिसिन',
                    nameEn: 'eSanjeevani Teleconsultation', nameHi: 'ई-संजीवनी टेलीमेडिसिन',
                    overviewEn: 'National doctor-to-doctor and patient-to-doctor teleconsultation system offering free consultation with medical specialists.',
                    overviewHi: 'राष्ट्रीय डॉक्टर-टू-डॉक्टर और रोगी-टू-डॉक्टर टेलीकंसल्टेशन प्रणाली जो चिकित्सा विशेषज्ञों के साथ मुफ्त परामर्श प्रदान करती है।',
                    eligibilityEn: 'All Indian citizens needing remote medical advice and prescriptions.',
                    eligibilityHi: 'दूरस्थ चिकित्सा सलाह और पर्चे की आवश्यकता वाले सभी भारतीय नागरिक।',
                    benefitsEn: 'Free remote consultations with government doctors, instant digital prescription generation.',
                    benefitsHi: 'सरकारी डॉक्टरों के साथ मुफ्त वीडियो परामर्श, तुरंत डिजिटल पर्चा प्राप्त करना।',
                    docsEn: 'Aadhaar Card (optional), past medical history documents.',
                    docsHi: 'आधार कार्ड (वैकल्पिक), पुराना चिकित्सा इतिहास।',
                    processEn: 'Log in to the eSanjeevaniOPD portal or app, register, verify mobile, generate token, and wait for video queue.',
                    processHi: 'ई-संजीवनी ओपीडी पोर्टल या ऐप पर लॉग इन करें, पंजीकरण करें, टोकन प्राप्त करें और डॉक्टर से वीडियो कॉल पर बात करें।',
                    portal: 'https://esanjeevaniopd.in',
                    faqsEn: [
                        { q: 'Are consultation charges applicable?', a: 'No, this service is completely free of cost.' }
                    ],
                    faqsHi: [
                        { q: 'क्या परामर्श शुल्क लागू है?', a: 'नहीं, यह सेवा पूरी तरह से निःशुल्क है।' }
                    ],
                    keywords: ['esanjeevani', 'teleconsultation', 'online doctor', 'video call health', 'ऑनलाइन डॉक्टर', 'परामर्श'],
                    age: ['0-18', '19-45', '46-60', '60+'], gender: ['all', 'male', 'female'], income: ['below-1l', '1l-5l', 'above-5l']
                },
                {
                    key: 'ayush_programs', icon: 'spa',
                    tagEn: 'Ayurveda', tagHi: 'आयुष कार्यक्रम',
                    nameEn: 'National AYUSH Mission', nameHi: 'राष्ट्रीय आयुष मिशन',
                    overviewEn: 'Promotes holistic healthcare through traditional systems: Ayurveda, Yoga, Unani, Siddha, and Homeopathy.',
                    overviewHi: 'पारंपरिक चिकित्सा पद्धतियों: आयुर्वेद, योग, यूनानी, सिद्ध और होम्योपैथी के माध्यम से समग्र स्वास्थ्य सेवा को बढ़ावा देता है।',
                    eligibilityEn: 'All individuals seeking alternative or holistic medical therapy.',
                    eligibilityHi: 'वैकल्पिक या समग्र चिकित्सा उपचार चाहने वाले सभी नागरिक।',
                    benefitsEn: 'Access to natural drug formulations, wellness centers, and specialized AYUSH doctors.',
                    benefitsHi: 'प्राकृतिक दवाओं, आयुष कल्याण केंद्रों और विशेष आयुष डॉक्टरों तक पहुंच।',
                    docsEn: 'Not required (open registration at clinic).',
                    docsHi: 'आवश्यक नहीं (क्लीनिक पर खुला पंजीकरण)।',
                    processEn: 'Visit nearest AYUSH wellness dispensary or wing at district hospital for free consultation and medicines.',
                    processHi: 'मुफ्त परामर्श और प्राकृतिक दवाओं के लिए जिला अस्पताल में निकटतम आयुष डिस्पेंसरी या विंग पर जाएं।',
                    portal: 'https://ayush.gov.in',
                    faqsEn: [
                        { q: 'Are AYUSH medicines provided free?', a: 'Yes, basic formulations are distributed free of cost at government AYUSH centers.' }
                    ],
                    faqsHi: [
                        { q: 'क्या आयुष दवाएं मुफ्त दी जाती हैं?', a: 'हाँ, सरकारी आयुष केंद्रों पर बुनियादी दवाएं मुफ्त वितरित की जाती हैं।' }
                    ],
                    keywords: ['ayush', 'ayurveda', 'homeopathy', 'yoga center', 'natural treatment', 'आयुर्वेद', 'जड़ी बूटी'],
                    age: ['0-18', '19-45', '46-60', '60+'], gender: ['all', 'male', 'female'], income: ['below-1l', '1l-5l', 'above-5l']
                },
                {
                    key: 'pmsma', icon: 'pregnant_woman',
                    tagEn: 'Maternal', tagHi: 'मातृ स्वास्थ्य',
                    nameEn: 'PM Surakshit Matritva (PMSMA)', nameHi: 'पीएम सुरक्षित मातृत्व अभियान (PMSMA)',
                    overviewEn: 'Guarantees free, comprehensive, and quality antenatal care (ANC) services to all pregnant women on the 9th of every month.',
                    overviewHi: 'हर महीने की 9 तारीख को सभी गर्भवती महिलाओं को मुफ्त, व्यापक और गुणवत्तापूर्ण प्रसव पूर्व देखभाल (ANC) सेवाओं की गारंटी देता है।',
                    eligibilityEn: 'All pregnant women in their 2nd or 3rd trimesters.',
                    eligibilityHi: 'गर्भावस्था की दूसरी या तीसरी तिमाही की सभी गर्भवती महिलाएं।',
                    benefitsEn: 'Free diagnostic tests, obstetricians checkup, health counseling on nutrition and institutional delivery.',
                    benefitsHi: 'मुफ्त नैदानिक परीक्षण, स्त्री रोग विशेषज्ञ जांच, पोषण व सुरक्षित प्रसव पर परामर्श।',
                    docsEn: 'Aadhaar Card, MCP Card.',
                    docsHi: 'आधार कार्ड, एमसीपी (Mamta) कार्ड।',
                    processEn: 'Visit any government health facility or district hospital on the 9th of any month to receive free specialist services.',
                    processHi: 'विशेषज्ञ सेवाओं को प्राप्त करने के लिए किसी भी महीने की 9 तारीख को किसी भी सरकारी अस्पताल में जाएं।',
                    portal: 'https://pmsma.mohfw.gov.in',
                    faqsEn: [
                        { q: 'Who provides the checkups?', a: 'Specialist gynecologists and government doctors conduct these screenings.' }
                    ],
                    faqsHi: [
                        { q: 'जांच कौन करता है?', a: 'विशेषज्ञ स्त्री रोग विशेषज्ञ और सरकारी डॉक्टर इन जांचों को आयोजित करते हैं।' }
                    ],
                    keywords: ['pmsma', 'anc checkup', 'pregnancy month 9', 'maternal screening', 'गर्भवती', '९ तारीख'],
                    age: ['19-45'], gender: ['female'], income: ['below-1l', '1l-5l', 'above-5l']
                },
                {
                    key: 'nvbdcp', icon: 'bug_report',
                    tagEn: 'Infections', tagHi: 'संक्रमण नियंत्रण',
                    nameEn: 'Vector Borne Diseases Program', nameHi: 'राष्ट्रीय कीट जनित रोग कार्यक्रम',
                    overviewEn: 'National program for prevention and control of vector-borne diseases like Malaria, Dengue, Chikungunya, and Kala-azar.',
                    overviewHi: 'मलेरिया, डेंगू, चिकनगुनिया और कालाजार जैसी कीट-जनित बीमारियों की रोकथाम और नियंत्रण के लिए राष्ट्रीय कार्यक्रम।',
                    eligibilityEn: 'Any citizen suffering from mosquito-borne or parasitic tropical diseases.',
                    eligibilityHi: 'मच्छर जनित या परजीवी उष्णकटिबंधीय बीमारियों से पीड़ित कोई भी नागरिक।',
                    benefitsEn: 'Free blood smear testing, diagnostic antigen cards, mosquito net distribution, and complete drug course.',
                    benefitsHi: 'मुफ्त रक्त बलगम/स्मीयर जांच, रैपिड एंटीजन कार्ड, मच्छरदानी वितरण और पूर्ण उपचार।',
                    docsEn: 'Not required.',
                    docsHi: 'आवश्यक नहीं।',
                    processEn: 'Visit nearest government clinic or sub-center for instant blood test and malaria/dengue treatment.',
                    processHi: 'त्वरित रक्त परीक्षण और मलेरिया/डेंगू के उपचार के लिए निकटतम सरकारी क्लिनिक या उप-केंद्र पर जाएं।',
                    portal: 'https://nvbdcp.gov.in',
                    faqsEn: [
                        { q: 'Are mosquito nets free?', a: 'Long-lasting insecticidal nets are distributed free in endemic high-risk rural areas.' }
                    ],
                    faqsHi: [
                        { q: 'क्या मच्छरदानी मुफ्त है?', a: 'अत्यधिक मलेरिया-प्रवण ग्रामीण क्षेत्रों में कीटनाशक युक्त मच्छरदानियां मुफ्त बांटी जाती हैं।' }
                    ],
                    keywords: ['nvbdcp', 'malaria cure', 'dengue test', 'mosquito spray', 'nets', 'मलेरिया', 'मच्छर'],
                    age: ['0-18', '19-45', '46-60', '60+'], gender: ['all', 'male', 'female'], income: ['below-1l', '1l-5l']
                },
                {
                    key: 'nphce', icon: 'elderly',
                    tagEn: 'Geriatric', tagHi: 'बुजुर्ग देखभाल',
                    nameEn: 'Geriatric Healthcare (NPHCE)', nameHi: 'राष्ट्रीय बुजुर्ग स्वास्थ्य (NPHCE)',
                    overviewEn: 'Provides dedicated health services for the elderly (above 60 years) at primary, secondary, and tertiary levels.',
                    overviewHi: 'प्राथमिक, माध्यमिक और तृतीयक स्तर पर बुजुर्गों (60 वर्ष से अधिक) के लिए समर्पित स्वास्थ्य सेवाएं प्रदान करता है।',
                    eligibilityEn: 'Senior citizens aged 60 years and above.',
                    eligibilityHi: '60 वर्ष और उससे अधिक आयु के वरिष्ठ नागरिक।',
                    benefitsEn: 'Dedicated geriatric OPDs, free provision of assistive devices (walking sticks, glasses), physiotherapy.',
                    benefitsHi: 'बुजुर्गों के लिए विशेष ओपीडी, सहायक उपकरण (छड़ी, चश्मा) का मुफ्त वितरण, और फिजियोथेरेपी।',
                    docsEn: 'Aadhaar Card, Senior Citizen ID card.',
                    docsHi: 'आधार कार्ड, वरिष्ठ नागरिक पहचान पत्र।',
                    processEn: 'Register at the dedicated Geriatric OPD counter at any government district hospital.',
                    processHi: 'किसी भी सरकारी जिला अस्पताल में समर्पित बुजुर्ग ओपीडी काउंटर पर पंजीकरण करें।',
                    portal: 'https://main.mohfw.gov.in',
                    faqsEn: [
                        { q: 'Are spectacles provided free?', a: 'Yes, free vision screening and basic spectacles are provided to needy seniors.' }
                    ],
                    faqsHi: [
                        { q: 'क्या चश्मा मुफ्त दिया जाता है?', a: 'हाँ, जरूरतमंद वरिष्ठ नागरिकों को मुफ्त दृष्टि जांच और चश्मा दिया जाता है।' }
                    ],
                    keywords: ['nphce', 'senior citizen', 'spectacles helper', 'wheelchair assistive', 'बुजुर्ग', 'चश्मा'],
                    age: ['60+'], gender: ['all', 'male', 'female'], income: ['below-1l', '1l-5l']
                },
                {
                    key: 'rksk', icon: 'sentiment_satisfied',
                    tagEn: 'Adolescent', tagHi: 'किशोर स्वास्थ्य',
                    nameEn: 'Rashtriya Kishor Swasthya (RKSK)', nameHi: 'राष्ट्रीय किशोर स्वास्थ्य (RKSK)',
                    overviewEn: 'Aims to reach adolescents aged 10-19 years to improve nutrition, reproductive health, and address substance abuse.',
                    overviewHi: '10-19 वर्ष के किशोरों में पोषण, प्रजनन स्वास्थ्य में सुधार लाने और नशामुक्त जीवन को बढ़ावा देने का कार्यक्रम।',
                    eligibilityEn: 'Adolescents in the age group of 10 to 19 years.',
                    eligibilityHi: '10 से 19 वर्ष की आयु वर्ग के किशोर और किशोरियां।',
                    benefitsEn: 'Weekly iron-folic supplements, menstrual hygiene counseling, and youth-friendly health clinics (Saathiya).',
                    benefitsHi: 'साप्ताहिक आयरन-फॉलिक गोलियां, मासिक धर्म स्वच्छता परामर्श, और युवा-अनुकूल क्लीनिक (साथिया)।',
                    docsEn: 'School enrollment proof (optional).',
                    docsHi: 'स्कूल पंजीकरण प्रमाण (वैकल्पिक)।',
                    processEn: 'Visit local Saathiya clinic or contact school health teachers/ASHA workers for guidance and health cards.',
                    processHi: 'स्थानीय साथिया क्लिनिक पर जाएं या स्वास्थ्य परामर्श व आयरन टैबलेट के लिए स्कूल स्वास्थ्य शिक्षक से संपर्क करें।',
                    portal: 'https://nhm.gov.in',
                    faqsEn: [
                        { q: 'What is Saathiya helpline?', a: 'It offers anonymous counseling on adolescent physical and mental health issues.' }
                    ],
                    faqsHi: [
                        { q: 'साथिया हेल्पलाइन क्या है?', a: 'यह किशोरों की शारीरिक और मानसिक स्वास्थ्य समस्याओं पर गुमनाम परामर्श प्रदान करती है।' }
                    ],
                    keywords: ['rksk', 'adolescent iron', 'menstrual pads', 'saathiya youth', 'किशोर', 'साथिया'],
                    age: ['0-18'], gender: ['all', 'male', 'female'], income: ['below-1l', '1l-5l', 'above-5l']
                },
                {
                    key: 'amrit', icon: 'pharmacy',
                    tagEn: 'Medicines', tagHi: 'दवाइयाँ',
                    nameEn: 'AMRIT Pharmacies', nameHi: 'अमृत फार्मेसी योजना',
                    overviewEn: 'Affordable Medicines and Reliable Implants for Treatment (AMRIT) stores offer cancer, cardiovascular drugs at highly discounted rates.',
                    overviewHi: 'कैंसर, हृदय रोग की दवाएं और विश्वसनीय चिकित्सा प्रत्यारोपण अत्यधिक रियायती दरों पर प्रदान करने वाला स्टोर।',
                    eligibilityEn: 'Patients requiring specialized oncology and cardiology medicines and implants.',
                    eligibilityHi: 'विशेष कैंसर और हृदय रोग की दवाओं तथा इम्प्लांट की आवश्यकता वाले मरीज।',
                    benefitsEn: 'Up to 60-90% discount on costly chemotherapy, cardiac stents, and surgical consumables.',
                    benefitsHi: 'महंगे कीमोथेरेपी उपचार, कार्डिएक स्टेंट और सर्जिकल उपभोग्य सामग्रियों पर 60-90% तक की छूट।',
                    docsEn: 'Doctor Prescription, Patient ID proof.',
                    docsHi: 'डॉक्टर का पर्चा, रोगी का पहचान पत्र।',
                    processEn: 'Purchase medicines directly from AMRIT pharmacies located inside major government medical institutes like AIIMS.',
                    processHi: 'एम्स (AIIMS) जैसे बड़े सरकारी मेडिकल संस्थानों के अंदर स्थित अमृत फार्मेसियों से सीधे दवाएं खरीदें।',
                    portal: 'http://www.hlllifecare.com',
                    faqsEn: [
                        { q: 'Can anyone buy from AMRIT?', a: 'Yes, anyone with a valid prescription can purchase from these stores.' }
                    ],
                    faqsHi: [
                        { q: 'क्या कोई भी अमृत से खरीद सकता है?', a: 'हाँ, कोई भी व्यक्ति जिसके पास वैध डॉक्टर का पर्चा है, वह खरीद सकता है।' }
                    ],
                    keywords: ['amrit pharmacy', 'cancer drugs', 'heart stents discount', 'implants', 'दवा छूट', 'कैंसर दवा'],
                    age: ['0-18', '19-45', '46-60', '60+'], gender: ['all', 'male', 'female'], income: ['below-1l', '1l-5l', 'above-5l']
                },
                {
                    key: 'nmhp', icon: 'psychology',
                    tagEn: 'Mental Health', tagHi: 'मानसिक स्वास्थ्य',
                    nameEn: 'National Mental Health (NMHP)', nameHi: 'राष्ट्रीय मानसिक स्वास्थ्य कार्यक्रम',
                    overviewEn: 'Ensures availability of mental health services at primary level, addressing anxiety, depression, and counseling.',
                    overviewHi: 'प्राथमिक स्तर पर मानसिक स्वास्थ्य सेवाओं की उपलब्धता सुनिश्चित करता है, अवसाद, चिंता व अन्य विकारों के लिए परामर्श प्रदान करता है।',
                    eligibilityEn: 'Any citizen suffering from emotional, behavioral, or psychiatric difficulties.',
                    eligibilityHi: 'मानसिक, भावनात्मक या व्यवहार संबंधी समस्याओं से पीड़ित कोई भी नागरिक।',
                    benefitsEn: 'Free psychiatric consultations, clinical counseling, and essential psychiatric medicines at district clinics.',
                    benefitsHi: 'जिला क्लीनिकों में मुफ्त मनोरोग परामर्श, नैदानिक परामर्श और आवश्यक दवाएं।',
                    docsEn: 'Not required.',
                    docsHi: 'आवश्यक नहीं।',
                    processEn: 'Visit the District Mental Health Program (DMHP) cell at the district hospital for counseling or outpatient services.',
                    processHi: 'परामर्श या बाह्य रोगी सेवाओं के लिए जिला अस्पताल में जिला मानसिक स्वास्थ्य कार्यक्रम (DMHP) सेल पर जाएं।',
                    portal: 'https://main.mohfw.gov.in',
                    faqsEn: [
                        { q: 'Is telehealth counseling available?', a: 'Yes, Tele-MANAS toll-free helpline (14416) is available 24/7 for tele-counseling.' }
                    ],
                    faqsHi: [
                        { q: 'क्या टेली-परामर्श उपलब्ध है?', a: 'हाँ, टेली-मानस हेल्पलाइन (14416) 24/7 निःशुल्क परामर्श के लिए उपलब्ध है।' }
                    ],
                    keywords: ['nmhp', 'tele manas helpline', 'depression counselor', 'psychiatrist free', 'चिंता', 'तनाव'],
                    age: ['0-18', '19-45', '46-60', '60+'], gender: ['all', 'male', 'female'], income: ['below-1l', '1l-5l', 'above-5l']
                },
                {
                    key: 'tb_mukt_bharat', icon: 'groups',
                    tagEn: 'Tuberculosis', tagHi: 'टीबी कार्यक्रम',
                    nameEn: 'Pradhan Mantri TB Mukt Bharat', nameHi: 'टीबी मुक्त भारत (Ni-kshay Mitra)',
                    overviewEn: 'A community engagement initiative allowing individuals, NGOs, and corporates (Ni-kshay Mitras) to adopt and support TB patients.',
                    overviewHi: 'एक सामुदायिक जुड़ाव पहल जिसके तहत व्यक्ति, गैर सरकारी संगठन और कॉर्पोरेट (निक्षय मित्र) टीबी रोगियों को अपनाकर उनकी सहायता कर सकते हैं।',
                    eligibilityEn: 'All diagnosed Tuberculosis patients registered on Ni-kshay portal who give consent.',
                    eligibilityHi: 'निक्षय पोर्टल पर पंजीकृत और सहमति देने वाले सभी निदान किए गए टीबी रोगी।',
                    benefitsEn: 'Additional nutritional food baskets, diagnostic support, and vocational training.',
                    benefitsHi: 'अतिरिक्त पोषण आहार बास्केट, नैदानिक सहायता और व्यावसायिक प्रशिक्षण की प्राप्ति।',
                    docsEn: 'TB Treatment Card, Aadhaar Card.',
                    docsHi: 'टीबी उपचार कार्ड, आधार कार्ड।',
                    processEn: 'Linked automatically to a Ni-kshay Mitra sponsor upon diagnosis and consent at the public health center.',
                    processHi: 'सरकारी स्वास्थ्य केंद्र में निदान और सहमति के बाद रोगी को एक निक्षय मित्र प्रायोजक से जोड़ दिया जाता है।',
                    portal: 'https://communitysupport.nikshay.in',
                    faqsEn: [
                        { q: 'What is inside a food basket?', a: 'Includes pulses, cereals, groundnuts, and oil rich in proteins.' }
                    ],
                    faqsHi: [
                        { q: 'आहार टोकरी में क्या होता है?', a: 'इसमें प्रोटीन से भरपूर दालें, अनाज, मूंगफली और खाद्य तेल शामिल हैं।' }
                    ],
                    keywords: ['tb mukt', 'nikshay mitra', 'nutrition basket', 'adopt tb patient', 'निक्षय मित्र', 'आहार'],
                    age: ['0-18', '19-45', '46-60', '60+'], gender: ['all', 'male', 'female'], income: ['below-1l', '1l-5l']
                },
                {
                    key: 'npcb', icon: 'visibility',
                    tagEn: 'Ophthalmic', tagHi: 'नेत्र स्वास्थ्य',
                    nameEn: 'Blindness Control Program (NPCB)', nameHi: 'राष्ट्रीय अंधत्व नियंत्रण (NPCB)',
                    overviewEn: 'Aims to reduce prevalence of blindness through free cataract screening, surgeries, and vision aids.',
                    overviewHi: 'मुफ्त मोतियाबिंद जांच, सर्जरी और नेत्र सहायक सामग्री के माध्यम से अंधेपन की व्यापकता को कम करने का राष्ट्रीय कार्यक्रम।',
                    eligibilityEn: 'Any citizen suffering from refractive errors, cataracts, or visual impairment.',
                    eligibilityHi: 'अपवर्तक त्रुटियों, मोतियाबिंद या दृष्टि हानि से पीड़ित कोई भी नागरिक।',
                    benefitsEn: 'Free cataract surgery (intraocular lens implant), free eyeglasses for school children, corneal transplantation.',
                    benefitsHi: 'मुफ्त मोतियाबिंद सर्जरी (लेंस प्रत्यारोपण), स्कूली बच्चों के लिए मुफ्त चश्मा, कॉर्निया प्रत्यारोपण।',
                    docsEn: 'Aadhaar Card, Hospital Screening slip.',
                    docsHi: 'आधार कार्ड, अस्पताल जांच पर्ची।',
                    processEn: 'Register at district hospital ophthalmic wing or attend local free eye surgical camps.',
                    processHi: 'जिला अस्पताल के नेत्र विभाग में पंजीकरण करें या स्थानीय मुफ्त नेत्र शिविरों में भाग लें।',
                    portal: 'https://main.mohfw.gov.in',
                    faqsEn: [
                        { q: 'Is cataract surgery free?', a: 'Yes, entirely free including the lens implant at government camps and hospitals.' }
                    ],
                    faqsHi: [
                        { q: 'क्या मोतियाबिंद की सर्जरी मुफ्त है?', a: 'हाँ, सरकारी शिविरों और अस्पतालों में लेंस सहित सर्जरी पूरी तरह से मुफ्त है।' }
                    ],
                    keywords: ['npcb', 'cataract surgery', 'eye screening lens', 'blindness spectacles', 'मोतियाबिंद', 'चश्मा'],
                    age: ['0-18', '46-60', '60+'], gender: ['all', 'male', 'female'], income: ['below-1l', '1l-5l']
                },
                {
                    key: 'pmssy', icon: 'apartment',
                    tagEn: 'Infrastructure', tagHi: 'बुनियादी ढांचा',
                    nameEn: 'PM Swasthya Suraksha (PMSSY)', nameHi: 'पीएम स्वास्थ्य सुरक्षा (PMSSY)',
                    overviewEn: 'Aims at correcting regional imbalances in availability of affordable tertiary healthcare and upgrading medical infrastructure.',
                    overviewHi: 'सस्ती तृतीयक स्वास्थ्य सेवा की उपलब्धता में क्षेत्रीय असंतुलन को ठीक करने और चिकित्सा बुनियादी ढांचे के उन्नयन के लिए योजना।',
                    eligibilityEn: 'Open to all citizens seeking tertiary advanced medical treatment.',
                    eligibilityHi: 'तृतीयक उन्नत चिकित्सा उपचार चाहने वाले सभी नागरिक।',
                    benefitsEn: 'Upgrades district hospitals and constructs new AIIMS institutes to offer world-class super-specialty treatment.',
                    benefitsHi: 'विश्व स्तरीय सुपर-स्पेशियलिटी उपचार प्रदान करने के लिए जिला अस्पतालों का उन्नयन और नए एम्स संस्थानों का निर्माण।',
                    docsEn: 'Referral slip from primary/secondary hospital.',
                    docsHi: 'प्राथमिक/माध्यमिक अस्पताल से रेफरल पर्ची।',
                    processEn: 'Get referred from local civil hospital to the nearest AIIMS or upgraded medical college hospital.',
                    processHi: 'स्थानीय सिविल अस्पताल से निकटतम एम्स या अपग्रेड मेडिकल कॉलेज अस्पताल में रेफरल प्राप्त करें।',
                    portal: 'https://pmssy.mohfw.gov.in',
                    faqsEn: [
                        { q: 'Are services in AIIMS free?', a: 'Outpatient consult is free, inpatient therapies and surgeries are highly subsidized.' }
                    ],
                    faqsHi: [
                        { q: 'क्या एम्स में सेवाएं मुफ्त हैं?', a: 'बाह्य रोगी परामर्श मुफ्त है, इनपेशेंट थेरेपी और सर्जरी अत्यधिक रियायती हैं।' }
                    ],
                    keywords: ['pmssy', 'aiims referral', 'superspecialty hospital', 'surgery discount', 'एम्स', 'बड़ा अस्पताल'],
                    age: ['0-18', '19-45', '46-60', '60+'], gender: ['all', 'male', 'female'], income: ['below-1l', '1l-5l', 'above-5l']
                },
                {
                    key: 'suman', icon: 'volunteer_activism',
                    tagEn: 'Maternal', tagHi: 'मातृ स्वास्थ्य',
                    nameEn: 'Surakshit Matritva (SUMAN)', nameHi: 'सुरक्षित मातृत्व आश्वासन (SUMAN)',
                    overviewEn: 'Aims to provide dignified, respectful, and quality healthcare at zero cost to every pregnant woman and newborn.',
                    overviewHi: 'प्रत्येक गर्भवती महिला और नवजात शिशु को शून्य लागत पर सम्मानजनक और गुणवत्तापूर्ण स्वास्थ्य सेवा प्रदान करने की प्रतिबद्धता।',
                    eligibilityEn: 'All pregnant women, mothers up to 6 months post-delivery, and sick newborns.',
                    eligibilityHi: 'सभी गर्भवती महिलाएं, प्रसव के 6 महीने बाद तक की माताएं और बीमार नवजात शिशु।',
                    benefitsEn: 'Zero expense for all complications, free transport, and assured referral within 1 hour of emergency.',
                    benefitsHi: 'सभी जटिलताओं के लिए शून्य खर्च, मुफ्त परिवहन और आपातकाल में 1 घंटे के भीतर सुनिश्चित रेफरल।',
                    docsEn: 'Aadhaar Card, Mamta Card (MCP).',
                    docsHi: 'आधार कार्ड, ममता कार्ड (MCP)।',
                    processEn: 'Automatically applicable upon visiting any government health center (FRUs/CHCs) for pregnancy emergencies.',
                    processHi: 'गर्भावस्था से जुड़ी आपातकालीन स्थिति में किसी भी सरकारी स्वास्थ्य केंद्र (FRUs/CHCs) पर जाने पर स्वतः लागू।',
                    portal: 'https://nhm.gov.in',
                    faqsEn: [
                        { q: 'What does zero expense mean?', a: 'Zero cost for medicines, blood, diagnostics, and transport.' }
                    ],
                    faqsHi: [
                        { q: 'शून्य खर्च का क्या अर्थ है?', a: 'दवाओं, रक्त, जांच और परिवहन के लिए शून्य शुल्क।' }
                    ],
                    keywords: ['suman maternal', 'pregnancy referral emergency', 'newborn delivery cost', 'गर्भवती', 'शून्य खर्च'],
                    age: ['0-18', '19-45'], gender: ['female'], income: ['below-1l', '1l-5l', 'above-5l']
                },
                {
                    key: 'laqshya', icon: 'check_circle',
                    tagEn: 'Maternal', tagHi: 'मातृ स्वास्थ्य',
                    nameEn: 'LaQshya Initiative', nameHi: 'लक्ष्य (LaQshya) पहल',
                    overviewEn: 'Focuses on improving quality of care in Labour Rooms and Maternity Operation Theatres to prevent maternal mortality.',
                    overviewHi: 'मातृ मृत्यु दर को रोकने के लिए लेबर रूम और मातृत्व ऑपरेशन थिएटरों में देखभाल की गुणवत्ता में सुधार लाने पर ध्यान केंद्रित करता है।',
                    eligibilityEn: 'All pregnant women undergoing delivery in public hospitals.',
                    eligibilityHi: 'सरकारी अस्पतालों में प्रसव कराने वाली सभी गर्भवती महिलाएं।',
                    benefitsEn: 'Ensures clean, respectful maternity care, reduction in childbirth complications, and certified quality facilities.',
                    benefitsHi: 'स्वच्छ, सम्मानजनक मातृत्व देखभाल, प्रसव जटिलताओं में कमी और प्रमाणित गुणवत्तापूर्ण सुविधाएं।',
                    docsEn: 'Not required.',
                    docsHi: 'आवश्यक नहीं।',
                    processEn: 'Active standard of care implemented internally in all public medical colleges and district hospitals during delivery.',
                    processHi: 'प्रसव के दौरान सभी सरकारी मेडिकल कॉलेजों और जिला अस्पतालों में आंतरिक रूप से लागू गुणवत्ता मानक।',
                    portal: 'https://nhm.gov.in',
                    faqsEn: [
                        { q: 'Is there a cash benefit?', a: 'No, this is a facility quality certification program, not a direct cash scheme.' }
                    ],
                    faqsHi: [
                        { q: 'क्या कोई नकद लाभ है?', a: 'नहीं, यह सुविधा की गुणवत्ता प्रमाणन कार्यक्रम है, कोई नकद योजना नहीं।' }
                    ],
                    keywords: ['laqshya labour room', 'safe birth delivery quality', 'maternity care safety', 'लेबर रूम', 'प्रसव कक्ष'],
                    age: ['19-45'], gender: ['female'], income: ['below-1l', '1l-5l', 'above-5l']
                },
                {
                    key: 'naco', icon: 'health_and_safety',
                    tagEn: 'Infections', tagHi: 'संक्रमण नियंत्रण',
                    nameEn: 'National AIDS Control (NACO)', nameHi: 'राष्ट्रीय एड्स नियंत्रण कार्यक्रम',
                    overviewEn: 'Provides free diagnostics, counseling, and antiretroviral therapy (ART) drugs for HIV/AIDS patients.',
                    overviewHi: 'एचआईवी/एड्स के रोगियों के लिए मुफ्त निदान, परामर्श और एंटीरेट्रोवाइरल थेरेपी (ART) दवाएं प्रदान करता है।',
                    eligibilityEn: 'Any individual requiring HIV screening or diagnosed positive for HIV.',
                    eligibilityHi: 'एचआईवी परीक्षण की आवश्यकता वाले या एचआईवी पॉजिटिव पाए गए कोई भी व्यक्ति।',
                    benefitsEn: 'Free CD4 tests, free lifelong ART medications, counselor support, and prevention kits.',
                    benefitsHi: 'मुफ्त सीडी4 जांच, जीवन भर मुफ्त एआरटी दवाएं, काउंसलर सहायता और रोकथाम किट।',
                    docsEn: 'Confidential registration card issued at government ART center.',
                    docsHi: 'सरकारी एआरटी केंद्र पर जारी गोपनीय पंजीकरण कार्ड।',
                    processEn: 'Visit nearest Integrated Counseling and Testing Center (ICTC) for confidential testing and medication enrollment.',
                    processHi: 'गोपनीय परीक्षण और उपचार पंजीकरण के लिए निकटतम एकीकृत परामर्श और परीक्षण केंद्र (ICTC) पर जाएं।',
                    portal: 'https://naco.gov.in',
                    faqsEn: [
                        { q: 'Is my identity kept secret?', a: 'Yes, patient confidentiality is strictly protected by law.' }
                    ],
                    faqsHi: [
                        { q: 'क्या मेरी पहचान गुप्त रखी जाती है?', a: 'हाँ, रोगी की गोपनीयता कानून द्वारा कड़ाई से संरक्षित है।' }
                    ],
                    keywords: ['naco art', 'hiv testing free', 'antiretroviral medications', 'ictc clinic', 'एड्स', 'एआरटी'],
                    age: ['0-18', '19-45', '46-60', '60+'], gender: ['all', 'male', 'female'], income: ['below-1l', '1l-5l', 'above-5l']
                },
                {
                    key: 'national_oral_health', icon: 'mood',
                    tagEn: 'Dental', tagHi: 'दंत स्वास्थ्य',
                    nameEn: 'National Oral Health Program', nameHi: 'राष्ट्रीय दंत स्वास्थ्य कार्यक्रम',
                    overviewEn: 'Aims to provide affordable, accessible, and comprehensive oral healthcare services at public facilities.',
                    overviewHi: 'सरकारी अस्पतालों में सस्ती, सुलभ और व्यापक दंत चिकित्सा सेवाएं प्रदान करने का लक्ष्य।',
                    eligibilityEn: 'All individuals requiring dental diagnostics, fillings, or extractions.',
                    eligibilityHi: 'दंत चिकित्सा, दांतों की फिलिंग या निकलवाने की आवश्यकता वाले सभी नागरिक।',
                    benefitsEn: 'Free dental checkups, extractions, basic fillings, and oral cancer screening.',
                    benefitsHi: 'दंत चिकित्सा जांच, दांत उखाड़ना, बुनियादी फिलिंग और मुंह के कैंसर की मुफ्त जांच।',
                    docsEn: 'Not required.',
                    docsHi: 'आवश्यक नहीं।',
                    processEn: 'Visit the dental OPD wing at any government community health center or district hospital.',
                    processHi: 'किसी भी सरकारी सामुदायिक स्वास्थ्य केंद्र या जिला अस्पताल में दंत ओपीडी विंग पर जाएं।',
                    portal: 'https://main.mohfw.gov.in',
                    faqsEn: [
                        { q: 'Are root canals covered?', a: 'Basic fillings and extractions are free; complex root canals are available at subsidized rates.' }
                    ],
                    faqsHi: [
                        { q: 'क्या रूट कैनाल शामिल है?', a: 'बुनियादी फिलिंग और दांत उखाड़ना मुफ्त है; जटिल रूट कैनाल रियायती दरों पर उपलब्ध हैं।' }
                    ],
                    keywords: ['oral health', 'dental tooth fillings', 'dentist tooth extraction', 'दांत दर्द', 'दंत चिकित्सक'],
                    age: ['0-18', '19-45', '46-60', '60+'], gender: ['all', 'male', 'female'], income: ['below-1l', '1l-5l', 'above-5l']
                },
                {
                    key: 'national_tobacco_control', icon: 'smoke_free',
                    tagEn: 'Substance Control', tagHi: 'नशामुक्ति',
                    nameEn: 'Tobacco Control Program', nameHi: 'राष्ट्रीय तंबाकू नियंत्रण कार्यक्रम',
                    overviewEn: 'Promotes public awareness regarding tobacco hazards and facilitates cessation centers to help users quit.',
                    overviewHi: 'तंबाकू के खतरों के बारे में जन जागरूकता को बढ़ावा देता है और उपयोगकर्ताओं को तंबाकू छोड़ने में मदद करने के लिए नशामुक्ति केंद्रों की सुविधा प्रदान करता है।',
                    eligibilityEn: 'Any citizen wishing to quit smoking or tobacco consumption.',
                    eligibilityHi: 'धूम्रपान या तंबाकू का सेवन छोड़ने का इच्छुक कोई भी नागरिक।',
                    benefitsEn: 'Free counseling, nicotine replacement therapies (gum/patches), and behavioral support.',
                    benefitsHi: 'मुफ्त परामर्श, निकोटीन रिप्लेसमेंट थेरेपी (गम/पैच) और व्यवहारिक सहायता।',
                    docsEn: 'Not required.',
                    docsHi: 'आवश्यक नहीं।',
                    processEn: 'Visit tobacco cessation clinics at district hospitals or call the national quitline (1800-11-2356).',
                    processHi: 'जिला अस्पतालों में तंबाकू नशामुक्ति क्लीनिकों पर जाएं या राष्ट्रीय क्विटलाइन (1800-11-2356) पर कॉल करें।',
                    portal: 'https://ntcp.mohfw.gov.in',
                    faqsEn: [
                        { q: 'Is the quitline free?', a: 'Yes, the quitline offers free counseling in multiple languages.' }
                    ],
                    faqsHi: [
                        { q: 'क्या क्विटलाइन मुफ्त है?', a: 'हाँ, क्विटलाइन विभिन्न भाषाओं में मुफ्त परामर्श प्रदान करती है।' }
                    ],
                    keywords: ['tobacco control', 'quit smoking nicotex', 'cessation counseling', 'quitline', 'तंबाकू छोड़ें', 'नशामुक्ति'],
                    age: ['19-45', '46-60', '60+'], gender: ['all', 'male', 'female'], income: ['below-1l', '1l-5l', 'above-5l']
                },
                {
                    key: 'nvbdcp_malaria', icon: 'local_pharmacy',
                    tagEn: 'Infections', tagHi: 'संक्रमण नियंत्रण',
                    nameEn: 'Malaria Mukt Bharat Initiative', nameHi: 'मलेरिया मुक्त भारत अभियान',
                    overviewEn: 'Targeted drive to eliminate malaria from rural communities through diagnostic camps and surveillance.',
                    overviewHi: 'नैदानिक शिविरों और निगरानी के माध्यम से ग्रामीण समुदायों से मलेरिया को समाप्त करने का लक्षित अभियान।',
                    eligibilityEn: 'Any rural resident experiencing high fever with chills.',
                    eligibilityHi: 'कंपकंपी के साथ तेज बुखार का अनुभव करने वाला कोई भी ग्रामीण निवासी।',
                    benefitsEn: 'Free rapid blood slide tests and immediate distribution of ACT drug combination therapy.',
                    benefitsHi: 'मुफ्त त्वरित रक्त स्लाइड परीक्षण और एसीटी (ACT) दवा संयोजन चिकित्सा का तत्काल वितरण।',
                    docsEn: 'Not required.',
                    docsHi: 'आवश्यक नहीं।',
                    processEn: 'Report to the local ASHA worker or sub-health center for an immediate malaria finger-prick test.',
                    processHi: 'त्वरित मलेरिया जांच (फिंगर-प्रिक) के लिए स्थानीय आशा कार्यकर्ता या उप-स्वास्थ्य केंद्र से संपर्क करें।',
                    portal: 'https://nvbdcp.gov.in',
                    faqsEn: [
                        { q: 'How long does the test take?', a: 'Rapid diagnostic kits give results within 15 minutes.' }
                    ],
                    faqsHi: [
                        { q: 'जांच में कितना समय लगता है?', a: 'रैपिड डायग्नोस्टिक किट 15 मिनट के भीतर परिणाम देती हैं।' }
                    ],
                    keywords: ['malaria mukt', 'fever chills test', 'act treatment malaria', 'मलेरिया जांच', 'बुखार'],
                    age: ['0-18', '19-45', '46-60', '60+'], gender: ['all', 'male', 'female'], income: ['below-1l', '1l-5l', 'above-5l']
                },
                {
                    key: 'nphce_geriatric', icon: 'elderly_woman',
                    tagEn: 'Geriatric', tagHi: 'बुजुर्ग देखभाल',
                    nameEn: 'Elderly Rehabilitation Centers', nameHi: 'बुजुर्ग पुनर्वास केंद्र योजना',
                    overviewEn: 'Establishes medical rehabilitation units at district levels to provide specialized physical therapies for senior citizens.',
                    overviewHi: 'वरिष्ठ नागरिकों के लिए विशेष भौतिक चिकित्सा प्रदान करने के लिए जिला स्तर पर चिकित्सा पुनर्वास इकाइयां स्थापित करना।',
                    eligibilityEn: 'Senior citizens requiring physical therapy, mobility aid, or rehabilitation.',
                    eligibilityHi: 'वरिष्ठ नागरिक जिन्हें फिजियोथेरेपी, गतिशीलता सहायता या पुनर्वास की आवश्यकता है।',
                    benefitsEn: 'Free orthopedic rehabilitation, stroke recovery therapy, and support group meetings.',
                    benefitsHi: 'वरिष्ठों के लिए मुफ्त ऑर्थोपेडिक पुनर्वास, पक्षाघात (स्ट्रोक) रिकवरी थेरेपी और सहायता समूह बैठकें।',
                    docsEn: 'Aadhaar Card, Geriatric OPD booklet.',
                    docsHi: 'आधार कार्ड, बुजुर्ग ओपीडी बुकलेट।',
                    processEn: 'Visit the rehabilitation and physiotherapy clinic at the nearest government civil hospital.',
                    processHi: 'निकटतम सरकारी सिविल अस्पताल में पुनर्वास और फिजियोथेरेपी क्लिनिक पर जाएं।',
                    portal: 'https://main.mohfw.gov.in',
                    faqsEn: [
                        { q: 'Are walk assistive devices free?', a: 'Yes, devices like walkers and canes are distributed free based on medical assessment.' }
                    ],
                    faqsHi: [
                        { q: 'क्या चलने वाले सहायक उपकरण मुफ्त हैं?', a: 'हाँ, वॉकर और लाठी जैसे उपकरण चिकित्सा मूल्यांकन के आधार पर मुफ्त वितरित किए जाते हैं।' }
                    ],
                    keywords: ['elderly rehab', 'physiotherapy stroke', 'walker assistive canes', 'बुजुर्ग फिजियो', 'छड़ी'],
                    age: ['60+'], gender: ['all', 'male', 'female'], income: ['below-1l', '1l-5l']
                },
                {
                    key: 'rksk_clinic', icon: 'sentiment_very_satisfied',
                    tagEn: 'Adolescent', tagHi: 'किशोर स्वास्थ्य',
                    nameEn: 'Saathiya Helpline Advisory', nameHi: 'साथिया किशोर परामर्श केंद्र',
                    overviewEn: 'Youth-friendly clinics operating under National Health Mission providing physical and emotional health counseling.',
                    overviewHi: 'राष्ट्रीय स्वास्थ्य मिशन के तहत संचालित युवा-अनुकूल क्लीनिक जो शारीरिक और भावनात्मक स्वास्थ्य परामर्श प्रदान करते हैं।',
                    eligibilityEn: 'Young adults and adolescents aged 10-19 years.',
                    eligibilityHi: '10-19 वर्ष की आयु के युवा और किशोर-किशोरियां।',
                    benefitsEn: 'Free psychological counseling, nutritional advice for puberty, and sexual health guidance.',
                    benefitsHi: 'मुफ्त मनोवैज्ञानिक परामर्श, किशोरावस्था पोषण सलाह और यौन स्वास्थ्य मार्गदर्शन।',
                    docsEn: 'Not required.',
                    docsHi: 'आवश्यक नहीं।',
                    processEn: 'Visit nearest government health center and ask for the Saathiya clinic wing.',
                    processHi: 'निकटतम सरकारी स्वास्थ्य केंद्र पर जाएं और साथिया क्लिनिक विभाग के बारे में पूछें।',
                    portal: 'https://nhm.gov.in',
                    faqsEn: [
                        { q: 'Are details kept confidential?', a: 'Yes, counseling sessions are strictly private and confidential.' }
                    ],
                    faqsHi: [
                        { q: 'क्या विवरण गुप्त रखे जाते हैं?', a: 'हाँ, परामर्श सत्र पूरी तरह से निजी और गुप्त होते हैं।' }
                    ],
                    keywords: ['saathiya clinic', 'puberty counseling', 'adolescent stress guidance', 'साथिया केंद्र', 'काउंसलिंग'],
                    age: ['0-18'], gender: ['all', 'male', 'female'], income: ['below-1l', '1l-5l', 'above-5l']
                },
                {
                    key: 'national_deafness_control', icon: 'hearing',
                    tagEn: 'Otology', tagHi: 'श्रवण स्वास्थ्य',
                    nameEn: 'Program for Control of Deafness', nameHi: 'राष्ट्रीय बधिरता नियंत्रण कार्यक्रम',
                    overviewEn: 'Aims to prevent, diagnose, and treat hearing loss through screening camps and free hearing aids.',
                    overviewHi: 'जांच शिविरों और मुफ्त श्रवण यंत्रों के माध्यम से सुनने की क्षमता के नुकसान को रोकने, निदान करने और इलाज करने की योजना।',
                    eligibilityEn: 'Citizens suffering from severe hearing impairment or middle ear infections.',
                    eligibilityHi: 'गंभीर श्रवण दोष या मध्य कान के संक्रमण से पीड़ित नागरिक।',
                    benefitsEn: 'Free hearing testing (audiometry), ENT checkups, and distribution of behind-the-ear hearing aids.',
                    benefitsHi: 'मुफ्त श्रवण परीक्षण (ऑडियोमेट्री), ईएनटी जांच और कान के पीछे लगाने वाले श्रवण यंत्रों का वितरण।',
                    docsEn: 'Aadhaar Card, Disability Certificate (if applicable for advanced aid).',
                    docsHi: 'आधार कार्ड, विकलांगता प्रमाण पत्र (यदि उन्नत सहायता के लिए आवश्यक हो)।',
                    processEn: 'Attend specialized ENT screening clinics at government medical colleges or district hospitals.',
                    processHi: 'सरकारी मेडिकल कॉलेजों या जिला अस्पतालों में विशेष ईएनटी स्क्रीनिंग क्लीनिक में भाग लें।',
                    portal: 'https://main.mohfw.gov.in',
                    faqsEn: [
                        { q: 'Are hearing aids free?', a: 'Yes, basic hearing aids are provided free to eligible low-income patients.' }
                    ],
                    faqsHi: [
                        { q: 'क्या बहरेपन की मशीन मुफ्त है?', a: 'हाँ, बुनियादी श्रवण यंत्र पात्र कम आय वाले रोगियों को मुफ्त दिए जाते हैं।' }
                    ],
                    keywords: ['deafness program', 'hearing aid free machine', 'ent clinic audiometry', 'कान की मशीन', 'ईएनटी'],
                    age: ['0-18', '46-60', '60+'], gender: ['all', 'male', 'female'], income: ['below-1l', '1l-5l']
                },
                {
                    key: 'amrit_implants', icon: 'local_mall',
                    tagEn: 'Medicines', tagHi: 'दवाइयाँ',
                    nameEn: 'AMRIT Surgical Implants Hub', nameHi: 'अमृत सर्जिकल प्रत्यारोपण केंद्र',
                    overviewEn: 'Subsidized outlet inside central hospitals selling surgical joints, heart valves, and implants at massive discounts.',
                    overviewHi: 'सस्ती दरों पर सर्जिकल जॉइंट्स, हार्ट वाल्व और चिकित्सा प्रत्यारोपण बेचने वाले अमृत आउटलेट।',
                    eligibilityEn: 'Patients undergoing major surgical procedures requiring implants.',
                    eligibilityHi: 'सर्जरी के लिए प्रत्यारोपण (इम्प्लांट) की आवश्यकता वाले मरीज।',
                    benefitsEn: 'Access to orthopedic joints, pacemakers, and valves at up to 70% cheaper than open market.',
                    benefitsHi: 'खुले बाजार की तुलना में 70% तक सस्ते ऑर्थोपेडिक जोड़ों, पेसमेकर और वाल्व की उपलब्धता।',
                    docsEn: 'Surgeon Prescription, Aadhaar Card.',
                    docsHi: 'सर्जन का नुस्खा (प्रिस्क्रिप्शन), आधार कार्ड।',
                    processEn: 'Submit doctor\'s implant requirement sheet at the institutional AMRIT pharmacy during billing.',
                    processHi: 'बिलिंग के दौरान मेडिकल संस्थान के भीतर स्थित अमृत स्टोर पर डॉक्टर की इम्प्लांट आवश्यकता सूची जमा करें।',
                    portal: 'http://www.hlllifecare.com',
                    faqsEn: [
                        { q: 'Are these implants quality-certified?', a: 'Yes, AMRIT only stocks verified, medical-grade reliable implants.' }
                    ],
                    faqsHi: [
                        { q: 'क्या ये प्रत्यारोपण प्रमाणित हैं?', a: 'हाँ, अमृत में केवल सत्यापित, मेडिकल-ग्रेड विश्वसनीय प्रत्यारोपण ही रखे जाते हैं।' }
                    ],
                    keywords: ['amrit implants', 'joint replacement valve', 'pacemaker discount cardiac', 'इम्प्लांट', 'पेसमेकर'],
                    age: ['19-45', '46-60', '60+'], gender: ['all', 'male', 'female'], income: ['below-1l', '1l-5l', 'above-5l']
                }
            ];

            const ageMap = {
                'Select Age Group': null,
                '0-18 Years': '0-18',
                '19-45 Years': '19-45',
                '46-60 Years': '46-60',
                '60+ Years': '60+'
            };
            const genderMap = {
                'All Genders': null,
                'Female (Special Schemes)': 'female',
                'Male': 'male'
            };
            const incomeMap = {
                'Any Income': null,
                'Below ₹1,00,000': 'below-1l',
                '₹1,00,000 - ₹5,00,000': '1l-5l',
                'Above ₹5,00,000': 'above-5l'
            };

            // Global FAQs toggle handler inside container
            schContainer.addEventListener('click', (e) => {
                const toggleBtn = e.target.closest('.toggle-scheme-details');
                if (toggleBtn) {
                    const article = toggleBtn.closest('article');
                    const detailsDiv = article.querySelector('.scheme-expanded-details');
                    const expandIcon = toggleBtn.querySelector('.expand-icon');
                    
                    if (detailsDiv) {
                        const isHidden = detailsDiv.classList.contains('hidden');
                        if (isHidden) {
                            detailsDiv.classList.remove('hidden');
                            toggleBtn.classList.add('bg-secondary-fixed/10');
                            if (expandIcon) expandIcon.textContent = 'expand_less';
                        } else {
                            detailsDiv.classList.add('hidden');
                            toggleBtn.classList.remove('bg-secondary-fixed/10');
                            if (expandIcon) expandIcon.textContent = 'expand_more';
                        }
                    }
                }
            });

            const renderSchemes = (ageFilter, genderFilter, incomeFilter, searchVal = '') => {
                const lang = localStorage.getItem('sehatsathi_lang') || 'en';
                schContainer.innerHTML = '';
                const query = searchVal.toLowerCase().replace(/[.,\/#!$%\^&\*;:{}=\-_`~()]/g,"").replace(/\s+/g," ").trim();

                const filtered = schemesList.filter(sch => {
                    // 1. Selector filters
                    if (ageFilter && !sch.age.includes(ageFilter)) return false;
                    if (genderFilter && !sch.gender.includes(genderFilter)) return false;
                    if (incomeFilter && !sch.income.includes(incomeFilter)) return false;
                    
                    // 2. Search match
                    if (query) {
                        const name = (lang === 'hi' ? sch.nameHi : sch.nameEn).toLowerCase();
                        const overview = (lang === 'hi' ? sch.overviewHi : sch.overviewEn).toLowerCase();
                        const eligibility = (lang === 'hi' ? sch.eligibilityHi : sch.eligibilityEn).toLowerCase();
                        const benefits = (lang === 'hi' ? sch.benefitsHi : sch.benefitsEn).toLowerCase();
                        
                        const matchTitle = name.includes(query);
                        const matchOverview = overview.includes(query);
                        const matchElig = eligibility.includes(query);
                        const matchBen = benefits.includes(query);
                        const matchKeywords = sch.keywords.some(k => k.includes(query));

                        if (!matchTitle && !matchOverview && !matchElig && !matchBen && !matchKeywords) {
                            return false;
                        }
                    }
                    return true;
                });

                if (filtered.length === 0) {
                    schContainer.innerHTML = `<div class="col-span-full text-center text-on-surface-variant py-16">
                        <span class="material-symbols-outlined text-4xl mb-3 block">search_off</span>
                        <p>${lang === 'hi' ? 'कोई योजना आपके खोज मानदंडों से मेल नहीं खाती।' : 'No schemes match the selected filters. Try different criteria.'}</p>
                    </div>`;
                    return;
                }

                filtered.forEach(sch => {
                    const name = lang === 'hi' ? sch.nameHi : sch.nameEn;
                    const overview = lang === 'hi' ? sch.overviewHi : sch.overviewEn;
                    const eligibility = lang === 'hi' ? sch.eligibilityHi : sch.eligibilityEn;
                    const benefits = lang === 'hi' ? sch.benefitsHi : sch.benefitsEn;
                    const tag = lang === 'hi' ? sch.tagHi : sch.tagEn;
                    const docs = lang === 'hi' ? sch.docsHi : sch.docsEn;
                    const process = lang === 'hi' ? sch.processHi : sch.processEn;
                    const faqs = lang === 'hi' ? sch.faqsHi : sch.faqsEn;

                    let faqsHtml = '';
                    if (faqs && faqs.length > 0) {
                        faqs.forEach(f => {
                            faqsHtml += `
                                <div class="bg-surface-container/30 p-2.5 rounded-lg border border-white/5">
                                    <p class="text-xs text-secondary-fixed font-bold">Q: ${f.q}</p>
                                    <p class="text-[11px] text-on-surface-variant/90 mt-1">${f.a}</p>
                                </div>
                            `;
                        });
                    }

                    let keywordsHtml = '';
                    sch.keywords.forEach(k => {
                        keywordsHtml += `<span class="text-[10px] bg-white/5 border border-white/5 px-2 py-0.5 rounded-full text-on-surface-variant">${k}</span>`;
                    });

                    const cardHtml = `
                        <article class="glass-card rounded-xl p-5 flex flex-col justify-between border border-white/5 bg-surface-container-low/40 relative overflow-hidden transition-all duration-300 hover:shadow-lg hover:border-secondary-fixed/30 h-auto">
                            <div>
                                <div class="flex items-center gap-3 mb-4">
                                    <div class="w-10 h-10 rounded-lg bg-surface-container-highest flex items-center justify-center border border-white/10 text-secondary-fixed shrink-0 shadow-[0_0_10px_rgba(0,241,254,0.1)]">
                                        <span class="material-symbols-outlined text-xl" style="font-variation-settings: 'FILL' 1;">${sch.icon}</span>
                                    </div>
                                    <div>
                                        <span class="text-[10px] bg-secondary-container/10 text-secondary-fixed px-2 py-0.5 rounded border border-secondary-fixed/20 font-bold uppercase tracking-wider">${tag}</span>
                                        <h3 class="text-base text-white font-bold mt-1 leading-tight">${name}</h3>
                                    </div>
                                </div>
                                <p class="text-xs text-on-surface-variant/90 mb-4">${overview}</p>

                                <div class="space-y-2.5 border-t border-white/5 pt-3">
                                    <div class="text-[11px]"><strong class="text-secondary-fixed">${lang === 'hi' ? 'पात्रता' : 'Eligibility'}:</strong> <span class="text-on-surface-variant/90">${eligibility}</span></div>
                                    <div class="text-[11px]"><strong class="text-secondary-fixed">${lang === 'hi' ? 'लाभ' : 'Benefits'}:</strong> <span class="text-on-surface-variant/90">${benefits}</span></div>
                                </div>

                                <!-- Expandable Details Section -->
                                <div class="scheme-expanded-details hidden mt-3 pt-3 border-t border-white/5 space-y-3">
                                    <div class="text-[11px]"><strong class="text-secondary-fixed">${lang === 'hi' ? 'आवश्यक दस्तावेज' : 'Required Documents'}:</strong> <span class="text-on-surface-variant/90">${docs}</span></div>
                                    <div class="text-[11px]"><strong class="text-secondary-fixed">${lang === 'hi' ? 'आवेदन प्रक्रिया' : 'Application Process'}:</strong> <span class="text-on-surface-variant/90">${process}</span></div>
                                    
                                    <div class="text-[11px]">
                                        <strong class="text-secondary-fixed block mb-1">${lang === 'hi' ? 'अक्सर पूछे जाने वाले प्रश्न' : 'FAQs'}:</strong>
                                        <div class="space-y-2 mt-1">
                                            ${faqsHtml}
                                        </div>
                                    </div>

                                    <div class="flex flex-wrap gap-1 mt-2">
                                        ${keywordsHtml}
                                    </div>

                                    <a href="${sch.portal}" target="_blank" class="w-full flex items-center justify-center gap-1.5 py-2 px-3 mt-3 bg-secondary-fixed text-on-secondary-fixed font-bold text-xs rounded-lg hover:shadow-[0_0_10px_rgba(0,241,254,0.3)] transition-all">
                                        <span class="material-symbols-outlined text-[14px]">language</span>
                                        <span>${lang === 'hi' ? 'आधिकारिक पोर्टल पर जाएं' : 'Visit Official Portal'}</span>
                                    </a>
                                </div>
                            </div>

                            <button class="toggle-scheme-details w-full mt-4 py-2 border border-white/5 hover:border-secondary-fixed/30 hover:bg-secondary-fixed/5 rounded-lg flex items-center justify-center gap-1 text-xs text-secondary-fixed font-bold transition-all">
                                <span class="expand-icon material-symbols-outlined text-[16px]">expand_more</span>
                                <span>${lang === 'hi' ? 'अधिक विवरण देखें' : 'Toggle Details'}</span>
                            </button>
                        </article>
                    `;
                    schContainer.insertAdjacentHTML('beforeend', cardHtml);
                });
            };

            const findBtn = document.querySelector('main button.bg-gradient-to-r');
            const selects = document.querySelectorAll('main select');
            const searchInput = document.getElementById('scheme-search-input');

            const applyFilters = () => {
                const ageVal   = selects[0] ? ageMap[selects[0].value]    : null;
                const genderVal= selects[1] ? genderMap[selects[1].value] : null;
                const incomeVal= selects[2] ? incomeMap[selects[2].value] : null;
                const searchVal = searchInput ? searchInput.value : '';
                renderSchemes(ageVal, genderVal, incomeVal, searchVal);
            };

            if (findBtn) findBtn.addEventListener('click', applyFilters);
            selects.forEach(sel => sel.addEventListener('change', applyFilters));
            if (searchInput) {
                searchInput.addEventListener('input', applyFilters);
            }

            renderSchemes(null, null, null, '');
        }
    }


    // ==========================================
    // 10.4. PAGE INTERACTIONS: SYMPTOM CHECKER
    // ==========================================
    if (pageName.includes('symptom-checker')) {
        const scGrid = document.getElementById('symptom-checker-grid');
        const searchInput = document.getElementById('symptom-search-input');
        
        let lang = localStorage.getItem('sehatsathi_lang') || 'en';
        
        const iconMap = {
            "fever": "thermostat",
            "runny_nose": "severe_cold",
            "cough": "coronavirus",
            "malaria": "sick",
            "dengue": "sick",
            "typhoid": "sick",
            "tuberculosis": "sick",
            "pneumonia": "sick",
            "bronchitis": "sick",
            "cholera": "sick",
            "hepatitis": "sick",
            "jaundice": "sick",
            "fatty_liver": "sick",
            "ulcer": "sick",
            "gastritis": "sick",
            "piles": "sick",
            "appendicitis": "sick",
            "kidney_stones": "sick",
            "tonsillitis": "sick",
            "chickenpox": "sick",
            "measles": "sick",
            "headache": "sentiment_dissatisfied",
            "body_ache": "sentiment_dissatisfied",
            "sore_throat": "sentiment_dissatisfied",
            "vomiting": "sick",
            "nausea": "sick",
            "stomach_pain": "healing",
            "chest_pain": "cardiology",
            "back_pain": "accessibility",
            "joint_pain": "accessibility",
            "dizziness": "speed",
            "fatigue": "battery_alert",
            "skin_rash": "healing",
            "itching": "healing",
            "diarrhea": "water_drop",
            "constipation": "water_drop",
            "bloating": "water_drop",
            "acid_reflux": "water_drop",
            "type_2_diabetes": "bloodtype",
            "high_cholesterol": "bloodtype",
            "fatty_liver_disease": "healing",
            "asthma_lifestyle": "airwave",
            "arthritis": "accessibility",
            "dementia": "psychiatry",
            "alzheimers": "psychiatry",
            "parkinsons": "psychiatry",
            "osteoporosis": "accessibility",
            "cataract": "visibility",
            "hearing_loss": "volume_up",
            "prostate_issues": "healing",
            "pregnancy_care": "pregnant_woman",
            "menstrual_cramps": "calendar_today",
            "pcos": "calendar_today",
            "uti": "local_drink",
            "breast_cancer": "healing",
            "cervical_cancer": "healing",
            "osteoporosis_women": "accessibility",
            "thyroid_women": "health_and_safety",
            "menopause": "calendar_today",
            "pregnancy_spacing": "calendar_today",
            "pregnancy_diet": "nutrition",
            "pmsma": "pregnant_woman",
            "morning_sickness": "sick",
            "gestational_diabetes": "bloodtype",
            "preeclampsia": "pregnant_woman",
            "postpartum_care": "pregnant_woman",
            "breastfeeding": "child_care",
            "folic_acid": "bloodtype",
            "prenatal_exercise": "accessibility",
            "miscarriage": "pregnant_woman",
            "labor_signs": "pregnant_woman",
            "anemia_diet": "bloodtype",
            "vaccination_schedule": "vaccines",
            "child_fever": "thermostat",
            "colic": "child_care",
            "diaper_rash": "child_care",
            "childhood_obesity": "trending_up",
            "teething": "child_care",
            "deworming": "vaccines",
            "pediatric_asthma": "airwave",
            "dehydration_in_children": "local_drink",
            "mumps": "sick",
            "rubella": "sick",
            "child_nutrition": "nutrition",
            "bcg_vaccine": "vaccines",
            "polio_vaccine": "vaccines",
            "hepatitis_b_vaccine": "vaccines",
            "tetanus_vaccine": "vaccines",
            "mmr_vaccine": "vaccines",
            "dpt_vaccine": "vaccines",
            "flu_shot": "vaccines",
            "covid_vaccine": "vaccines",
            "hpv_vaccine": "vaccines"
        };

        const renderSymptoms = (query = '') => {
            if (!scGrid) return;
            scGrid.innerHTML = '';
            
            const normalizedQuery = query.toLowerCase().trim();

            for (let key in window.healthKnowledge) {
                // Skip schemes or emergency first aid
                if (['pmjay', 'abha', 'jsy', 'indradhanush', 'nhm', 'first aid', 'heart attack', 'stroke', 'burns', 'severe bleeding', 'fracture', 'seizure', 'breathing difficulty', 'snake bite', 'choking', 'electric shock', 'unconscious'].includes(key)) continue;

                const entry = window.healthKnowledge[key];
                const content = entry[lang] || entry['en'];
                const name = content.name;
                const overview = content.overview;
                const icon = iconMap[key] || "medical_services";

                if (normalizedQuery && !name.toLowerCase().includes(normalizedQuery) && !overview.toLowerCase().includes(normalizedQuery)) {
                    continue;
                }

                const symPreview = content.symptoms ? content.symptoms.split('\n')[0].replace(/^[•\-\s]+/, '') : "";

                const cardHtml = `
                    <button class="glass-panel rounded-xl p-md flex flex-col items-center text-center gap-sm transition-all duration-300 hover:-translate-y-1 group text-left w-full animate-fade-in-up" onclick="openSymptomDetailsModal('${key}')">
                        <div class="w-16 h-16 rounded-full bg-primary-container/80 flex items-center justify-center mb-sm group-hover:glow-accent transition-all border border-primary-fixed/20 shadow-[0_0_15px_rgba(0,241,254,0.05)]">
                            <span class="material-symbols-outlined text-tertiary-fixed text-4xl" style="font-variation-settings: 'FILL' 1;">${icon}</span>
                        </div>
                        <h3 class="font-title-md text-title-md text-on-surface font-semibold">${name}</h3>
                        <p class="font-body-md text-body-md text-on-surface-variant text-sm line-clamp-1">${symPreview}</p>
                    </button>
                `;
                scGrid.insertAdjacentHTML('beforeend', cardHtml);
            }
        };

        if (searchInput) {
            searchInput.addEventListener('input', (e) => {
                renderSymptoms(e.target.value);
            });
        }

        renderSymptoms();
        
        window.openSymptomDetailsModal = (key) => {
            const modal = document.getElementById('symptomModal');
            const modalContent = document.getElementById('modalContent');
            const entry = window.healthKnowledge[key];
            if (!entry) return;

            const content = entry[lang] || entry['en'];
            const icon = iconMap[key] || "medical_services";

            document.getElementById('modalTitle').textContent = content.name;
            document.getElementById('modalIcon').textContent = icon;

            const causesList = document.getElementById('modalCausesList');
            causesList.innerHTML = content.causes ? content.causes.split('\n').map(line => `<li>${line.replace(/^[•\-\s]+/, '')}</li>`).join('') : "";

            const careList = document.getElementById('modalCareList');
            careList.innerHTML = content.homeCare ? content.homeCare.split('\n').map(line => `<li>${line.replace(/^[•\-\s]+/, '')}</li>`).join('') : "";

            const warningList = document.getElementById('modalWarningList');
            warningList.innerHTML = (content.dangerSigns ? content.dangerSigns.split('\n').map(line => `<li>${line.replace(/^[•\-\s]+/, '')}</li>`).join('') : "") + `<li><strong>${lang === 'hi' ? 'डॉक्टर से परामर्श' : 'Consult Doctor'}:</strong> ${content.doctorVisit || ''}</li>`;

            if (modal) {
                modal.classList.remove('hidden');
                modal.classList.add('flex');
                void modal.offsetWidth;
                modal.classList.remove('opacity-0');
            }
            if (modalContent) {
                modalContent.classList.remove('scale-95');
                modalContent.classList.add('scale-100');
            }
        };

        window.closeSymptomDetailsModal = () => {
            const modal = document.getElementById('symptomModal');
            const modalContent = document.getElementById('modalContent');
            if (modal) modal.classList.add('opacity-0');
            if (modalContent) {
                modalContent.classList.remove('scale-100');
                modalContent.classList.add('scale-95');
            }
            setTimeout(() => {
                if (modal) {
                    modal.classList.add('hidden');
                    modal.classList.remove('flex');
                }
            }, 300);
        };

        const modal = document.getElementById('symptomModal');
        if (modal) {
            modal.addEventListener('click', (e) => {
                if (e.target === modal) {
                    window.closeSymptomDetailsModal();
                }
            });
        }
    }

    // ==========================================
    // 10.45. PAGE INTERACTIONS: COMMUNITY HEALTH SURVEY
    // ==========================================
    if (pageName.includes('community-survey')) {
        const form = document.getElementById('health-form');
        const sections = [
            document.getElementById('section-1'),
            document.getElementById('section-2'),
            document.getElementById('section-3'),
            document.getElementById('section-4')
        ];
        const progressBar = document.getElementById('progress-bar');
        const progressText = document.getElementById('progress-text');
        
        let lang = localStorage.getItem('sehatsathi_lang') || 'en';

        if (form && progressBar && progressText) {
            form.addEventListener('input', () => {
                let filledSections = 0;
                const checkSection = (index, inputSelector) => {
                    if (!sections[index]) return;
                    const inputs = sections[index].querySelectorAll(inputSelector);
                    let hasValue = false;
                    inputs.forEach(input => {
                        if (input.type === 'radio' || input.type === 'checkbox') {
                            if (input.checked) hasValue = true;
                        } else if (input.value.trim() !== '') {
                            hasValue = true;
                        }
                    });
                    if (hasValue) filledSections++;
                };

                checkSection(0, 'input[required], select[required]');
                checkSection(1, 'input[required], select[required]');
                checkSection(2, 'input[required], select[required]');
                checkSection(3, 'textarea');

                const progress = Math.max(1, filledSections);
                const percentage = (progress / 4) * 100;
                
                progressBar.style.width = `${percentage}%`;
                progressText.textContent = lang === 'hi' ? `चरण ${progress} of 4` : `Step ${progress} of 4`;
            });
        }

        window.submitCommunitySurvey = () => {
            const header = document.getElementById('survey-header');
            const progressContainer = document.getElementById('progress-container');
            const results = document.getElementById('results-section');
            
            let currentStats = window.sehatSathiDB.getHealthData();
            let submissionsCount = (currentStats.surveySubmissions || 0) + 1;
            window.sehatSathiDB.saveHealthData({ surveySubmissions: submissionsCount });

            if (form) form.style.opacity = '0';
            if (header) header.style.opacity = '0';
            if (progressContainer) progressContainer.style.opacity = '0';
            
            setTimeout(() => {
                if (form) form.style.display = 'none';
                if (header) header.style.display = 'none';
                if (progressContainer) progressContainer.style.display = 'none';
                
                if (results) {
                    results.classList.remove('hidden');
                    void results.offsetWidth;
                    results.style.opacity = '1';
                }
                
                document.querySelector('main').scrollTo({ top: 0, behavior: 'smooth' });
            }, 400);
        };

        window.resetCommunitySurveyForm = () => {
            const header = document.getElementById('survey-header');
            const progressContainer = document.getElementById('progress-container');
            const results = document.getElementById('results-section');
            
            if (results) results.style.opacity = '0';
            
            setTimeout(() => {
                if (results) results.classList.add('hidden');
                
                if (form) {
                    form.style.display = 'flex';
                    form.reset();
                    form.style.opacity = '1';
                }
                if (header) {
                    header.style.display = 'block';
                    header.style.opacity = '1';
                }
                if (progressContainer) {
                    progressContainer.style.display = 'flex';
                    progressContainer.style.opacity = '1';
                }
                
                const sleepValSpan = document.getElementById('sleepVal');
                if (sleepValSpan) sleepValSpan.textContent = lang === 'hi' ? '7 घंटे' : '7 hrs';
                
                if (progressBar) progressBar.style.width = '25%';
                if (progressText) progressText.textContent = lang === 'hi' ? 'चरण 1 of 4' : 'Step 1 of 4';
                
                const animatedElements = document.querySelectorAll('.form-section');
                animatedElements.forEach(el => {
                    el.style.animation = 'none';
                    void el.offsetWidth;
                    el.style.animation = null;
                });
                
                document.querySelector('main').scrollTo({ top: 0, behavior: 'smooth' });
            }, 400);
        };
    }

    // ==========================================
    // 10.5. PAGE INTERACTIONS: HOME PAGE
    // ==========================================
    if (pageName.includes('index') || pageName === '' || pageName === 'index.html') {
        try {
            let stats = window.sehatSathiDB.getHealthData() || {};
            let totalUsers = 1;
            try {
                totalUsers = JSON.parse(localStorage.getItem('sehatsathi_all_users') || '[]').length || 1;
            } catch (e) {
                console.error("Error parsing all users", e);
            }
            let familiesCount = 0;
            try {
                familiesCount = parseInt(localStorage.getItem('guest_surveySubmissions') || '0') + (stats.surveySubmissions || 0);
            } catch (e) {
                console.error("Error calculating familiesCount", e);
            }
            let topicsCount = stats.healthTopicsCompleted || 0;

            const homePanels = document.querySelectorAll('.glass-panel');
            homePanels.forEach(panel => {
                const icon = panel.querySelector('.material-symbols-outlined');
                const valueDiv = panel.querySelector('.font-display-lg');
                if (icon && valueDiv) {
                    const iconName = icon.textContent.trim();
                    if (iconName === 'family_restroom') {
                        valueDiv.textContent = familiesCount.toString();
                    } else if (iconName === 'groups') {
                        valueDiv.textContent = totalUsers.toString();
                    } else if (iconName === 'menu_book') {
                        valueDiv.textContent = topicsCount.toString();
                    }
                }
            });
        } catch (error) {
            console.error("Error loading home page stats:", error);
        }
    }

    // ==========================================
    // 11. GLOBAL RENDER COMPONENTS: FOOTER
    // ==========================================
    const footerContainer = document.getElementById('footer-container');
    if (footerContainer) {
        let lang = localStorage.getItem('sehatsathi_lang') || 'en';
        footerContainer.className = "w-full py-6 px-6 md:px-12 flex flex-col md:flex-row justify-between items-center gap-4 bg-surface-container-lowest border-t border-white/5 mt-auto z-30 relative text-xs";
        
        const footerTitle = lang === 'hi' 
            ? `<span class="font-bold text-white">सेहतसाथी AI</span> — स्वास्थ्य जागरूकता मंच` 
            : `<span class="font-bold text-white">SehatSaathi AI</span> — Healthcare awareness platform`;
        
        const privacyText = lang === 'hi' ? 'गोपनीयता नीति' : 'Privacy';
        const termsText = lang === 'hi' ? 'सेवा की शर्तें' : 'Terms';
        const contactText = lang === 'hi' ? 'संपर्क करें' : 'Contact';

        footerContainer.innerHTML = `
            <div class="text-center md:text-left text-on-surface-variant">
                ${footerTitle}
            </div>
            <div class="flex gap-4 text-on-surface-variant justify-center flex-wrap">
                <a class="hover:text-accent hover:underline transition-all duration-200" href="#">${privacyText}</a>
                <a class="hover:text-accent hover:underline transition-all duration-200" href="#">${termsText}</a>
                <a class="hover:text-accent hover:underline transition-all duration-200" href="#">${contactText}</a>
            </div>
        `;
    }

    // Trigger Dynamic Translation runner
    translatePage();
});

// Polyfill for containsText
jQueryContainsPolyfill();
function jQueryContainsPolyfill() {
    if (typeof Element.prototype.containsText === 'undefined') {
        Element.prototype.containsText = function(text) {
            return this.textContent.trim().includes(text);
        };
    }
}
