/**
 * SehatSaathi AI - Gemini API Service Integration
 */

window.geminiService = {
    async askGemini(prompt, apiKey) {
        if (!apiKey || apiKey.trim().length < 5 || apiKey.includes('...')) {
            throw new Error("Invalid API Key");
        }

        try {
            // Import the official Google AI SDK dynamically from CDN
            const { GoogleGenerativeAI } = await import("https://esm.run/@google/generative-ai");
            
            // Initialize the SDK client
            const genAI = new GoogleGenerativeAI(apiKey);
            
            // Use the currently supported stable model
            const model = genAI.getGenerativeModel({ 
                model: "gemini-1.5-flash" 
            });
            
            // Call generateContent with concise healthcare prompt constraints
            const result = await model.generateContent(
                prompt + "\n\n(Provide direct, helpful healthcare information. Keep response concise, readable with bullet points. Include disclaimer at the end.)"
            );
            
            const response = await result.response;
            const text = response.text();
            
            if (text) {
                return text;
            } else {
                throw new Error("Empty response returned from model.");
            }
        } catch (error) {
            console.error("Gemini API Error:", error);
            throw error; // Re-throw to allow script.js to manage offline fallback
        }
    }
};
