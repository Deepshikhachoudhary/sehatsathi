/**
 * SehatSaathi AI - Bilingual Interface Translations Dictionary
 */

window.sehatSathiTranslations = {
    en: {
        // Navigation / Sidebar Links
        nav_home: "Home",
        nav_assistant: "AI Assistant",
        nav_library: "Health Library",
        nav_first_aid: "First Aid",
        nav_family_card: "Family Health Card",
        nav_schemes: "Government Schemes",
        nav_impact: "Community Impact",
        nav_tools: "Health Tools",
        nav_feedback: "Feedback",

        nav_logout: "Logout",
        nav_login: "Login / Register",
        nav_guest: "Guest Mode",

        // Common Headers & Titles
        logo_title: "SehatSaathi AI",
        tagline: "Community Healthcare Companion",
        btn_listen: "Listen to Overview",
        btn_search: "Search",
        btn_submit: "Submit",
        btn_save: "Save",
        btn_close: "Close",
        btn_cancel: "Cancel",

        // Home Page Static Elements
        home_title: "Community Healthcare Platform",
        home_desc: "Your bilingual health companion. Access AI-powered assistance, local health libraries, emergency guides, and digital health cards.",
        home_features: "Core Features",
        home_stat_users: "TOTAL USERS",
        home_stat_families: "FAMILIES REACHED",
        home_stat_completed: "TOPICS COMPLETED",

        // First Aid Page Static Elements
        fa_title: "Emergency First Aid Guide",
        fa_desc: "Immediate actionable steps for common emergencies. Follow these instructions carefully while waiting for medical help.",
        fa_emergency_numbers: "Emergency Helplines",
        fa_national_emergency: "National Emergency: 112",
        fa_ambulance: "Ambulance: 108",
        fa_women_helpline: "Women Helpline: 1091",
        fa_child_helpline: "Child Helpline: 1098",

        // Govt Schemes Page Static Elements
        schemes_title: "Government Healthcare Schemes",
        schemes_desc: "Discover, verify eligibility, and learn how to apply for central and state health benefits.",
        schemes_finder_title: "Scheme Finder Tool",
        schemes_finder_desc: "Filter schemes by eligibility criteria:",
        schemes_filter_age: "Select Age Group",
        schemes_filter_income: "Income Category",
        schemes_filter_gender: "Select Gender",
        schemes_tab_eligibility: "Eligibility",
        schemes_tab_benefits: "Benefits",
        schemes_tab_docs: "Documents Required",
        schemes_tab_apply: "How to Apply",

        // Health Library Page Static Elements
        lib_title: "Health Library",
        lib_desc: "Search verified bilingual information for common diseases, chronic conditions, and wellness.",
        lib_search_placeholder: "Search diseases, symptoms, causes...",
        lib_tab_all: "All Topics",
        lib_tab_common: "Common Diseases",
        lib_tab_chronic: "Chronic Conditions",
        lib_tab_women: "Women's Health",
        lib_tab_children: "Children's Health",

        // Family Card Page Static Elements
        fc_title: "Digital Family Health Card",
        fc_desc: "Create and manage digital health profiles for your family. Generate QR codes for instant emergency medical retrieval.",
        fc_add_member: "Add Family Member",
        fc_select_profile: "Select Card Profile",
        fc_form_personal: "Personal Details",
        fc_form_medical: "Medical History",
        fc_form_emergency: "Emergency Contact Info",
        fc_label_relationship: "Relationship",
        fc_label_name: "Full Name",
        fc_label_age: "Age",
        fc_label_gender: "Gender",
        fc_label_blood: "Blood Group",
        fc_label_diseases: "Chronic Diseases",
        fc_label_allergies: "Allergies",
        fc_label_medicines: "Current Medications",
        fc_label_surgeries: "Previous Surgeries",
        fc_label_vaccines: "Vaccinations",
        fc_label_contact: "Emergency Contact",
        fc_label_address: "Residential Address",
        fc_btn_generate: "Save & Generate Card",
        fc_preview_title: "Digital Health Card Preview",
        fc_scan_instruction: "Scan to Access Profile",

        // Feedback Page Static Elements
        fb_title: "Website Feedback",
        fb_desc: "Help us improve SehatSaathi by sharing your experience and suggestions.",
        fb_q_rating: "How did you find this website?",
        fb_opt_good: "Good",
        fb_opt_not_good: "Not Good",
        fb_q_suggestions: "Do you have any suggestions or feedback for us?",
        fb_placeholder_suggestions: "Enter your suggestions here...",
        fb_btn_submit: "Submit Feedback",
        fb_success_title: "Feedback Submitted!",
        fb_success_desc: "Thank you for your feedback! Your suggestions help us improve SehatSaathi AI for the entire community.",
        fb_btn_reset: "Submit Another Response",

        // Tools Page Static Elements
        tools_title: "Health Tracker Tools",
        tools_desc: "Monitor your key health parameters including BMI, water intake, sleep patterns, and medicine schedules.",
        tools_bmi_title: "BMI Calculator",
        tools_bmi_height: "Height (cm)",
        tools_bmi_weight: "Weight (kg)",
        tools_bmi_btn: "Calculate BMI",
        tools_water_title: "Water Intake Tracker",
        tools_water_goal: "Daily Goal: 2.5L",
        tools_sleep_title: "Sleep Tracker",
        tools_sleep_click: "Click to log sleep hours",
        tools_med_title: "Medicine Schedule",
        tools_med_pill: "Pill Name",
        tools_med_dosage: "Dosage",
        tools_med_time: "Time",
        tools_med_status: "Status",

        // Impact Page Static Elements
        imp_title: "Community Health Impact",
        imp_desc: "Real-time analytics and coverage data from SehatSaathi deployment in rural and urban communities.",
        imp_card_users: "Registered Users",
        imp_card_families: "Families Covered",
        imp_card_topics: "Topics Read",
        imp_card_questions: "AI Queries Handled",



        // Auth Page
        auth_title: "Welcome to SehatSaathi AI",
        auth_desc: "Access bilingual healthcare tools, digital cards, and instant AI guidance.",

        // Symptom Checker Page Static Elements
        nav_symptom_checker: "Symptom Checker",
        sc_title: "Symptom Checker",
        sc_desc: "Select a symptom below to understand possible causes, learn basic care steps, and know when to seek immediate medical attention.",

        // Community Survey Page Static Elements
        nav_community_survey: "Community Survey",
        cs_title: "Community Health Survey",
        cs_desc: "Your responses help us understand healthcare awareness needs in rural and community sectors."
    },
    hi: {
        // Navigation / Sidebar Links
        nav_home: "मुख्य पृष्ठ",
        nav_assistant: "AI सहायक",
        nav_library: "स्वास्थ्य पुस्तकालय",
        nav_first_aid: "प्राथमिक चिकित्सा",
        nav_family_card: "पारिवारिक स्वास्थ्य कार्ड",
        nav_schemes: "सरकारी योजनाएं",
        nav_impact: "सामुदायिक प्रभाव",
        nav_tools: "स्वास्थ्य उपकरण",
        nav_feedback: "प्रतिक्रिया",

        nav_logout: "लॉगआउट",
        nav_login: "लॉगिन / पंजीकरण",
        nav_guest: "अतिथि मोड",

        // Common Headers & Titles
        logo_title: "सेहतसाथी AI",
        tagline: "सामुदायिक स्वास्थ्य साथी",
        btn_listen: "विवरण सुनें",
        btn_search: "खोजें",
        btn_submit: "जमा करें",
        btn_save: "सहेजें",
        btn_close: "बंद करें",
        btn_cancel: "रद्द करें",

        // Home Page Static Elements
        home_title: "सामुदायिक स्वास्थ्य मंच",
        home_desc: "आपका दुभाषिया स्वास्थ्य साथी। एआई-संचालित सहायता, स्थानीय स्वास्थ्य पुस्तकालयों, आपातकालीन गाइडों और डिजिटल स्वास्थ्य कार्डों तक पहुंचें।",
        home_features: "मुख्य विशेषताएं",
        home_stat_users: "कुल उपयोगकर्ता",
        home_stat_families: "लाभान्वित परिवार",
        home_stat_completed: "पूरे किए गए विषय",

        // First Aid Page Static Elements
        fa_title: "आपातकालीन प्राथमिक चिकित्सा गाइड",
        fa_desc: "सामान्य आपात स्थितियों के लिए तत्काल कार्रवाई योग्य कदम। चिकित्सा सहायता की प्रतीक्षा करते समय इन निर्देशों का सावधानीपूर्वक पालन करें।",
        fa_emergency_numbers: "आपातकालीन हेल्पलाइन नंबर",
        fa_national_emergency: "राष्ट्रीय आपातकाल: 112",
        fa_ambulance: "एम्बुलेंस: 108",
        fa_women_helpline: "महिला हेल्पलाइन: 1091",
        fa_child_helpline: "चाइल्ड हेल्पलाइन: 1098",

        // Govt Schemes Page Static Elements
        schemes_title: "सरकारी स्वास्थ्य योजना केंद्र",
        schemes_desc: "केंद्र और राज्य सरकार के स्वास्थ्य लाभों की खोज करें, पात्रता की जांच करें और आवेदन करना सीखें।",
        schemes_finder_title: "योजना खोजक उपकरण",
        schemes_finder_desc: "पात्रता मानदंडों के अनुसार योजनाएं छाँटें:",
        schemes_filter_age: "आयु वर्ग चुनें",
        schemes_filter_income: "आय श्रेणी",
        schemes_filter_gender: "लिंग चुनें",
        schemes_tab_eligibility: "पात्रता",
        schemes_tab_benefits: "योजना के लाभ",
        schemes_tab_docs: "आवश्यक दस्तावेज",
        schemes_tab_apply: "आवेदन कैसे करें",

        // Health Library Page Static Elements
        lib_title: "स्वास्थ्य पुस्तकालय",
        lib_desc: "सामान्य बीमारियों, पुरानी स्वास्थ्य स्थितियों और कल्याण के लिए सत्यापित द्विभाषी जानकारी खोजें।",
        lib_search_placeholder: "बीमारियों, लक्षणों, कारणों को खोजें...",
        lib_tab_all: "सभी विषय",
        lib_tab_common: "सामान्य बीमारियां",
        lib_tab_chronic: "दीर्घकालिक बीमारियां",
        lib_tab_women: "महिला स्वास्थ्य",
        lib_tab_children: "बाल स्वास्थ्य",

        // Family Card Page Static Elements
        fc_title: "डिजिटल पारिवारिक स्वास्थ्य कार्ड",
        fc_desc: "अपने परिवार के लिए डिजिटल स्वास्थ्य प्रोफ़ाइल बनाएं और प्रबंधित करें। तत्काल आपातकालीन चिकित्सा विवरण के लिए क्यूआर कोड बनाएं।",
        fc_add_member: "परिवार का सदस्य जोड़ें",
        fc_select_profile: "कार्ड प्रोफ़ाइल चुनें",
        fc_form_personal: "व्यक्तिगत विवरण",
        fc_form_medical: "चिकित्सा इतिहास",
        fc_form_emergency: "आपातकालीन संपर्क जानकारी",
        fc_label_relationship: "संबंध",
        fc_label_name: "पूरा नाम",
        fc_label_age: "उम्र",
        fc_label_gender: "लिंग",
        fc_label_blood: "रक्त समूह",
        fc_label_diseases: "दीर्घकालिक बीमारियां",
        fc_label_allergies: "एलर्जी",
        fc_label_medicines: "वर्तमान दवाएं",
        fc_label_surgeries: "पिछली सर्जरी",
        fc_label_vaccines: "टीकाकरण",
        fc_label_contact: "आपातकालीन संपर्क",
        fc_label_address: "आवासीय पता",
        fc_btn_generate: "सहेजें और कार्ड बनाएं",
        fc_preview_title: "डिजिटल स्वास्थ्य कार्ड पूर्वावलोकन",
        fc_scan_instruction: "विवरण देखने के लिए स्कैन करें",

        // Feedback Page Static Elements
        fb_title: "वेबसाइट प्रतिक्रिया",
        fb_desc: "अपने अनुभव और सुझाव साझा करके सेहतसाथी को बेहतर बनाने में हमारी मदद करें।",
        fb_q_rating: "आपको यह वेबसाइट कैसी लगी?",
        fb_opt_good: "अच्छी लगी",
        fb_opt_not_good: "अच्छी नहीं लगी",
        fb_q_suggestions: "क्या आपके पास हमारे लिए कोई सुझाव या प्रतिक्रिया है?",
        fb_placeholder_suggestions: "अपने सुझाव यहाँ दर्ज करें...",
        fb_btn_submit: "प्रतिक्रिया भेजें",
        fb_success_title: "प्रतिक्रिया सबमिट की गई!",
        fb_success_desc: "आपकी प्रतिक्रिया के लिए धन्यवाद! आपके सुझाव हमें पूरे समुदाय के लिए सेहतसाथी AI को बेहतर बनाने में मदद करते हैं।",
        fb_btn_reset: "एक और प्रतिक्रिया सबमिट करें",

        // Tools Page Static Elements
        tools_title: "स्वास्थ्य ट्रैकर उपकरण",
        tools_desc: "बीएमआई, पानी का सेवन, नींद के पैटर्न और दवा के शेड्यूल सहित अपने प्रमुख स्वास्थ्य मापदंडों की निगरानी करें।",
        tools_bmi_title: "बीएमआई (BMI) कैलकुलेटर",
        tools_bmi_height: "ऊंचाई (सेमी)",
        tools_bmi_weight: "वजन (किलो)",
        tools_bmi_btn: "बीएमआई गणना करें",
        tools_water_title: "जल सेवन ट्रैकर",
        tools_water_goal: "दैनिक लक्ष्य: 2.5L",
        tools_sleep_title: "नींद ट्रैकर",
        tools_sleep_click: "नींद के घंटे दर्ज करने के लिए क्लिक करें",
        tools_med_title: "दवा अनुसूची (शेड्यूल)",
        tools_med_pill: "दवा का नाम",
        tools_med_dosage: "खुराक (डोज)",
        tools_med_time: "समय",
        tools_med_status: "स्थिति",

        // Impact Page Static Elements
        imp_title: "सामुदायिक स्वास्थ्य प्रभाव",
        imp_desc: "ग्रामीण और शहरी समुदायों में सेहतसाथी की तैनाती से वास्तविक समय के विश्लेषिकी और कवरेज डेटा।",
        imp_card_users: "पंजीकृत उपयोगकर्ता",
        imp_card_families: "कवर किए गए परिवार",
        imp_card_topics: "पढ़े गए विषय",
        imp_card_questions: "सुलझाए गए एआई प्रश्न",



        // Auth Page
        auth_title: "सेहतसाथी AI में आपका स्वागत है",
        auth_desc: "दुभाषिया स्वास्थ्य उपकरणों, डिजिटल कार्डों और त्वरित एआई मार्गदर्शन तक पहुंचें।",

        // Symptom Checker Page Static Elements
        nav_symptom_checker: "लक्षण जांचकर्ता",
        sc_title: "लक्षण जांचकर्ता",
        sc_desc: "संभावित कारणों को समझने, बुनियादी देखभाल के कदमों को जानने और तत्काल चिकित्सा सहायता प्राप्त करने के समय को जानने के लिए नीचे दिए गए लक्षणों को चुनें।",

        // Community Survey Page Static Elements
        nav_community_survey: "सामुदायिक सर्वेक्षण",
        cs_title: "सामुदायिक स्वास्थ्य सर्वेक्षण",
        cs_desc: "आपकी प्रतिक्रियाएं हमें ग्रामीण और सामुदायिक क्षेत्रों में स्वास्थ्य जागरूकता आवश्यकताओं को समझने में मदद करती हैं।"
    }
};
